<?php
require 'header.php';
?>
<style>
    .nav-link.activetc {
        background-color: rgb(3, 29, 54);
        color: white;
    }
</style>

<div class="event text-right">
    <p class="p-t-13"><a href="#"><i class="fa fa-plus"></i> Add Course</a></p>
</div>

<div class="row" style="overflow-x: scroll;">
    <table class="table table-hover table-bordered bg-white" id="sampleTable">
        <thead>
            <tr>
                <th>Trainer Names</th>
                <th>Course Name</th>
                <th>School Name</th>
                <th>Date</th>
                <th>Period</th>
                <th>Trade</th>
                <th>Level</th>
                <th>No Trainees</th>
                <th>MCDCO</th>
                <th>Topic</th>
                <th>SOW</th>
                <th>SPAEF</th>
                <th>CDAU</th>
                <th>CAIEU</th>
                <th>TMSBPCETREWA</th>
                <th>FTA</th>
                <th>TAAU</th>
                <th>DMAU</th>
                <th>TSP</th>
                <th>CIWM</th>
                <th>LEIC</th>
                <th>T Mark (55)</th>
                <th>Strong Point</th>
                <th>Area of Improvement</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
        <?php
        require 'connection.php';

        // Get user role and school
        $title = $_SESSION['title'];
        $school = $_SESSION['school'];
        $usr_id = $_SESSION['user_id']; // Assuming user_id is stored in session for identifying the Trainer
        // $id = $_GET['trainer'];
        // Admin has the highest priority - Can see all trainer checklists (no restrictions)
        if ($title == 'Admin') {
            $sql = "SELECT * FROM checklist
                    INNER JOIN users ON checklist.usr_id = users.user_id
                    INNER JOIN schools ON checklist.schol_id = schools.school_id
                    INNER JOIN courses ON checklist.course_id = courses.course_id
                    WHERE checklist.usr_id = '$id'
                    ORDER BY list_id DESC";
        }
        // Trainer: Can only see data that is assigned to them. This will be unique data.
        else if ($title == 'Trainer') {
            $sql = "SELECT * FROM checklist
                    INNER JOIN users ON checklist.usr_id = users.user_id
                    INNER JOIN schools ON checklist.schol_id = schools.school_id
                    INNER JOIN courses ON checklist.course_id = courses.course_id
                    WHERE checklist.usr_id = '$usr_id' AND schools.school_id = '$school'
                    ORDER BY list_id DESC";
        }
        // Master and Dos: See their specific data, but might overlap with Trainer based on school
        else if ($title == 'Master' || $title == 'Dos') {
            $sql = "SELECT * FROM checklist
                    INNER JOIN users ON checklist.usr_id = users.user_id
                    INNER JOIN schools ON checklist.schol_id = schools.school_id
                    INNER JOIN courses ON checklist.course_id = courses.course_id
                    WHERE schools.school_id = '$school'
                    -- AND checklist.usr_id = '$id'
                    ORDER BY list_id DESC";
        }

        // Execute the query
        $select = mysqli_query($conn, $sql);
        while ($rows = mysqli_fetch_array($select)) {
        ?>
            <tr>
                <td><?=$rows['username']?></td>
                <td><?=$rows['course_name']?></td>
                <td><?=$rows['school_name']?></td>
                <td><?=$rows['date']?></td>
                <td><?=$rows['period']?></td>
                <td><?=$rows['trade']?></td>
                <td><?=$rows['level']?></td>
                <td><?=$rows['no_trainees']?></td>
                <td><?=$rows['mcdco']?></td>
                <td><?=$rows['topic']?></td>
                <td><?=$rows['sowr']?></td>
                <td><?=$rows['spaef']?></td>
                <td><?=$rows['cdau']?></td>
                <td><?=$rows['caleu']?></td>
                <td><?=$rows['tmsbpcetrewa']?></td>
                <td><?=$rows['fta']?></td>
                <td><?=$rows['taau']?></td>
                <td><?=$rows['dmau']?></td>
                <td><?=$rows['tsp']?></td>
                <td><?=$rows['ciwm']?></td>
                <td><?=$rows['leic']?></td>
                <td><?=$rows['avg_sum']?></td>
                <td><?=$rows['strong_point']?></td>
                <td><?=$rows['area_of_improv']?></td>
                <td>
                    <a href=""><i class="fa fa-comment text-danger" style="font-size: 25px;margin-right: 10px" title="Delete <?=$rows['username']?> checklist file" onclick="return confirm('Are you sure you want to delete this Trainer?')"></i></a>
                    <a href="view_trainer_inspection.php?trainer=<?=$rows['list_id']?>=<?=$rows['username']?>"><i class="fa fa-eye" style="font-size: 25px" title="View <?=$rows['username']?> Checklist file"></i></a>
                </td>
            </tr>
        <?php
        }
        ?>
        </tbody>
    </table>
</div>

<?php
require 'footer.php';
?>
