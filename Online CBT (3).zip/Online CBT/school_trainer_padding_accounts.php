<?php
require 'header.php';
require 'connection.php';
?>

<style>
    .activepa {
        background-color: rgba(3, 29, 54, 0.56);
        color: white;
    }
</style>

<div class="event text-right">
    <p class="p-t-13"><a href="add_trainer.php"><i class="fa fa-plus"></i> Add Trainer</a></p>
</div>

<div class="row" style="overflow-x: scroll;">
    <table class="table table-hover table-bordered bg-white" id="sampleTable">
        <thead>
            <tr>
                <th>Trainer Image</th>
                <th>Trainer Name</th>
                <th>National Id</th>
                <th>Telephone</th>
                <th>Degree</th>
                <th>Title</th>
                <th>Email</th>
                <th>School</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $school = $_SESSION['school'];
            $sql = "SELECT * FROM users JOIN schools ON users.school = schools.school_id WHERE user_status = 'pending' AND school = '$school' ORDER BY user_id DESC";
            $select = mysqli_query($conn, $sql);
            while ($rows = mysqli_fetch_array($select)) {
            ?>
                <tr id="trainer-<?=$rows['user_id']?>">
                    <td><a href="#" data-toggle="modal" data-target="#imageModal" data-image="uploaded_file/<?=$rows['user_image']?>"><img src="uploaded_file/<?=$rows['user_image']?>" alt="" style="width: 4rem;height: 4rem;border-radius: 350px;border: 1px solid green"></a></td>
                    <td><?=$rows['username']?></td>
                    <td><?=$rows['nat_id']?></td>
                    <td><?=$rows['tel']?></td>
                    <td><?=$rows['degree']?></td>
                    <td><?=$rows['title']?></td>
                    <td><?=$rows['email']?></td>
                    <td><?=$rows['school_name']?></td>
                    <td>
                        <a href="#" class="approve-btn" data-id="<?=$rows['user_id']?>"><i class="fa fa-check text-info" style="font-size: 25px;margin-right: 10px" title="Approve <?=$rows['username']?> Account"></i></a>
                        <a href="#" class="delete-btn" data-id="<?=$rows['user_id']?>"><i class="fa fa-times text-danger" style="font-size: 25px;margin-right: 10px" title="Delete <?=$rows['username']?> Account"></i></a>
                    </td>
                </tr>
            <?php
            }
            ?>
        </tbody>
    </table>
</div>

<!-- Modal to show full image -->
<div class="modal fade" id="imageModal" tabindex="-1" role="dialog" aria-labelledby="imageModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="imageModalLabel">Trainer Image</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <img src="" alt="Trainer Image" id="fullImage" style="width: 100%; height: auto;">
            </div>
        </div>
    </div>
</div>

<?php require 'footer.php'; ?>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
$(document).ready(function() {
    // Show full image in modal
    $('#imageModal').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget);
        var imageSrc = button.data('image');
        $('#fullImage').attr('src', imageSrc);
    });

    // Approve trainer
    $('.approve-btn').click(function() {
        var trainerId = $(this).data('id');
        Swal.fire({
            title: 'Are you sure?',
            text: 'You are about to approve this trainer Account!',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, approve!',
            cancelButtonText: 'Cancel'
        }).then((result) => {
            if (result.isConfirmed) {
                $.post('approve_account.php', { user_id: trainerId, status: 'approved' }, function(response) {
                    Swal.fire('Approved!', 'Trainer Account has been approved.', 'success');
                    $('#trainer-' + trainerId).remove();
                });
            }
        });
    });

    // Delete trainer
    $('.delete-btn').click(function() {
        var trainerId = $(this).data('id');
        Swal.fire({
            title: 'Are you sure?',
            text: 'To Reject Trainer Account!',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete!',
            cancelButtonText: 'Cancel'
        }).then((result) => {
            if (result.isConfirmed) {
                $.post('delete_trainer_account.php', { delete: trainerId }, function(response) {
                    Swal.fire('Deleted!', 'Trainer has been removed.', 'success');
                    $('#trainer-' + trainerId).remove();
                });
            }
        });
    });
});
</script>
