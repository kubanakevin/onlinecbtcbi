<?php
// Include database connection
require 'connection.php';

// Check if the course ID is provided
if(isset($_GET['course'])) {
    $course_id = $_GET['course'];

    // Prepare the DELETE query
    $sql = "DELETE FROM courses WHERE course_id = '$course_id'";

    // Execute the query
    if(mysqli_query($conn, $sql)) {
        echo 'success'; // Send success response
    } else {
        echo 'error'; // Send error response if something went wrong
    }
} else {
    echo 'error'; // Send error response if no course ID is provided
}

// Close the database connection
mysqli_close($conn);
?>
