<?php
require 'header.php'; // Include header
require 'connection.php'; // Include database connection

// Handle AJAX Request to Update Schema Status
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['assessment_id'])) {
    $assessment_id = $_POST['assessment_id'];

    // Update the assessment_plan table
    $updateQuery = "UPDATE assessment_plan SET astatus = 'pending' WHERE assessment_id = ?";
    $stmt = $conn->prepare($updateQuery);
    $stmt->bind_param("i", $assessment_id);
    
    if ($stmt->execute()) {
        echo json_encode(["status" => "success"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Failed to update."]);
    }
    exit;
}

// Pagination setup
$school = $_SESSION['school'];
$user = $_SESSION['user_id'];
$itemsPerPage = 12; // Number of items per page
$currentPage = isset($_GET['page']) ? $_GET['page'] : 1; // Current page number
$offset = ($currentPage - 1) * $itemsPerPage; // Offset for database query

// Fetch data from the database
$sql = "SELECT assessment_plan.*, courses.course_name, courses.course_level 
        FROM assessment_plan 
        INNER JOIN courses ON assessment_plan.ascourse_id = courses.course_id
        WHERE assessment_plan.aschl_id = '$school' 
        AND assessment_plan.auser_id = '$user' 
        AND assessment_plan.assessment_id > 0
        ORDER BY assessment_plan.assessment_id DESC 
        LIMIT $itemsPerPage OFFSET $offset";
$result = $conn->query($sql);

// Total items count for pagination
$sqlCount = "SELECT COUNT(*) AS total_items FROM assessment_plan WHERE aschl_id = '$school' AND auser_id = '$user'";
$countResult = $conn->query($sqlCount);
$row = $countResult->fetch_assoc();
$totalItems = $row['total_items'];
$totalPages = ceil($totalItems / $itemsPerPage);
?>
<style>
    .activewith {
        background-color: rgba(3, 29, 54, 0.56);
        color: white;
    }
</style>
<div class="container mt-3">
    <h4>Modules With Assessment Plan</h4>
    <div class="row">
        <?php if ($result->num_rows > 0) : ?>
            <?php while ($row = $result->fetch_assoc()) : 
            $fileName = $row['assessment_doc'];
            $fileNameLimited = substr($fileName, 0, 20); // Limit file name to 10 characters
                ?>
                <div class="col-md-4 mb-3">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Module Name: <strong><?php echo $row['course_name']; ?></strong></h5>
                            <p class="card-text">Level: <strong><?php echo $row['course_level']; ?></strong></p>
                            <p class="card-text">Time: <strong><?php echo $row['date']; ?></strong></p>
                            <p><a href="view_assessment_plan.php?schema=<?=$row['assessment_doc']?>" target="_blank"><?=$fileNameLimited?></a></p>
                            <?php
                            if ($row['on_status'] == 'done') {
                                echo "<p class='text-success'> <i class='fa fa-check-circle'></i> Assessment Done </p>";
                            } else {
                                ?>
                                <p class='text-danger'>
                                    <i class='fa fa-times-circle'></i> Not Yet Done
                                    <a href='#' style='margin-left: 20px' class="doneAssessmentLink" data-assessment-id="<?= $row['assessment_id'] ?>">
                                        <span class='text-success'><i class='fa fa-check-circle'></i> Make it done</span>
                                    </a>
                                </p>
                                <?php
                            }
                            ?>
                            <?php if ($row['astatus'] == 'none') : ?>
                                <button class="btn btn-warning generate-btn col-lg-12 p-2" data-id="<?php echo $row['assessment_id']; ?>">
                                    <i class="fa fa-plus-circle"></i> Generate
                                </button>
                            <?php elseif ($row['astatus'] == 'pending') : ?>
                                <button class="btn btn-primary col-lg-12 p-2">
                                    <i class="fa fa-spinner fa-spin"></i> Pending...
                                </button>
                            <?php elseif ($row['astatus'] == 'approved') : ?>
                                <button class="btn btn-success col-lg-12 p-2">
                                    <i class="fa fa-check-circle"></i> Approved
                                </button>
                            <?php elseif ($row['astatus'] == 'rejected') : ?>
                                <button class="btn btn-danger col-lg-12">Rejected</button>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else : ?>
            <p class='text-center'>No Assessment Plan Here.</p>
        <?php endif; ?>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
$(document).ready(function() {
    $(document).on("click", ".doneAssessmentLink", function(e) {
        e.preventDefault();
        var assessmentId = $(this).data("assessment-id");

        Swal.fire({
            title: 'Are you sure?',
            text: "Do you want to mark this assessment as done?",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, make it done!',
            cancelButtonText: 'Cancel'
        }).then((result) => {
            if (result.isConfirmed) {
                $.post("done_assessment.php", { assessment_id: assessmentId }, function(response) {
                    var result = JSON.parse(response);
                    if (result.success) {
                        Swal.fire('Done!', 'The assessment has been marked as done.', 'success');
                        location.reload();
                    } else {
                        Swal.fire('Error!', 'There was an error marking the assessment as done.', 'error');
                    }
                });
            }
        });
    });
});
</script>

<?php require 'footer.php'; ?>
