<!DOCTYPE html>
<html lang="en">
<head>
    <title>Trainer Sign Up</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" href="images/icon.png">
    <link rel="stylesheet" type="text/css" href="st/vendor/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="st/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="st/vendor/animate/animate.css">
    <link rel="stylesheet" type="text/css" href="st/vendor/select2/select2.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="icon" type="image/png" href="images/icon.png">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="st/vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="st/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="st/vendor/animate/animate.css">
<!--===============================================================================================-->	
	<link rel="stylesheet" type="text/css" href="st/vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="st/vendor/select2/select2.min.css">
    <link href="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/css/select2.min.css" rel="stylesheet" />
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="st/css/util.css">
	<link rel="stylesheet" type="text/css" href="st/css/main.css">
    <!-- Include Select2 CSS -->
<link href="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/css/select2.min.css" rel="stylesheet" />

<!-- Include jQuery (required for Select2) -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- Include Select2 JS -->
<script src="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/js/select2.min.js"></script>
<style>
    /* Style the select dropdown */
.select2-container .select2-selection--single {
    border: 2px solid rgba(70, 247, 70, 0.24); /* Green border for the select box */
    padding: 25px; /* Add padding to the select box */
    font-size: 16px; /* Set the font size */
    border-radius: 30px; /* Slightly rounded corners */
    background-color:rgb(224, 224, 224); /* Light background color */
}

/* Style the dropdown when it's open */
.select2-container .select2-dropdown {
    border: 2px solid  rgba(70, 247, 70, 0.24); /* Green border for the dropdown */
    border-radius: 5px; /* Rounded corners for the dropdown */
    background-color: #ffffff; /* White background for the dropdown */
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); /* Subtle shadow for dropdown */
}

/* Focus effect on the select dropdown */
.select2-container--focus .select2-selection--single {
    border-color:  rgba(70, 247, 70, 0.24); /* Darker green border when focused */
    outline: none; /* Remove default outline */
    box-shadow: 0 0 5px rgba(0, 128, 0, 0.5); /* Add a glow effect when focused */
}

/* Style the dropdown options */
.select2-container .select2-results__option {
    font-size: 16px; /* Set font size for the options */
    padding: 10px; /* Padding inside each option */
    background-color: #f1f1f1; /* Background color for the options */
}

/* Hover effect on the options */
.select2-container .select2-results__option--highlighted {
    background-color: #d3f4d8; /* Light green background on hover */
}

/* Style for the placeholder text */
.select2-container .select2-selection--single .select2-selection__placeholder {
    color: #888888; /* Placeholder text color */
    font-style: italic; /* Italic style for placeholder */
}

</style>
</head>
<body>
    <div class="limiter">
        <div class="container-login100">
            <div class="wrap-login100">
            <?php
include('connection.php');
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $nat_id = $_POST['nat_id'];
    $tel = $_POST['tel'];
    $degree = $_POST['degree'];
    $title = $_POST['title'];
    $school_id = $_POST['school_id'];
    $email = $_POST['email'];
    $password = $_POST['pass'];
    $re_password = $_POST['re_pass'];
    
    // Check if an image was uploaded, otherwise use the default image name
    if (!empty($_FILES['user_image']['name'])) {
        $user_image = $_FILES['user_image']['name'];
        $target_dir = "uploaded_file/";
        $target_file = $target_dir . basename($user_image);
    } else {
        // Use the default image name when no image is uploaded
        $user_image = "defout_image.png";  // Only the image name, no path
    }
    
    // Validate required fields
    if (empty($username) || empty($nat_id) || empty($tel) || empty($degree) || empty($title) || empty($email) || empty($password) || empty($re_password) || $password !== $re_password) {
        echo "<script>Swal.fire('Error', 'Make sure passwords match and all fields are filled.', 'error');</script>";
    } else {
        // Hash the password before storing it
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // If image is uploaded, move it to the target folder
        if (!empty($_FILES['user_image']['name']) && !move_uploaded_file($_FILES['user_image']['tmp_name'], $target_file)) {
            echo "<script>Swal.fire('Error', 'Sorry, there was an error uploading your file.', 'error');</script>";
        } else {
            // Insert the user data into the database
            $stmt = $conn->prepare("INSERT INTO users (username, nat_id, tel, degree, title, school, email, password, re_password, user_image) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("ssssssssss", $username, $nat_id, $tel, $degree, $title, $school_id, $email, $hashed_password, $re_password, $user_image);
            
            if ($stmt->execute()) {
                echo "<script>Swal.fire({title: 'Success', text: 'Account created successfully! Redirecting...', icon: 'success'}).then(() => {window.location.href='index.php';});</script>";
            } else {
                echo "<script>Swal.fire('Error', 'There was an issue with registration.', 'error');</script>";
            }
            $stmt->close();
        }
        $conn->close();
    }
}
?>

                <div class="login100-pic js-tilt" data-tilt>
					<img src="st/images/img-01.png" alt="IMG" style="margin-top: 5rem;">
					
				</div>
                <form class="login100-form validate-form" action="" method="POST" enctype="multipart/form-data">
                    <span class="login100-form-title">Account Creation</span>
                    <div class="wrap-input100 validate-input">
                            <input class="input100" type="text" name="username" placeholder="Full Names" value="<?php echo isset($username) ? $username : ''; ?>">
                        </div>
                        <div class="wrap-input100 validate-input">
                            <input class="input100" type="number" name="nat_id" placeholder="National Id" value="<?php echo isset($nat_id) ? $nat_id : ''; ?>">
                        </div>
                        <div class="wrap-input100 validate-input">
                            <input class="input100" type="text" name="tel" placeholder="Telephone No" value="<?php echo isset($tel) ? $tel : ''; ?>">
                        </div>
                        <div class="wrap-input100 validate-input">
                            <input class="input100" type="text" name="degree" placeholder="Degree Level" value="<?php echo isset($degree) ? $degree : ''; ?>">
                        </div>
                        <div class="wrap-input100 validate-input">
                            <select name="title" class="input100">
                                <option value="Trainer" <?php echo isset($title) && $title == 'Trainer' ? 'selected' : ''; ?>>Trainer</option>
                                <option value="Dos" <?php echo isset($title) && $title == 'Dos' ? 'selected' : ''; ?>>Dos</option>
                                <option value="Master" <?php echo isset($title) && $title == 'Master' ? 'selected' : ''; ?>>Master</option>
                            </select>
                        </div>
                        <div class="wrap-input100 validate-input">
                            <input class="input100" type="text" name="email" placeholder="Email" value="<?php echo isset($email) ? $email : ''; ?>">
                        </div>
                        <div class="wrap-input100 validate-input">
                            <select id="school_id" name="school_id" class="input100">
                                <option value="">Select a School</option>
                                <?php
                                $result = $conn->query("SELECT * FROM schools");
                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        $selected = (isset($school_id) && $school_id == $row['school_id']) ? 'selected' : '';
                                        echo "<option value='{$row['school_id']}' {$selected}>{$row['school_name']}</option>";
                                    }
                                }
                                ?>
                            </select>
                        </div>
                        <div class="wrap-input100 validate-input">
                            <input class="input100" type="password" name="pass" placeholder="Password">
                        </div>
                        <div class="wrap-input100 validate-input">
                            <input class="input100" type="password" name="re_pass" placeholder="Repeat Password">
                        </div>
                        <div class="wrap-input100 validate-input">
                            <input class="input10" type="file" name="user_image">
                        </div>

                    <div class="container-login100-form-btn">
                        <button class="login100-form-btn">Sign Up</button>
                    </div>
                    <div class="text-center p-t-13">
                        <a class="txt2" href="index.php">Login if you have an account</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <script>
        $(document).ready(function() {
            $('#school_id').select2({
                placeholder: "Select or Search School",
                allowClear: true
            });
        });
    </script>
    	
<!--===============================================================================================-->	
<script src="st/vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="st/vendor/bootstrap/js/popper.js"></script>
	<script src="st/vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="st/vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="st/vendor/tilt/tilt.jquery.min.js"></script>
	<script >
		$('.js-tilt').tilt({
			scale: 1.1
		})
	</script>
<!--===============================================================================================-->
	<script src="st/js/main.js"></script>
        <script type="text/javascript">
    $(document).ready(function() {
        // Initialize Select2 on the school_id dropdown
        $('#school_id').select2({
            placeholder: "Select or Search School",
            allowClear: true // Allow the user to clear the selection
        });
    });
</script>
</body>
</html>
