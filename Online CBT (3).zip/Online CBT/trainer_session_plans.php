<style>
    .nav-link.activetd {
        background-color: rgba(3, 29, 54, 0.56);
        color: white;
    }
</style>
<?php
require 'header.php'; // Include header
require 'connection.php'; // Include database connection

// Automatically delete sessions rejected over 24 hours ago
$deleteQuery = "DELETE FROM session_plan WHERE sstatus = 'rejected' AND action_time < NOW() - INTERVAL 24 HOUR";
$conn->query($deleteQuery);

// Handle AJAX Request to Update Schema Status
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['session_id'])) {
    $session_id = $_POST['session_id'];
    $action = $_POST['action']; // Determine if approving or rejecting
    
    if ($action == "approve") {
        $updateQuery = "UPDATE session_plan SET sstatus = 'approved' WHERE session_id = ?";
    } elseif ($action == "reject") {
        $updateQuery = "UPDATE session_plan SET sstatus = 'rejected', action_time = NOW() WHERE session_id = ?";
    }
    
    $stmt = $conn->prepare($updateQuery);
    $stmt->bind_param("i", $session_id);
    
    if ($stmt->execute()) {
        echo json_encode(["status" => "success"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Failed to update."]);
    }
    exit;
}

// Pagination setup
$school = $_SESSION['school'];
$user = $_SESSION['user_id'];
$user_id_name = $_GET['trainer'];
$itemsPerPage = 12;
$currentPage = isset($_GET['page']) ? $_GET['page'] : 1;
$offset = ($currentPage - 1) * $itemsPerPage;

// Fetch data from the database
$sql = "SELECT session_plan.*, courses.course_name, courses.course_level 
        FROM session_plan 
        INNER JOIN courses ON session_plan.scourse_id = courses.course_id
        WHERE session_plan.sschl_id = '$school' 
        AND session_plan.suser_id = '$user_id_name'
        AND (sstatus = 'pending' OR sstatus = 'approved' OR sstatus = 'rejected' OR sstatus = 'none')
        ORDER BY session_plan.session_id DESC 
        LIMIT $itemsPerPage OFFSET $offset";
$result = $conn->query($sql);

// Total items count for pagination
$sqlCount = "SELECT COUNT(*) AS total_items FROM session_plan WHERE sschl_id = '$school'";
$countResult = $conn->query($sqlCount);
$row = $countResult->fetch_assoc();
$totalItems = $row['total_items'];
$totalPages = ceil($totalItems / $itemsPerPage);
?>

<div class="container mt-3">
    <h4 class="text-center mb-3">The Ongoing Trainer Session Plans</h4>
    <div class="row">
        <?php if ($result->num_rows > 0) : ?>
            <?php while ($row = $result->fetch_assoc()) : ?>
                <div class="col-md-4 mb-3">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Module: <strong><?php echo $row['course_name']; ?></strong></h5>
                            <p class="card-text">Level: <strong><?php echo $row['course_level']; ?></strong></p>
                            <p><a href="view_session_plan.php?session=<?= $row['session_doc'] ?>" target="_blank">View Session Plan</a></p>
                            
                            <?php if ($row['sstatus'] == 'none') : ?>
                                <button class="btn btn-warning col-lg-12 p-2">Waiting to be Generated</button>
                            <?php elseif ($row['sstatus'] == 'pending') : ?>
                                <button class="btn btn-primary approve-btn col-lg-12 p-2">
                                <i class="fa fa-spinner fa-spin"></i> Pending...   <i class="fa fa-check text-warning" style="margin-left: 10px;"></i> Approve It
                                </button>
                                <button class="btn btn-danger reject-btn col-lg-12 p-2">
                                    <i class="fa fa-times-circle "></i> Reject
                                </button>
                            <?php elseif ($row['sstatus'] == 'approved') : ?>
                                <button class="btn btn-success col-lg-12 p-2"><i class="fa fa-check-circle"></i> Approved</button>
                            <?php elseif ($row['sstatus'] == 'rejected') : ?>
                                <button class="btn btn-danger col-lg-12 p-2"><i class="fa fa-times-circle"></i> Rejected</button>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else : ?>
            <p class='text-center'>No Session Plan here.</p>
        <?php endif; ?>
    </div>

    <!-- Pagination Controls -->
    <nav>
        <ul class="pagination mt-3 justify-content-center">
            <?php for ($i = 1; $i <= $totalPages; $i++) : ?>
                <li class="page-item <?php echo ($i == $currentPage) ? 'active' : ''; ?>">
                    <a class="page-link" href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                </li>
            <?php endfor; ?>
        </ul>
    </nav>
</div>

<!-- Include jQuery, Bootstrap JS & SweetAlert -->
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
$(document).ready(function() {
    // Approve button functionality
    $(".approve-btn").click(function() {
        var sessionId = $(this).data("id");
        handleAction(sessionId, "approve", "Approve", "You are about to approve this session!");
    });
    
    // Reject button functionality
    $(".reject-btn").click(function() {
        var sessionId = $(this).data("id");
        handleAction(sessionId, "reject", "Reject", "You are about to reject this session!");
    });
});

function handleAction(sessionId, action, actionText, confirmationText) {
    Swal.fire({
        title: "Are you sure?",
        text: confirmationText,
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: action === "approve" ? "#28a745" : "#d33",
        cancelButtonColor: "#6c757d",
        confirmButtonText: `Yes, ${actionText} it!`
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                url: "", // The same file handles the request
                type: "POST",
                data: { session_id: sessionId, action: action },
                success: function(response) {
                    var result = JSON.parse(response);
                    if (result.status === "success") {
                        Swal.fire({
                            title: `${actionText}d!`,
                            text: `The session has been ${actionText.toLowerCase()}d successfully.`,
                            icon: "success",
                            timer: 3000,
                            showConfirmButton: false
                        }).then(() => {
                            location.reload();
                        });
                    } else {
                        Swal.fire("Error!", result.message, "error");
                    }
                }
            });
        }
    });
}
</script>

<?php require 'footer.php'; ?> 
