<?php
require 'header.php';
require 'connection.php';
?>

<div class="container mt-5">
    <div class="row">
        <div class="form-container col-lg-6 bg-white p-4">
            <h5>Fill this form to make <span class="text-primary">Dairy Plan</span></h5>
            <form action="submit_dairy_plan.php" method="POST" enctype="multipart/form-data">
                <?php
                $school = $_SESSION['school'];
                $user_id = $_SESSION['user_id'];
                ?>

                <input type="hidden" name="school_id" value="<?= $school ?>">
                <input type="hidden" name="user_id" value="<?= $user_id ?>">

                <div class="mb-3">
                    <label>Date</label>
                    <input type="date" name="date" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label>Start Time</label>
                    <input type="time" name="start_time" class="form-control" required>

                    <label>End Time</label>
                    <input type="time" name="end_time" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label>Trade</label>
                    <select name="trade" class="form-control" required>
                        <option value="">Select Trade</option>
                        <?php
                        $sql = mysqli_query($conn, "SELECT DISTINCT trade FROM courses WHERE user_id = '$user_id' AND schl_id = '$school'");
                        while ($row = mysqli_fetch_array($sql)) {
                            echo "<option value='{$row['trade']}'>{$row['trade']}</option>";
                        }
                        ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label>Level</label>
                    <select name="level" class="form-control" required>
                        <option value="3">Level 3</option>
                        <option value="4">Level 4</option>
                        <option value="5">Level 5</option>
                    </select>
                </div>

                <div class="mb-3">
                    <label>Course / Module Name</label>
                    <select name="course_id" class="form-control" required>
                        <option value="">Select Course Name</option>
                        <?php
                        $sql = mysqli_query($conn, "SELECT course_id, course_name FROM courses WHERE user_id = '$user_id' AND schl_id = '$school'");
                        while ($row = mysqli_fetch_array($sql)) {
                            echo "<option value='{$row['course_id']}'>{$row['course_name']}</option>";
                        }
                        ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label>Topic</label>
                    <input type="text" name="topic" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label>Activity (Main Content)</label>
                    <input type="text" name="activity" class="form-control" required>
                </div>

                <div class="mb-3">
                    <textarea name="application" rows="3" class="form-control" placeholder="Application"></textarea>
                </div>

                <div class="mb-3">
                    <textarea name="observation" rows="3" class="form-control" placeholder="Observation"></textarea>
                </div>

                <input type="hidden" name="academic_year" value="<?= mysqli_fetch_array(mysqli_query($conn, "SELECT academic_id FROM academic_year"))['academic_id'] ?>">

                <div class="smt-btn">
                    <input type="submit" class="btn btn-dark col-lg-12" value="Add Dairy Plan">
                </div>
            </form>
        </div>
    </div>
</div>

<?php require 'footer.php'; ?>
