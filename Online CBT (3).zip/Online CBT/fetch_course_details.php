<?php
require 'connection.php';

if (isset($_GET['course_id'])) {
    $course_id = $_GET['course_id'];
    
    $sql = "SELECT * FROM courses WHERE course_id = '$course_id'";
    $result = mysqli_query($conn, $sql);
    
    if ($course = mysqli_fetch_assoc($result)) {
        echo json_encode($course);
    } else {
        echo json_encode(null); // Course not found
    }
}
?>
