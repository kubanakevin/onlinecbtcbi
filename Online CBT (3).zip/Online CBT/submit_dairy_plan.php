<?php
require 'connection.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = $_POST['user_id'];
    $school_id = $_POST['school_id'];
    $date = $_POST['date'];
    $start_time = $_POST['start_time'];
    $end_time = $_POST['end_time'];
    $trade = $_POST['trade'];
    $level = $_POST['level'];
    $course_id = $_POST['course_id'];
    $topic = $_POST['topic'];
    $activity = $_POST['activity'];
    $application = $_POST['application'];
    $observation = $_POST['observation'];
    $academic_year = $_POST['academic_year'];

    $sql = "INSERT INTO dairy_plan (duser_id, school_id, date, start_time, end_time, trade, level, course_id, topic, activity, application, observation, academic_year)
            VALUES ('$user_id', '$school_id', '$date', '$start_time', '$end_time', '$trade', '$level', '$course_id', '$topic', '$activity', '$application', '$observation', '$academic_year')";

    if (mysqli_query($conn, $sql)) {
        echo "<script>
            alert('Dairy Plan added successfully!');
            window.location.href = 'class_dairy_plan.php';
        </script>";
    } else {
        echo "<script>
            alert('Unable to add Dairy Plan. Please try again.');
        </script>";
    }

    mysqli_close($conn);
}
?>
