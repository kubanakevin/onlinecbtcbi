<?php
require 'header.php';
require 'connection.php';

// Handle delete request with SweetAlert confirmation
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $sql = "DELETE FROM academic_year WHERE academic_id = '$id'";
    $delete = mysqli_query($conn, $sql);
    
    if ($delete) {
        echo "<script>
                Swal.fire({
                    title: 'Deleted!',
                    text: 'Academic year deleted successfully.',
                    icon: 'success',
                    timer: 3000,
                    showConfirmButton: false
                }).then(() => {
                    window.location.href='academic_year.php';
                });
              </script>";
    } else {
        echo "<script>
                Swal.fire({
                    title: 'Error!',
                    text: 'Failed to delete academic year.',
                    icon: 'error',
                    confirmButtonText: 'OK'
                });
              </script>";
    }
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $year = mysqli_real_escape_string($conn, $_POST['year']);
    $term = mysqli_real_escape_string($conn, $_POST['term']);
    $acuser_id = $_SESSION['user_id'];
    $academic_id = isset($_POST['academic_id']) ? $_POST['academic_id'] : '';
    
    if ($academic_id) {
        // Update existing record
        $query = "UPDATE academic_year SET year='$year', term='$term' WHERE academic_id='$academic_id'";
    } else {
        // Insert new record
        $query = "INSERT INTO academic_year (acuser_id, year, term) VALUES ('$acuser_id', '$year', '$term')";
    }
    
    if (mysqli_query($conn, $query)) {
        echo "<script>
                Swal.fire({
                    title: 'Success!',
                    text: 'Academic year saved successfully.',
                    icon: 'success',
                    timer: 3000,
                    showConfirmButton: false
                }).then(() => {
                    location.reload();
                });
              </script>";
    } else {
        echo "<script>
                Swal.fire({
                    title: 'Error!',
                    text: 'Failed to save academic year.',
                    icon: 'error',
                    confirmButtonText: 'OK'
                });
              </script>";
    }
}
?>

<style>
    .activetac {
        background-color: rgb(3, 29, 54);
        color: white;
    }
</style>

<div class="event text-right">
    <p class="p-t-13">
        <a href="#" data-toggle="modal" data-target="#addAcademicModal">
            <i class="fa fa-plus"></i> Add Academic
        </a>
    </p>
</div>

<!-- Modal Form -->
<div class="modal fade" id="addAcademicModal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Add/Edit Academic Year</h5>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <form id="academicForm" action="" method="POST">
                    <input type="hidden" name="academic_id" id="academic_id">
                    <div class="form-group">
                        <label>Academic Year</label>
                        <input type="text" name="year" id="year" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>Term</label>
                        <select name="term" id="term" class="form-control" required>
                            <option value="First Term">First Term</option>
                            <option value="Second Term">Second Term</option>
                            <option value="Third Term">Third Term</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary col-lg-12">Submit</button>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="row" style="overflow-x: scroll;">
    <table class="table table-hover table-bordered bg-white">
        <thead>
            <tr>
                <th>School Year</th>
                <th>Term</th>
                <th>Added By</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $sql = "SELECT * FROM academic_year JOIN users ON academic_year.acuser_id = users.user_id ORDER BY academic_id DESC";
            $select = mysqli_query($conn, $sql);
            while ($rows = mysqli_fetch_array($select)) {
            ?>
            <tr>
                <td><?=$rows['year']?></td>
                <td><?=$rows['term']?></td>
                <td><?=$rows['username']?></td>
                <td>
                    <a href="#" class="edit-btn" data-id="<?=$rows['academic_id']?>" data-year="<?=$rows['year']?>" data-term="<?=$rows['term']?>">
                        <i class="text-info fa fa-edit" style="font-size: 25px;margin-right: 10px"></i>
                    </a>
                    <a href="#" class="delete-btn" data-id="<?=$rows['academic_id']?>">
                        <i class="fa fa-trash text-danger" style="font-size: 25px;"></i>
                    </a>
                </td>
            </tr>
            <?php } ?>
        </tbody>
    </table>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
$(document).ready(function() {
    $('.edit-btn').click(function() {
        var id = $(this).data('id');
        var year = $(this).data('year');
        var term = $(this).data('term');
        
        $('#academic_id').val(id);
        $('#year').val(year);
        $('#term').val(term);
        $('#addAcademicModal').modal('show');
    });

    $('.delete-btn').click(function() {
        var id = $(this).data('id');
        Swal.fire({
            title: 'Are you sure?',
            text: 'You will not be able to recover this record!',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = 'academic_year.php?delete=' + id;
            }
        });
    });
});
</script>

<?php require 'footer.php'; ?>
