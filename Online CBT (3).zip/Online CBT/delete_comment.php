<?php
session_start();
include 'connection.php'; // Ensure database connection

header("Content-Type: application/json"); // JSON response format

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (!isset($_POST['comment_id'])) {
        echo json_encode(["status" => "error", "message" => "Comment ID is required."]);
        exit;
    }

    $commentId = intval($_POST['comment_id']); // Convert to integer for security

    // Delete the comment
    $stmt = $conn->prepare("DELETE FROM comments WHERE comment_id = ?");
    $stmt->bind_param("i", $commentId);

    if ($stmt->execute()) {
        echo json_encode(["status" => "success", "message" => "Comment deleted successfully."]);
    } else {
        echo json_encode(["status" => "error", "message" => "Failed to delete comment."]);
    }

    $stmt->close();
    $conn->close();
} else {
    echo json_encode(["status" => "error", "message" => "Invalid request method."]);
}
?>
