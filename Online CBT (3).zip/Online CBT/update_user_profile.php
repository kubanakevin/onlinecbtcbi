<?php
include('connection.php');
if (isset($_POST['save'])) {
    $id = $_POST['user_id'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $re_password = $_POST['re_password'];
    $nat_id = $_POST['nat_id'];
    $tel = $_POST['tel'];
    $degree = $_POST['degree'];
    $title = $_POST['title'];
    $user_image = $_FILES['user_image']['name']; // File name
    $user_image_tmp_name = $_FILES['user_image']['tmp_name']; // Temporary file name
    $user_image_folder = 'uploaded_file/' . $user_image; // Folder to store the file
    if (!empty($password) && $password !== $re_password) {
        echo "<script> alert('Passwords do not match. Please try again.')</script>";
        echo "<script> history.back()</script>";
        exit();
    }
    if (!empty($password)) {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $password_sql = "password='$hashed_password', "; // Include password in the SQL update
    } else {
        $password_sql = ''; // Do not include password in the SQL update
    }
    if (!empty($user_image)) {
        move_uploaded_file($user_image_tmp_name, $user_image_folder);
        $sql = "UPDATE users SET username='$username', email='$email', $password_sql nat_id='$nat_id', tel='$tel', degree='$degree', title='$title', user_image='$user_image' WHERE user_id='$id'";
    } else {
        $sql = "UPDATE users SET username='$username', email='$email', $password_sql nat_id='$nat_id', tel='$tel', degree='$degree', title='$title' WHERE user_id='$id'";
    }
    $result = mysqli_query($conn, $sql);
    if ($result) {
        header('location: user_profile.php');
    } else {
        echo "<script> alert('Failed to update user. Try again.')</script>";
        echo "<script> history.back()</script>";
    }
}
?>
<?php
include('header.php');
?>
<?php
include('connection.php');
$id = $_GET['user_id']; // Get user_id from URL

// Fetch the current user data based on user_id
$sql = "SELECT * FROM users WHERE user_id='$id'";
$select = mysqli_query($conn, $sql);
while ($rows = mysqli_fetch_array($select)) {
?>
<div class="row">
    <div class="form-container col-lg-6 bg-white" style="padding: 30px">
        <h5>User Information</h5>
        <!-- Profile Edit Form -->
        <form class="pt-3" action="" method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label for="">Username</label>
                <input type="hidden" name="user_id" value="<?=$rows['user_id']?>" />
                <input type="text" name="username" value="<?=$rows['username']?>" class="form-control" id="username">
            </div>
            <div class="form-group">
                <label for="">National ID</label>
                <input type="text" name="nat_id" value="<?=$rows['nat_id']?>" class="form-control" id="nat_id">
            </div>
            <div class="form-group">
                <label for="">Telephone</label>
                <input type="text" name="tel" value="<?=$rows['tel']?>" class="form-control" id="tel">
            </div>
            <div class="form-group">
                <label for="">Degree</label>
                <input type="text" name="degree" value="<?=$rows['degree']?>" class="form-control" id="degree">
            </div>
            <div class="form-group">
                <label for="">Title</label>
                <input type="text" name="title" value="<?=$rows['title']?>" class="form-control" id="title">
            </div>
            <div class="form-group">
                <label for="">Email</label>
                <input type="text" name="email" value="<?=$rows['email']?>" class="form-control" id="email">
            </div>
            <div class="form-group">
                <label for="">Password</label>
                <input type="password" name="password" value="" class="form-control" id="password">
            </div>
            <div class="form-group">
                <label for="">Password</label>
                <input type="password" name="re_password" value="" class="form-control" id="password">
            </div>
            <div class="form-group">
                <label for="">User Image</label>
                <input type="file" name="user_image" class="form-control" id="user_image" accept="image/png, image/jpg, image/jpeg" >
            </div>
            <div class="mt-3 d-grid gap-2">
                <input type="submit" value="Save changes" name="save" class="btn btn-info btn-lg font-weight-medium auth-form-btn">
                <a href="user_profile.php" class="btn btn-danger btn-lg font-weight-medium auth-form-btn" style="margin-left: 20px">Cancel</a>
            </div>
        </form>
    </div>
</div>
<?php
}
require 'footer.php';
?>
