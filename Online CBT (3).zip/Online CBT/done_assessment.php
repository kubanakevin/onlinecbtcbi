<?php
require 'connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get assessment ID from POST data
    $assessmentId = $_POST['assessment_id'];

    // Update the assessment plan to 'done'
    $query = "UPDATE assessment_plan SET on_status = 'done' WHERE assessment_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $assessmentId);

    if ($stmt->execute()) {
        // Success response
        echo json_encode(['success' => true]);
    } else {
        // Error response
        echo json_encode(['success' => false]);
    }
}
?>
