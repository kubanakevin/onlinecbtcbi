<?php
require 'header.php';
?>
<style>
    td{
        font-size: 10px;
    }
</style>
 
<div class="row">
        <div class="ms-3 text-left col-12">
          
        </div>
        <div class="col-xl-12 col-sm-12 mb-xl-0 mb-4">
          <div class="card">
            <div class="card-header p-2 ps-3">
              <div class="d-flex justify-content-between">
                <div>
                <!-- <span class=" btn btn-success" style="color: white"><a href=""><i class="fa fa-eye"></i> View All Reports</a></span> -->
                <!-- <span class="btn btn-primary"><i class="fa fa-eye"></i> View All Reports</span> -->
                  <h4 class="mb-0">
                    </h4>
                </div>
                <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.9.2/html2pdf.bundle.js"></script>
                <div class="icon icon-md icon-shape bg-gradient-dark shadow-dark shadow text-center border-radius-lg" onclick="downloadTableAsPDF()">
                    <i class="material-symbols-rounded opacity-10" style="cursor: pointer;">download</i>
                </div>
              </div>
            </div>
            <hr class="dark horizontal my-0">
            <div class="card-footer p-2 ps-3">
              <table border="1" class="table table-hover table-bordered bg-white" id="sampleTable" style="overflow-x: scroll;">
              <script>
                    function downloadTableAsPDF() {
                        var element = document.getElementById("sampleTable");
                        html2pdf(element);
                    }
                </script>
              <?php
                require 'connection.php';
                $school = $_SESSION['school'];
                $user_id = $_SESSION['user_id'];
                $trainer = $_GET['trainer'];
                $sql = "SELECT * FROM checklist, users, schools, courses 
                WHERE checklist.usr_id = users.user_id 
                AND checklist.schol_id = schools.school_id 
                AND checklist.course_id = courses.course_id 
                AND school = '$school' 
                AND list_id = '$trainer' 
                ORDER BY list_id DESC "; // Updated query here

                // $sql = "SELECT * FROM checklist,users,schools,courses WHERE checklist.user_id = users.user_id AND checklist.schol_id = schools.school_id AND checklist.course_id = courses.course_id AND school = '$school' ORDER BY list_id DESC "; // Updated query here
                $select = mysqli_query($conn, $sql);
                while ($rows = mysqli_fetch_array($select)) {
                ?>
                <tr>
                    <td class="text-right" colspan="9" style="padding-right: 4rem;">
                        <img src="images/icon.png" alt="" style="width: 4rem;">
                    </td>
                </tr>
                <tr>
                    <td colspan="9"><span class="col-lg-4">Trainer Name: <b><?=$rows['username']?></b></span>  <span class="col-lg-4">Date: <b><?=$rows['date']?></b></span>  <span class="col-lg-4">Period: <b> <?=$rows['period']?></b></span> </td>
                </tr>
                <tr>
                    <td colspan="9"><span class="col-lg-4">Trade: <b><?=$rows['trade']?></b> </span> <span class="col-lg-4">Level: <b><?=$rows['level']?></b></span> <span class="col-lg-4">Number of Trainees: <b><?=$rows['no_trainees']?></b></span></td>
                </tr>
                <tr>
                    <td colspan="9"><span style="font-weight: bold;font-size: large">Module Conduct During Class : </span> <span><?=$rows['mcdco']?></span><br>
                    <span style="font-weight: bold;font-size: large"><u>Topic of the Session:</u></span> <span> <?=$rows['topic']?></span>
                </td>
                </tr>
                <tr style="background: #949494a2;color: #000;" class="text-dark">
                    <td>Creteria</td>
                    <td>Indicator/Observation</td>
                    <td>0 <br> <span style="font-size: 8px;">Not Available</span></td>
                    <td>1 <br> <span style="font-size: 8px;">Very Poor</span></td>
                    <td>2 <br> <span style="font-size: 8px;">Poor</span></td>
                    <td>3 <br> <span style="font-size: 8px;">Good</span></td>
                    <td>4 <br> <span style="font-size: 8px;">Very Good</span></td>
                    <td>5 <br> <span style="font-size: 8px;">Excellent</span></td>
                    <td>Observation</td>
                </tr>
                <tr>
                    <td rowspan="4">Pedagogical Documents</td>
                    <td>Schema Of Work is respected</td>
                    <td>
                        <?php
                        if ($rows['sowr'] == 0) {
                            echo "<i class='fa fa-check text-danger' class='font-size: 20px'></i>";
                        } else {
                            echo "";
                        }
                        ?>
                    </td>
                    <td>
                        <?php
                        if ($rows['sowr'] == 1) {
                            echo "<i class='fa fa-check text-danger' class='font-size: 20px'></i>";
                        } else {
                            echo "";
                        }
                        ?>
                    </td>
                    <td>
                        <?php
                        if ($rows['sowr'] == 2) {
                            echo "<i class='fa fa-check text-danger' class='font-size: 20px'></i>";
                        } else {
                            echo "";
                        }
                        ?>
                    </td>
                    <td>
                        <?php
                        if ($rows['sowr'] == 3) {
                            echo "<i class='fa fa-check text-warning' class='font-size: 20px'></i>";
                        } else {
                            echo "";
                        }
                        ?>
                    </td>
                    <td>
                        <?php
                        if ($rows['sowr'] == 4) {
                            echo "<i class='fa fa-check text-primary' class='font-size: 20px'></i>";
                        } else {
                            echo "";
                        }
                        ?>
                    </td>
                    <td>
                        <?php
                        if ($rows['sowr'] == 5) {
                            echo "<i class='fa fa-check text-success' class='font-size: 20px'></i>";
                        } else {
                            echo "";
                        }
                        ?>
                    </td>
                    <td></td>
                </tr>
                <tr>
                    <td>Session plan is available and effectively followed</td>
                    <td>
                        <?php
                        if ($rows['spaef'] == 0) {
                            echo "<i class='fa fa-check text-danger' class='font-size: 20px'></i>";
                        } else {
                            echo "";
                        }
                        ?>
                    </td>
                    <td>
                        <?php
                        if ($rows['spaef'] == 1) {
                            echo "<i class='fa fa-check text-danger' class='font-size: 20px'></i>";
                        } else {
                            echo "";
                        }
                        ?>
                    </td>
                    <td>
                        <?php
                        if ($rows['spaef'] == 2) {
                            echo "<i class='fa fa-check text-danger' class='font-size: 20px'></i>";
                        } else {
                            echo "";
                        }
                        ?>
                    </td>
                    <td>
                        <?php
                        if ($rows['spaef'] == 3) {
                            echo "<i class='fa fa-check text-warning' class='font-size: 20px'></i>";
                        } else {
                            echo "";
                        }
                        ?>
                    </td>
                    <td>
                        <?php
                        if ($rows['spaef'] == 4) {
                            echo "<i class='fa fa-check text-primary' class='font-size: 20px'></i>";
                        } else {
                            echo "";
                        }
                        ?>
                    </td>
                    <td>
                        <?php
                        if ($rows['spaef'] == 5) {
                            echo "<i class='fa fa-check  text-success' class='font-size: 20px'></i>";
                        } else {
                            echo "";
                        }
                        ?>
                    </td>
                    <td></td>
                </tr>
                <tr>
                    <td>Class Daily is available and up to time</td>
                    <td>
                        <?php
                        if ($rows['cdau'] == 0) {
                            echo "<i class='fa fa-check text-danger' class='font-size: 20px'></i>";
                        } else {
                            echo "";
                        }
                        ?>
                    </td>
                    <td>
                        <?php
                        if ($rows['cdau'] == 1) {
                            echo "<i class='fa fa-check text-danger' class='font-size: 20px'></i>";
                        } else {
                            echo "";
                        }
                        ?>
                    </td>
                    <td>
                        <?php
                        if ($rows['cdau'] == 2) {
                            echo "<i class='fa fa-check text-danger' class='font-size: 20px'></i>";
                        } else {
                            echo "";
                        }
                        ?>
                    </td>
                    <td>
                        <?php
                        if ($rows['cdau'] == 3) {
                            echo "<i class='fa fa-check text-warning' class='font-size: 20px'></i>";
                        } else {
                            echo "";
                        }
                        ?>
                    </td>
                    <td>
                        <?php
                        if ($rows['cdau'] == 4) {
                            echo "<i class='fa fa-check text-primary' class='font-size: 20px'></i>";
                        } else {
                            echo "";
                        }
                        ?>
                    </td>
                    <td>
                        <?php
                        if ($rows['cdau'] == 5) {
                            echo "<i class='fa fa-check text-success' class='font-size: 20px'></i>";
                        } else {
                            echo "";
                        }
                        ?>
                    </td>
                    <td></td>
                </tr>
                <tr>
                    <td>Class Attendance list is effectively used</td>
                    <td>
                        <?php
                        if ($rows['caleu'] == 0) {
                            echo "<i class='fa fa-check  text-danger' class='font-size: 20px'></i>";
                        } else {
                            echo "";
                        }
                        ?>
                    </td>
                    <td>
                        <?php
                        if ($rows['caleu'] == 1) {
                            echo "<i class='fa fa-check text-danger' class='font-size: 20px'></i>";
                        } else {
                            echo "";
                        }
                        ?>
                    </td>
                    <td>
                        <?php
                        if ($rows['caleu'] == 2) {
                            echo "<i class='fa fa-check text-danger' class='font-size: 20px'></i>";
                        } else {
                            echo "";
                        }
                        ?>
                    </td>
                    <td>
                        <?php
                        if ($rows['caleu'] == 3) {
                            echo "<i class='fa fa-check text-warning' class='font-size: 20px'></i>";
                        } else {
                            echo "";
                        }
                        ?>
                    </td>
                    <td>
                        <?php
                        if ($rows['caleu'] == 4) {
                            echo "<i class='fa fa-check text-primary' class='font-size: 20px'></i>";
                        } else {
                            echo "";
                        }
                        ?>
                    </td>
                    <td>
                        <?php
                        if ($rows['caleu'] == 5) {
                            echo "<i class='fa fa-check text-success' class='font-size: 20px'></i>";
                        } else {
                            echo "";
                        }
                        ?>
                    </td>
                    <td></td>
                </tr>
                <tr>
                    <td rowspan="7">Pedagogical Documents</td>
                    <td>Trainer masters the subject by <br> providing clear explanations</td>
                    <td>
                        <?php
                        if ($rows['tmsbpcetrewa'] == 0) {
                            echo "<i class='fa fa-check text-danger' class='font-size: 20px'></i>";
                        } else {
                            echo "";
                        }
                        ?>
                    </td>
                    <td>
                        <?php
                        if ($rows['tmsbpcetrewa'] == 1) {
                            echo "<i class='fa fa-check text-danger' class='font-size: 20px'></i>";
                        } else {
                            echo "";
                        }
                        ?>
                    </td>
                    <td>
                        <?php
                        if ($rows['tmsbpcetrewa'] == 2) {
                            echo "<i class='fa fa-check text-danger' class='font-size: 20px'></i>";
                        } else {
                            echo "";
                        }
                        ?>
                    </td>
                    <td>
                        <?php
                        if ($rows['tmsbpcetrewa'] == 3) {
                            echo "<i class='fa fa-check text-warning' class='font-size: 20px'></i>";
                        } else {
                            echo "";
                        }
                        ?>
                    </td>
                    <td>
                        <?php
                        if ($rows['tmsbpcetrewa'] == 4) {
                            echo "<i class='fa fa-check text-primary' class='font-size: 20px'></i>";
                        } else {
                            echo "";
                        }
                        ?>
                    </td>
                    <td>
                        <?php
                        if ($rows['tmsbpcetrewa'] == 5) {
                            echo "<i class='fa fa-check text-success' class='font-size: 20px'></i>";
                        } else {
                            echo "";
                        }
                        ?>
                    </td>
                    <td></td>
                </tr>
                <tr>
                    <td>Facilitation techniques (Variation, <br> Relevance, Quality of Handling  questions) is applied</td>
                    <td>
                        <?php
                        if ($rows['fta'] == 0) {
                            echo "<i class='fa fa-check text-danger' class='font-size: 20px'></i>";
                        } else {
                            echo "";
                        }
                        ?>
                    </td>
                    <td>
                        <?php
                        if ($rows['fta'] == 1) {
                            echo "<i class='fa fa-check text-danger' class='font-size: 20px'></i>";
                        } else {
                            echo "";
                        }
                        ?>
                    </td>
                    <td>
                        <?php
                        if ($rows['fta'] == 2) {
                            echo "<i class='fa fa-check text-danger' class='font-size: 20px'></i>";
                        } else {
                            echo "";
                        }
                        ?>
                    </td>
                    <td>
                        <?php
                        if ($rows['fta'] == 3) {
                            echo "<i class='fa fa-check text-warning' class='font-size: 20px'></i>";
                        } else {
                            echo "";
                        }
                        ?>
                    </td>
                    <td>
                        <?php
                        if ($rows['fta'] == 4) {
                            echo "<i class='fa fa-check text-primary' class='font-size: 20px'></i>";
                        } else {
                            echo "";
                        }
                        ?>
                    </td>
                    <td>
                        <?php
                        if ($rows['fta'] == 5) {
                            echo "<i class='fa fa-check text-success' class='font-size: 20px'></i>";
                        } else {
                            echo "";
                        }
                        ?>
                    </td>
                    <td></td>
                </tr>
                <tr>
                    <td>Teaching aids are used (Variation, <br> Relevance, Quality, Effectiveness)</td>
                    <td>
                        <?php
                        if ($rows['taau'] == 0) {
                            echo "<i class='fa fa-check text-danger' class='font-size: 20px'></i>";
                        } else {
                            echo "";
                        }
                        ?>
                    </td>
                    <td>
                        <?php
                        if ($rows['taau'] == 1) {
                            echo "<i class='fa fa-check text-danger' class='font-size: 20px'></i>";
                        } else {
                            echo "";
                        }
                        ?>
                    </td>
                    <td>
                        <?php
                        if ($rows['taau'] == 2) {
                            echo "<i class='fa fa-check text-danger' class='font-size: 20px'></i>";
                        } else {
                            echo "";
                        }
                        ?>
                    </td>
                    <td>
                        <?php
                        if ($rows['taau'] == 3) {
                            echo "<i class='fa fa-check text-warning' class='font-size: 20px'></i>";
                        } else {
                            echo "";
                        }
                        ?>
                    </td>
                    <td>
                        <?php
                        if ($rows['taau'] == 4) {
                            echo "<i class='fa fa-check text-primary' class='font-size: 20px'></i>";
                        } else {
                            echo "";
                        }
                        ?>
                    </td>
                    <td>
                        <?php
                        if ($rows['taau'] == 5) {
                            echo "<i class='fa fa-check text-success' class='font-size: 20px'></i>";
                        } else {
                            echo "";
                        }
                        ?>
                    </td>
                    <td></td>
                </tr>
                <tr>
                    <td>Didactic materials are used <br>(Variation, Relevance, Quality, Effectiveness)</td>
                    <td>
                        <?php
                        if ($rows['dmau'] == 0) {
                            echo "<i class='fa fa-check text-danger' class='font-size: 20px'></i>";
                        } else {
                            echo "";
                        }
                        ?>
                    </td>
                    <td>
                        <?php
                        if ($rows['dmau'] == 1) {
                            echo "<i class='fa fa-check text-danger' class='font-size: 20px'></i>";
                        } else {
                            echo "";
                        }
                        ?>
                    </td>
                    <td>
                        <?php
                        if ($rows['dmau'] == 2) {
                            echo "<i class='fa fa-check text-danger' class='font-size: 20px'></i>";
                        } else {
                            echo "";
                        }
                        ?>
                    </td>
                    <td>
                        <?php
                        if ($rows['dmau'] == 3) {
                            echo "<i class='fa fa-check text-warning' class='font-size: 20px'></i>";
                        } else {
                            echo "";
                        }
                        ?>
                    </td>
                    <td>
                        <?php
                        if ($rows['dmau'] == 4) {
                            echo "<i class='fa fa-check text-primary' class='font-size: 20px'></i>";
                        } else {
                            echo "";
                        }
                        ?>
                    </td>
                    <td>
                        <?php
                        if ($rows['dmau'] == 5) {
                            echo "<i class='fa fa-check text-success' class='font-size: 20px'></i>";
                        } else {
                            echo "";
                        }
                        ?>
                    </td>
                    <td></td>
                </tr>
                <tr>
                    <td>Trainer's Self-presentation (proper <br> work attire, language, body language)</td>
                    <td>
                        <?php
                        if ($rows['tsp'] == 0) {
                            echo "<i class='fa fa-check text-danger' class='font-size: 20px'></i>";
                        } else {
                            echo "";
                        }
                        ?>
                    </td>
                    <td>
                        <?php
                        if ($rows['tsp'] == 1) {
                            echo "<i class='fa fa-check text-danger' class='font-size: 20px'></i>";
                        } else {
                            echo "";
                        }
                        ?>
                    </td>
                    <td>
                        <?php
                        if ($rows['tsp'] == 2) {
                            echo "<i class='fa fa-check text-danger' class='font-size: 20px'></i>";
                        } else {
                            echo "";
                        }
                        ?>
                    </td>
                    <td>
                        <?php
                        if ($rows['tsp'] == 3) {
                            echo "<i class='fa fa-check text-warning' class='font-size: 20px'></i>";
                        } else {
                            echo "";
                        }
                        ?>
                    </td>
                    <td>
                        <?php
                        if ($rows['tsp'] == 4) {
                            echo "<i class='fa fa-check text-primary' class='font-size: 20px'></i>";
                        } else {
                            echo "";
                        }
                        ?>
                    </td>
                    <td>
                        <?php
                        if ($rows['tsp'] == 5) {
                            echo "<i class='fa fa-check text-success' class='font-size: 20px'></i>";
                        } else {
                            echo "";
                        }
                        ?>
                    </td>
                    <td></td>
                </tr>
                <tr>
                    <td>Class is well managed (Handling <br> interruptions)</td>
                    <td>
                        <?php
                        if ($rows['ciwm'] == 0) {
                            echo "<i class='fa fa-check text-danger' class='font-size: 20px'></i>";
                        } else {
                            echo "";
                        }
                        ?>
                    </td>
                    <td>
                        <?php
                        if ($rows['ciwm'] == 1) {
                            echo "<i class='fa fa-check text-danger' class='font-size: 20px'></i>";
                        } else {
                            echo "";
                        }
                        ?>
                    </td>
                    <td>
                        <?php
                        if ($rows['ciwm'] == 2) {
                            echo "<i class='fa fa-check text-danger' class='font-size: 20px'></i>";
                        } else {
                            echo "";
                        }
                        ?>
                    </td>
                    <td>
                        <?php
                        if ($rows['ciwm'] == 3) {
                            echo "<i class='fa fa-check text-warning' class='font-size: 20px'></i>";
                        } else {
                            echo "";
                        }
                        ?>
                    </td>
                    <td>
                        <?php
                        if ($rows['ciwm'] == 4) {
                            echo "<i class='fa fa-check text-primary' class='font-size: 20px'></i>";
                        } else {
                            echo "";
                        }
                        ?>
                    </td>
                    <td>
                        <?php
                        if ($rows['ciwm'] == 5) {
                            echo "<i class='fa fa-check text-success' class='font-size: 20px'></i>";
                        } else {
                            echo "";
                        }
                        ?>
                    </td>
                    <td></td>
                </tr>
                <tr>
                    <td>Learning environment is conducive <br>(Organization, Safety, cleanliness)</td>
                    <td>
                        <?php
                        if ($rows['leic'] == 0) {
                            echo "<i class='fa fa-check text-danger' class='font-size: 20px'></i>";
                        } else {
                            echo "";
                        }
                        ?>
                    </td>
                    <td>
                        <?php
                        if ($rows['leic'] == 1) {
                            echo "<i class='fa fa-check text-danger' class='font-size: 20px'></i>";
                        } else {
                            echo "";
                        }
                        ?>
                    </td>
                    <td>
                        <?php
                        if ($rows['leic'] == 2) {
                            echo "<i class='fa fa-check text-danger' class='font-size: 20px'></i>";
                        } else {
                            echo "";
                        }
                        ?>
                    </td>
                    <td>
                        <?php
                        if ($rows['leic'] == 3) {
                            echo "<i class='fa fa-check text-warning' class='font-size: 20px'></i>";
                        } else {
                            echo "";
                        }
                        ?>
                    </td>
                    <td>
                        <?php
                        if ($rows['leic'] == 4) {
                            echo "<i class='fa fa-check text-primary' class='font-size: 20px'></i>";
                        } else {
                            echo "";
                        }
                        ?>
                    </td>
                    <td>
                        <?php
                        if ($rows['leic'] == 5) {
                            echo "<i class='fa fa-check text-success' class='font-size: 20px'></i>";
                        } else {
                            echo "";
                        }
                        ?>
                    </td>
                    <td></td>
                </tr>
                <tr>
                    <td colspan="2" class="text-right">Sub/Total</td>
                    <td colspan="6" class="text-center">
                    <?php
                    $total = $rows['sowr'] + $rows['spaef'] + $rows['cdau'] + $rows['caleu'] + $rows['tmsbpcetrewa'] + $rows['fta'] + $rows['taau'] + $rows['dmau'] + $rows['tsp'] + $rows['ciwm'] + $rows['leic'];
                    echo $total;
                    ?></td>
                    <?php

                    $total = $rows['sowr'] + $rows['spaef'] + $rows['cdau'] + $rows['caleu'] + $rows['tmsbpcetrewa'] + $rows['fta'] + $rows['taau'] + $rows['dmau'] + $rows['tsp'] + $rows['ciwm'] + $rows['leic'];
                    if ($total >= 0 && $total <= 21) {
                        echo "<td class='bg-danger text-dark'>$total/55</td>";
                    }elseif ($total >= 22 && $total <= 32) {
                        echo "<td class='bg-warning text-dark'>$total/55</td>";
                    }elseif ($total >= 33 && $total <= 43) {
                        echo "<td class='bg-info text-dark'>$total/55</td>";
                    }elseif ($total >= 44 && $total <= 55) {
                        echo "<td class='bg-success text-dark'>$total/55</td>";
                    }
                    ?>
                </tr>
                <tr>
                    <td colspan="8" class="text-right"> Average (Sum of all rate/number of Indicators)</td>
                    <?php
                    $avg_sum = $rows['sowr'] + $rows['spaef'] + $rows['cdau'] + $rows['caleu'] + $rows['tmsbpcetrewa'] + $rows['fta'] + $rows['taau'] + $rows['dmau'] + $rows['tsp'] + $rows['ciwm'] + $rows['leic'] / 11;
                    if ($avg_sum >= 0 && $avg_sum <= 21) {
                        echo "<td class='bg-danger text-dark'>$avg_sum / 55</td>";
                    }elseif ($avg_sum >= 22 && $avg_sum <= 32) {
                        echo "<td class='bg-warning text-dark'>$avg_sum / 55</td>";
                    }elseif ($avg_sum >= 33 && $avg_sum <= 43) {
                        echo "<td class='bg-info text-dark'>$avg_sum / 55</td>";
                    }elseif ($avg_sum >= 44 && $avg_sum <= 54) {
                        echo "<td class='bg-success text-dark'>$avg_sum / 55</td>";
                    }
                    ?>
                </tr>
                <tr>
                    <td colspan="9">Strong Point: <b><?=$rows['strong_point']?></b></td>
                </tr>
                <tr>
                    <td colspan="9">Area of Improvement: <b><?=$rows['area_of_improv']?></b></td>
                </tr>
                <tr>
                    <td colspan="9">
                        <?php
                        if ($total >= 0 && $total <= 21) {
                            // echo "<span class='col-lg-3'>Note: 0-21: Very poor <i class='fa fa-chech-square-o'></span>";
                            ?>
                            <span class="col-lg-3">Note: 0-21: Very poor </span> <span class="col-lg-3">22-32: Poor </span> <span class="col-lg-3">33-43: Good </span>
                    <span class="col-lg-3"> 44-54: Very Good </span> <span class="col-lg-3"> 55: Excellent </span>  <br>
                    <span class="col-lg-3">General Observarion: Very poor <i class="fa fa-check-square-o" style="font-size: large;"></i></span> 
                    <span class="col-lg-3">Poor <i class="fa fa-square-o" style="font-size: large;"></i></span>
                    <span class="col-lg-3">Good <i class="fa fa-square-o" style="font-size: large;"></i></span>
                    <span class="col-lg-3">Very Good <i class="fa fa-square-o" style="font-size: large;"></i></span>
                    <span class="col-lg-3">Excellent <i class="fa fa-square-o" style="font-size: large;"></i></span>
                            <?php
                        }elseif ($total >= 22 && $total <= 32) {
                            // echo "<span class='col-lg-3'>Note: 22-32: Poor <i class='fa fa-check-square-o'></span>"; 
                            ?>
                            <span class="col-lg-3">Note: 0-21: Very poor </span> <span class="col-lg-3">22-32: Poor </span> <span class="col-lg-3">33-43: Good </span>
                    <span class="col-lg-3"> 44-54: Very Good </span> <span class="col-lg-3"> 55: Excellent </span>  <br>
                    <span class="col-lg-3">General Observarion: Very poor <i class="fa fa-square-o" style="font-size: large;"></i></span> 
                    <span class="col-lg-3">Poor <i class="fa fa-check-square-o" style="font-size: large;"></i></span>
                    <span class="col-lg-3">Good <i class="fa fa-square-o" style="font-size: large;"></i></span>
                    <span class="col-lg-3">Very Good <i class="fa fa-square-o" style="font-size: large;"></i></span>
                    <span class="col-lg-3">Excellent <i class="fa fa-square-o" style="font-size: large;"></i></span>
                            <?php
                        }elseif ($total >= 33 && $total <= 43) {
                            ?>
                            <span class="col-lg-3">Note: 0-21: Very poor </span> <span class="col-lg-3">22-32: Poor </span> <span class="col-lg-3">33-43: Good </span>
                    <span class="col-lg-3"> 44-54: Very Good </span> <span class="col-lg-3"> 55: Excellent </span>  <br>
                    <span class="col-lg-3">General Observarion: Very poor <i class="fa fa-square-o" style="font-size: large;"></i></span> 
                    <span class="col-lg-3">Poor <i class="fa fa-square-o" style="font-size: large;"></i></span>
                    <span class="col-lg-3">Good <i class="fa fa-check-square-o" style="font-size: large;"></i></span>
                    <span class="col-lg-3">Very Good <i class="fa fa-square-o" style="font-size: large;"></i></span>
                    <span class="col-lg-3">Excellent <i class="fa fa-square-o" style="font-size: large;"></i></span>
                    <?php
                        }elseif ($total >= 44 && $total <= 54) {
                            ?>
                            <span class="col-lg-3">Note: 0-21: Very poor </span> <span class="col-lg-3">22-32: Poor </span> <span class="col-lg-3">33-43: Good </span>
                    <span class="col-lg-3"> 44-54: Very Good </span> <span class="col-lg-3"> 55: Excellent </span>  <br>
                    <span class="col-lg-3">General Observarion: Very poor <i class="fa fa-square-o" style="font-size: large;"></i></span> 
                    <span class="col-lg-3">Poor <i class="fa fa-square-o" style="font-size: large;"></i></span>
                    <span class="col-lg-3">Good <i class="fa fa-square-o" style="font-size: large;"></i></span>
                    <span class="col-lg-3">Very Good <i class="fa fa-check-square-o" style="font-size: large;"></i></span>
                    <span class="col-lg-3">Excellent <i class="fa fa-square-o" style="font-size: large;"></i></span>
                            <?php
                        }elseif ($total == 55) {
                            ?>
                            <span class="col-lg-3">Note: 0-21: Very poor </span> <span class="col-lg-3">22-32: Poor </span> <span class="col-lg-3">33-43: Good </span>
                    <span class="col-lg-3"> 44-54: Very Good </span> <span class="col-lg-3"> 55: Excellent </span>  <br>
                    <span class="col-lg-3">General Observarion: Very poor <i class="fa fa-square-o" style="font-size: large;"></i></span> 
                    <span class="col-lg-3">Poor <i class="fa fa-square-o" style="font-size: large;"></i></span>
                    <span class="col-lg-3">Good <i class="fa fa-square-o" style="font-size: large;"></i></span>
                    <span class="col-lg-3">Very Good <i class="fa fa-square-o" style="font-size: large;"></i></span>
                    <span class="col-lg-3">Excellent <i class="fa fa-check-square-o" style="font-size: large;"></i></span>
                            <?php
                        }
                        ?>
                        
                </td>
                </tr>
                <tr>
                    <td colspan="9">
                        <span class="col-lg-12">Trainer Comment: 
                    </td></span>
                </tr>
                <tr>
                    <td colspan="9"><hr style="border: 4px solid black;"> <br><br><br></td>
                </tr>
                <?php
                }
                ?>
                
              </table>
            </div>
          </div>
        </div>
<?php
require 'footer.php';
?>