<?php
require 'header.php'; // Include header
require 'connection.php'; // Include database connection

// Handle AJAX Request to Update Schema Status
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['session_id'])) {
    $session_id = $_POST['session_id'];

    // Update the session_plan table
    $updateQuery = "UPDATE session_plan SET sstatus = 'pending' WHERE session_id = ?";
    $stmt = $conn->prepare($updateQuery);
    $stmt->bind_param("i", $session_id);
    
    if ($stmt->execute()) {
        echo json_encode(["status" => "success"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Failed to update."]);
    }
    exit;
}

// Pagination setup
$school = $_SESSION['school'];
$user = $_SESSION['user_id'];
$itemsPerPage = 12; // Number of items per page
$currentPage = isset($_GET['page']) ? $_GET['page'] : 1; // Current page number
$offset = ($currentPage - 1) * $itemsPerPage; // Offset for database query

// Fetch data from the database
$sql = "SELECT session_plan.*, courses.course_name, courses.course_level 
        FROM session_plan 
        INNER JOIN courses ON session_plan.scourse_id = courses.course_id
        WHERE session_plan.sschl_id = '$school' 
        AND session_plan.suser_id = '$user' 
        AND session_plan > 0
        ORDER BY session_plan.session_id DESC 
        LIMIT $itemsPerPage OFFSET $offset";
$result = $conn->query($sql);

// Total items count for pagination
$sqlCount = "SELECT COUNT(*) AS total_items FROM session_plan WHERE sschl_id = '$school' AND suser_id = '$user'";
$countResult = $conn->query($sqlCount);
$row = $countResult->fetch_assoc();
$totalItems = $row['total_items'];
$totalPages = ceil($totalItems / $itemsPerPage);
?>
<style>
    .activewith {
        background-color: rgba(3, 29, 54, 0.56);
        color: white;
    }
</style>
<div class="container mt-3">
    <h4>Modules With Session Plan</h4>
    <div class="row">
        <?php if ($result->num_rows > 0) : ?>
            <?php while ($row = $result->fetch_assoc()) : 
            $fileName = $row['session_doc'];
            $fileNameLimited = substr($fileName, 0, 20); // Limit file name to 10 characters
                 ?>
                <div class="col-md-4 mb-3">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Module Name: <strong><?php echo $row['course_name']; ?></strong></h5>
                            <p class="card-text">Level: <strong><?php echo $row['course_level']; ?></strong></p>
                            <p><a href="view_session_plan.php?session=<?=$row['session_doc']?>" target="_blank"><?=$fileNameLimited?></a></p>
                            <?php if ($row['sstatus'] == 'none') : ?>
                                <button class="btn btn-warning generate-btn col-lg-12 p-2" data-id="<?php echo $row['session_id']; ?>">
                                    <i class="fa fa-plus-circle"></i> Generate
                                </button>
                            <?php elseif ($row['sstatus'] == 'pending') : ?>
                                <button class="btn btn-primary col-lg-12 p-2">
                                    <i class="fa fa-spinner fa-spin"></i> Pending...
                                </button>
                            <?php elseif ($row['sstatus'] == 'approved') : ?>
                                <button class="btn btn-success col-lg-12 p-2">
                                    <i class="fa fa-check-circle"></i> Approved
                                </button>
                            <?php elseif ($row['sstatus'] == 'rejected') : ?>
                                <button class="btn btn-danger col-lg-12"><i class="fa fa-times-circle"></i> Rejected</button>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else : ?>
            <p class='text-center'>No Data found.</p>
        <?php endif; ?>
    </div>

    <!-- Pagination Controls -->
    <nav>
        <ul class="pagination mt-3 justify-content-center">
            <?php for ($i = 1; $i <= $totalPages; $i++) : ?>
                <li class="page-item <?php echo ($i == $currentPage) ? 'active' : ''; ?>">
                    <a class="page-link" href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                </li>
            <?php endfor; ?>
        </ul>
    </nav>
</div>

<!-- Include jQuery, Bootstrap JS & SweetAlert -->
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
$(document).ready(function() {
    // Handle the click for "Generate" button
    $(".generate-btn").click(function() {
        var schemaId = $(this).data("id"); // Get session_id from button

        // Change button to loading state
        var button = $(this);
        button.prop('disabled', true);
        button.html('<i class="fa fa-spinner fa-spin"></i> Generating...');

        Swal.fire({
            title: "Are you sure?",
            text: "You are about to generate a schema!",
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#28a745",
            cancelButtonColor: "#d33",
            confirmButtonText: "Yes, generate it!"
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    url: "", // Same file handles request
                    type: "POST",
                    data: { session_id: schemaId },
                    success: function(response) {
                        var result = JSON.parse(response);
                        if (result.status === "success") {
                            Swal.fire({
                                title: "Generation Successful!",
                                text: "The schema has been successfully set to pending.",
                                icon: "success",
                                timer: 5000, // Wait 5 seconds before page reload
                                showConfirmButton: false
                            }).then(() => {
                                location.reload(); // Reload page after 5 seconds
                            });
                        } else {
                            Swal.fire({
                                title: "Error!",
                                text: result.message,
                                icon: "error",
                                showConfirmButton: true
                            });
                        }
                    }
                });
            } else {
                button.prop('disabled', false);
                button.html('<i class="fa fa-plus-circle"></i> Generate'); // Reset button if cancelled
            }
        });
    });

    // Handle the "Approved" button click
    $(".approve-btn").click(function() {
        var schemaId = $(this).data("id"); // Get session_id from button

        // Change button to loading state
        var button = $(this);
        button.prop('disabled', true);
        button.html('<i class="fa fa-spinner fa-spin"></i> Approving...');

        $.ajax({
            url: "", // Same file handles request
            type: "POST",
            data: { session_id: schemaId, action: 'approve' },
            success: function(response) {
                var result = JSON.parse(response);
                if (result.status === "success") {
                    button.html('<i class="fa fa-check-circle"></i> Approved'); // Update to approved state
                } else {
                    Swal.fire({
                        title: "Error!",
                        text: result.message,
                        icon: "error",
                        showConfirmButton: true
                    });
                }
            }
        });
    });
});
</script>

<?php require 'footer.php'; ?>
