<?php
require 'header.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Collect form data
    $auser_id = mysqli_real_escape_string($conn, $_POST['auser_id']);
    $aschl_id = mysqli_real_escape_string($conn, $_POST['aschl_id']);
    $term = mysqli_real_escape_string($conn, $_POST['term']);
    $sector = mysqli_real_escape_string($conn, $_POST['sector']);
    $trade = mysqli_real_escape_string($conn, $_POST['trade']);
    $level = mysqli_real_escape_string($conn, $_POST['level']);
    $course_id = mysqli_real_escape_string($conn, $_POST['course_id']);
    $type_of_module = mysqli_real_escape_string($conn, $_POST['type_of_module']);
    $lo = mysqli_real_escape_string($conn, $_POST['lo']);
    $type_of_assessment = mysqli_real_escape_string($conn, $_POST['type_of_assessment']);
    $res_trainer = mysqli_real_escape_string($conn, $_POST['res_trainer']);
    $no_of_candidate = mysqli_real_escape_string($conn, $_POST['no_of_candidate']);
    $no_of_invigilator = mysqli_real_escape_string($conn, $_POST['no_of_invigilator']);
    $date = mysqli_real_escape_string($conn, $_POST['date']);
    $resources = mysqli_real_escape_string($conn, $_POST['resources']);
    $place = mysqli_real_escape_string($conn, $_POST['place']);
    $observation = mysqli_real_escape_string($conn, $_POST['observation']);
    
    $file_name = $_FILES['assessment_doc']['name'];
    $file_tmp = $_FILES['assessment_doc']['tmp_name'];
    $file_type = $_FILES['assessment_doc']['type'];
    $folder = 'assessments/' . $file_name;
    
    $allowed_types = ['application/pdf'];
    if (!in_array($file_type, $allowed_types)) {
        echo "<script>Swal.fire({ icon: 'error', title: 'Error', text: 'Only PDF files are allowed!' });</script>";
        exit;
    }
    
    move_uploaded_file($file_tmp, $folder);
    
    $query = "INSERT INTO assessment_plan (auser_id, aschl_id, term, sector, trade, level, ascourse_id, type_of_module, lo, type_of_assessment, res_trainer, no_of_condidate, no_of_invigilator, date, resources, place, observation, assessment_doc) 
              VALUES ('$auser_id', '$aschl_id', '$term', '$sector', '$trade', '$level', '$course_id', '$type_of_module', '$lo', '$type_of_assessment', '$res_trainer', '$no_of_candidate', '$no_of_invigilator', '$date', '$resources', '$place', '$observation', '$file_name')";
    
    if ($conn->query($query) === TRUE) {
        // After successful insertion, update the courses table
        $updateSql = "UPDATE courses SET assessment_plan = assessment_plan + 1 WHERE course_id = '$course_id'";

        if ($conn->query($updateSql) === TRUE) {
            $message = "Assessment added successfully.";
            echo "location.href = 'module_with_assessment_plan.php'";
        } else {
            $message = "Error updating course: " . $conn->error;
            $redirect = false; // Flag to indicate failure, no redirect
        }
    } else {
        $message = "Error: " . $conn->error;
        $redirect = false; // Flag to indicate failure, no redirect
    }
} else {
    $message = "Error uploading file.";
    $redirect = false; // Flag to indicate failure, no redirect
}
?>
<style>
    .nav-link.activecmo {
        background-color: rgba(3, 29, 54, 0.56);
        color: white;
    }
</style>
<div class="container mt-5">
    <div class="form-container col-lg-12 bg-white p-4">
        <h5>Add Assessment Plan</h5>
        <!-- Step Progress Bar -->
        <div class="mt-4">
            <label>Step Progress:</label>
            <input type="range" min="1" max="4" value="1" id="stepRange" class="col-lg-12" disabled>
        </div>
        <form action="" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="auser_id" value="<?=$_SESSION['user_id']?>">
            <input type="hidden" name="aschl_id" value="<?=$_SESSION['school']?>">

            <!-- Step 1 -->
            <div id="step1">
                <label>Select Term</label>
                <select name="term" class="form-control" required>
                    <option value="First">First Term</option>
                    <option value="Second">Second Term</option>
                    <option value="Third">Third Term</option>
                </select>

                <label>Sector</label>
                <input type="text" name="sector" class="form-control" required>

                <label>Trade</label>
                <input type="text" name="trade" class="form-control" required>

                <label>Module Name</label>
                <select name="course_id" class="form-control" required>
                    <?php
                    $user = $_SESSION['user_id'];
                    $id = $_GET['module'];
                    $select = mysqli_query($conn, "SELECT * FROM courses WHERE user_id = '$user' AND course_id = '$id'");
                    while ($course = mysqli_fetch_array($select)) {
                        echo "<option value='" . $course['course_id'] . "'>" . $course['course_name'] . "</option>";
                  ?>
                  <input type="hidden" name="level" value="<?=$course['course_level']?>" id="">
                </select>
                <?php
                    }
                ?>
                <button type="button" class="btn btn-dark mt-3" onclick="nextStep(1)">Next </button>
            </div>

            <!-- Step 2 -->
            <div id="step2" style="display:none;">
                <label>Type of Module</label>
                <input type="text" name="type_of_module" class="form-control" required>

                <label>Learning Outcome (LO)</label>
                <input type="text" name="lo" class="form-control" required>

                <label>Type of Assessment</label>
                <select name="type_of_assessment" class="form-control">
                    <option value="Formative">Formative</option>
                    <option value="Summative">Summative</option>
                    <option value="Integrated">Integrated</option>
                </select>
                <button type="button" class="btn btn-secondary mt-3" onclick="prevStep(2)">Previous </button>
                <button type="button" class="btn btn-dark mt-3" onclick="nextStep(2)">Next </button>
            </div>

            <!-- Step 3 -->
            <div id="step3" style="display:none;">
                <label>Responsible Trainer</label>
                <input type="text" value="<?=$_SESSION['username']?>" class="form-control" readonly>
                <input type="hidden" name="res_trainer" value="<?=$_SESSION['user_id']?>">

                <label>Number of Candidates</label>
                <input type="number" name="no_of_candidate" class="form-control" required>

                <label>Number of Invigilators</label>
                <input type="number" name="no_of_invigilator" class="form-control" required>

                <label>Assessment Date</label>
                <input type="date" name="date" class="form-control" required>
                <button type="button" class="btn btn-secondary mt-3" onclick="prevStep(3)">Previous</button>
                <button type="button" class="btn btn-dark mt-3" onclick="nextStep(3)">Next </button>
            </div>

            <!-- Step 4 -->
            <div id="step4" style="display:none;">
                <label>Resources</label>
                <select name="resources" class="form-control">
                    <option value="Paper and Pen">Paper and Pen</option>
                    <option value="Computer">Computer</option>
                    <option value="Projector">Projector</option>
                    <option value="Others">Others</option>
                </select>

                <label>Place of Assessment</label>
                <input type="text" name="place" class="form-control" required>

                <label>Observations</label>
                <textarea name="observation" class="form-control" required></textarea>

                <label>Upload Assessment Document (PDF)</label>
                <input type="file" name="assessment_doc" class="form-control" accept=".pdf" >
                <button type="button" class="btn btn-secondary mt-3" onclick="prevStep(4)">Previous</button>
                <button type="submit" class="btn btn-dark mt-3">Submit Assessment Plan</button>
            </div>
        </form>
    </div>
</div>

<script>
    function nextStep(step) {
        document.getElementById('step' + step).style.display = 'none';
        document.getElementById('step' + (step + 1)).style.display = 'block';
        document.getElementById('stepRange').value = step + 1;
        Swal.fire({
            icon: 'info',
            title: 'Step ' + (step + 1),
            text: 'You are now at step ' + (step + 1) + ' of the process.'
        });
    }

    function prevStep(step) {
        document.getElementById('step' + step).style.display = 'none';
        document.getElementById('step' + (step - 1)).style.display = 'block';
        document.getElementById('stepRange').value = step - 1;
        Swal.fire({
            icon: 'info',
            title: 'Step ' + (step - 1),
            text: 'You have returned to step ' + (step - 1) + '.'
        });
    }
</script>

<?php if (isset($redirect) && $redirect): ?>
    <script>
        Swal.fire({
            icon: 'success',
            title: 'Success',
            text: '<?php echo $message; ?>',
            showConfirmButton: false,
            timer: 5000
        }).then(function() {
            window.location.href = 'module_with_assessment_plan.php';
        });
    </script>
<?php elseif (isset($message)): ?>
    <script>
        Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: '<?php echo $message; ?>',
            showConfirmButton: true
        });
    </script>
<?php endif; ?>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<?php require 'footer.php'; ?>
