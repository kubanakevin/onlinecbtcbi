<?php
// require 'header.php';
require 'connection.php';
?>

<!-- Include SweetAlert -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<?php
if (isset($_GET['delete'])) {
    $dairy_id = $_GET['delete'];
    
    // Prepare delete statement
    $stmt = $conn->prepare("DELETE FROM dairy_plan WHERE dairy_id = ?");
    $stmt->bind_param("i", $dairy_id);
    
    if ($stmt->execute()) {
        echo "<script>
            document.addEventListener('DOMContentLoaded', function() {
                Swal.fire({
                    icon: 'success',
                    title: 'Deleted!',
                    text: 'Dairy plan has been deleted successfully.',
                    showConfirmButton: false,
                    timer: 2000
                }).then(() => {
                    window.location.href = 'dashboard.php';
                });
            });
        </script>";
    } else {
        echo "<script>
            document.addEventListener('DOMContentLoaded', function() {
                Swal.fire({
                    icon: 'error',
                    title: 'Error!',
                    text: 'Failed to delete dairy plan. Please try again.',
                });
            });
        </script>";
    }
    
    $stmt->close();
} else {
    echo "<script>
        document.addEventListener('DOMContentLoaded', function() {
            Swal.fire({
                icon: 'warning',
                title: 'Warning!',
                text: 'Invalid request.',
            });
        });
    </script>";
}

$conn->close();
// require 'footer.php';
?>