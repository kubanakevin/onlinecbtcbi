<?php
// mark_messages_as_read.php
include 'connection.php';

// Get data from POST request
$school_id = $_POST['school_id'];
$user_id = $_POST['user_id'];

// Update the status of unread messages to 'read' for the given school
$query = "UPDATE messages SET status = 'read' WHERE mschl_id = '$school_id' AND status = 'unread' AND muser_id != '$user_id'";

if (mysqli_query($conn, $query)) {
    echo json_encode(['status' => 'success']);
} else {
    echo json_encode(['status' => 'error', 'message' => mysqli_error($conn)]);
}
?>
