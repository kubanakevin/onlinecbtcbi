<?php
require 'connection.php';
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $messageId = $_POST['message_id'];
    $userId = $_SESSION['user_id'];
    $comment = mysqli_real_escape_string($conn, $_POST['comment']);

    $sql = "INSERT INTO comments (message_id, user_id, comment) VALUES ('$messageId', '$userId', '$comment')";
    if (mysqli_query($conn, $sql)) {
        $response = [
            "success" => true,
            "username" => $_SESSION['username'],
            "comment" => $comment,
            "created_at" => date("Y-m-d H:i:s")
        ];
    } else {
        $response = ["success" => false, "error" => mysqli_error($conn)];
    }

    echo json_encode($response);
}
?>
