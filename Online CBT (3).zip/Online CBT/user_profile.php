
<?php
include ('header.php');
?>
 <div class="row">
                <div class="form-container col-lg-5 bg-white" style="padding: 30px">
                  <h5>User Information</h5>
                        <div class="card">
                            <div class="card-body">
                                <?php
                                include ('connection.php');
                                
                                if ($_SESSION['title'] == 'Master' || $_SESSION['title'] == 'Dos') {
                                $user_id=$_SESSION['user_id'];
                                $school = $_SESSION['school'];
                                $title = $_SESSION['title'];
                                    $select=mysqli_query($conn,"SELECT * FROM users, schools WHERE users.school = schools.school_id AND school = '$school' AND user_id = '$user_id'");
                                while ($row=mysqli_fetch_array($select)) {
                                    ?>
                                    <b>User Image</b><br><br>
                                    <img src="uploaded_file/<?php echo $row['user_image']; ?>" style="width: 7rem;height:7rem;border-radius: 250px;border: 5px solid green" alt=""><br><br>
                                    <p><b>Username: </b><?=$row['username']?></p>
                                    <p><b>National ID: </b><?=$row['nat_id']?></p>
                                    <p><b>Telephone: </b><?=$row['tel']?></p>
                                    <p><b>Degree: </b><?=$row['degree']?></p>
                                    <p><b>Title: </b><?=$row['title']?></p>
                                    <p><b>Email: </b><?=$row['email']?></p>
                                    <p><b>School Name: </b><?=$row['school_name']?></p>
                                    <!-- <p><b>Password: </b><?=$row['password']?></p> -->
                                    <!-- <a href="user_profile.php?delete=<?=$row['user_id']?>"><button class="btn btn-danger">Delete</button></a> -->
                                    <a href="update_user_profile.php?user_id=<?=$row['user_id']?>"><button class="btn btn-info">Change  Info</button></a><br><br>
                                    <hr style="border: 5px solid #000;">
                                    <?php
                                } 
                             }elseif ($_SESSION['title'] == 'Trainer') {
                                $user_id=$_SESSION['user_id'];
                                $school = $_SESSION['school'];
                                $title = $_SESSION['title'];
                                $select=mysqli_query($conn,"SELECT * FROM users, schools WHERE users.school = schools.school_id AND school = '$school' AND user_id = '$user_id' ");
                                while ($row=mysqli_fetch_array($select)) {
                                    ?>
                                    <b>User Image</b><br><br>
                                    <img src="uploaded_file/<?php echo $row['user_image']; ?>" style="width: 7rem;height:7rem;border-radius: 250px;border: 5px solid green" alt=""><br><br>
                                    <p><b>Username: </b><?=$row['username']?></p>
                                    <p><b>National ID: </b><?=$row['nat_id']?></p>
                                    <p><b>Telephone: </b><?=$row['tel']?></p>
                                    <p><b>Degree: </b><?=$row['degree']?></p>
                                    <p><b>Title: </b><?=$row['title']?></p>
                                    <p><b>Email: </b><?=$row['email']?></p>
                                    <p><b>School Name: </b><?=$row['school_name']?></p>
                                    <!-- <p><b>Password: </b><?=$row['password']?></p> -->
                                    <!-- <a href="user_profile.php?delete=<?=$row['user_id']?>"><button class="btn btn-danger">Delete</button></a> -->
                                    <a href="update_user_profile.php?user_id=<?=$row['user_id']?>"><button class="btn btn-info">Change  Info</button></a><br><br>
                                    
                                    <?php
                             }
                            } elseif ($_SESSION['title'] == 'Admin') {
                                $user_id=$_SESSION['user_id'];
                                $school = $_SESSION['school'];
                                $title = $_SESSION['title'];
                                $select=mysqli_query($conn,"SELECT * FROM users, schools WHERE users.school = schools.school_id AND user_id = '$user_id' ");
                                while ($row=mysqli_fetch_array($select)) {
                                    ?>
                                    <b>User Image</b><br><br>
                                    <img src="uploaded_file/<?php echo $row['user_image']; ?>" style="width: 7rem;height:7rem;border-radius: 250px;border: 5px solid green" alt=""><br><br>
                                    <p><b>Username: </b><?=$row['username']?></p>
                                    <p><b>National ID: </b><?=$row['nat_id']?></p>
                                    <p><b>Telephone: </b><?=$row['tel']?></p>
                                    <p><b>Degree: </b><?=$row['degree']?></p>
                                    <p><b>Title: </b><?=$row['title']?></p>
                                    <p><b>Email: </b><?=$row['email']?></p>
                                    <p><b>School Name: </b><?=$row['school_name']?></p>
                                    <!-- <p><b>Password: </b><?=$row['password']?></p> -->
                                    <!-- <a href="user_profile.php?delete=<?=$row['user_id']?>"><button class="btn btn-danger">Delete</button></a> -->
                                    <a href="update_user_profile.php?user_id=<?=$row['user_id']?>"><button class="btn btn-info">Change  Info</button></a><br><br>
                                    <hr style="border: 3px solid #000;">
                                    <?php
                             }
                            }
                                ?>
                            </div>
                        </div>
                    </div>
<?php
include ('footer.php');
?>