<?php
require 'header.php';
require 'connection.php';
$school = $_SESSION['school'];
$user = $_SESSION['user_id'];
$role = $_SESSION['title']; // Assuming user roles are stored in session
if ($role === 'Master' || $role === 'DOS') {
    $sql = "SELECT * FROM messages 
            JOIN users ON messages.muser_id = users.user_id
            JOIN schools ON messages.mschl_id = schools.school_id
            WHERE messages.mschl_id = '$school'";
} elseif ($role === 'Trainer') {
    $sql = "SELECT * FROM messages 
            JOIN users ON messages.muser_id = users.user_id
            JOIN schools ON messages.mschl_id = schools.school_id
            WHERE messages.mschl_id = '$school'";
} else {
    $sql = "SELECT * FROM messages WHERE 1=0"; // No messages for other roles
}
$res = mysqli_query($conn, $sql);
?>
<style>
    .activecmess {
        background-color: rgba(3, 29, 54, 0.56);
        color: white;
    }
</style>
<div class="row">
    <div class="col-md-12 mt-4" style="height: 30rem; overflow-y: scroll;">
        <div class="card">
            <div class="card-header pb-0 px-3">
                <h6 class="mb-3">School Messages</h6>
            </div>
            <div id="messageContainer" class="card-body pt-4 p-3 col-lg-12" style="height: 20rem; overflow-y: auto;">
                <ul>
                    <?php while ($row = mysqli_fetch_array($res)) { 
                        $messageId = $row['message_id']; 
                    ?>
                        <li class="list-group-item border-0 d-flex flex-column p-1 mb-1 bg-gray-100 border-radius-lg">
                            <span class="d-flex flex-column">
                                <h6 class="mb-2 text-sm"><?= $row['username'] ?> (<?= $row['title'] ?>)</h6>
                                <span class="mb-2 text-xs"><?= $row['message'] ?></span>
                            </span>
                            <span class="ms-auto text-end">
                                <?php if ($role == 'Master' || $role == 'DOS') { ?>
                                    <a href="delete_message.php?message=<?= $row['message_id'] ?>" 
                                    class="text-danger" 
                                    onclick="return confirm('Are you sure you want to delete this message?');">
                                    <i class="material-symbols-rounded text-danger me-2 fa fa-trash"></i> Delete Message
                                    </a>
                                    <?php
                                    date_default_timezone_set('Africa/Kigali'); 
                                    $messageTime = new DateTime($row['time']);
                                    $currentTime = new DateTime();
                                    $interval = $messageTime->diff($currentTime);
                                    if ($interval->y > 0) {
                                        $timeAgo = $messageTime->format("Y-m-d H:i:s");
                                    } elseif ($interval->m > 0 || $interval->d > 0) {
                                        $timeAgo = $messageTime->format("M d, Y");
                                    } elseif ($interval->h > 0) {
                                        $timeAgo = $interval->h . " hours ago";
                                    } elseif ($interval->i > 0) {
                                        $timeAgo = $interval->i . " minutes ago";
                                    } else {
                                        $timeAgo = "Just now";
                                    }
                                    ?>
                                    <p class="text-primary"> <?= $timeAgo ?></p>
                                    <div class="comments-list" id="comments-<?= $messageId ?>">
                                    <?php
                                            $commentSql = "SELECT * FROM comments 
                                                        JOIN users ON comments.user_id = users.user_id
                                                        WHERE comments.message_id = '$messageId'
                                                        ORDER BY comments.created_at DESC";
                                            $commentRes = mysqli_query($conn, $commentSql);
                                            while ($comment = mysqli_fetch_assoc($commentRes)) {
                                                $commentId = $comment['comment_id'];
                                                echo "<p id='comment-$commentId' style='margin-right: 20px'>
                                                        <strong>{$comment['username']}:</strong> {$comment['comment']} 
                                                        <small class='text-warning'>{$comment['created_at']}</small>
                                                        <i class='fa fa-trash text-danger delete-comment' 
                                                        style='cursor:pointer;' 
                                                        data-comment-id='$commentId'></i>
                                                    </p>";
                                            }
                                            ?>
                                    </div>
                                <?php } else { ?>
                                    <?php
                                    date_default_timezone_set('Africa/Kigali'); 
                                    $messageTime = new DateTime($row['time']);
                                    $currentTime = new DateTime();
                                    $interval = $messageTime->diff($currentTime);
                                    if ($interval->y > 0) {
                                        $timeAgo = $messageTime->format("Y-m-d H:i:s");
                                    } elseif ($interval->m > 0 || $interval->d > 0) {
                                        $timeAgo = $messageTime->format("M d, Y");
                                    } elseif ($interval->h > 0) {
                                        $timeAgo = $interval->h . " hours ago";
                                    } elseif ($interval->i > 0) {
                                        $timeAgo = $interval->i . " minutes ago";
                                    } else {
                                        $timeAgo = "Just now";
                                    }
                                    ?>
                                    <p class="text-primary"> <?= $timeAgo ?></p>
                                     <div class="comments-list" id="comments-<?= $messageId ?>">
                                <?php
                                $commentSql = "SELECT * FROM comments 
                                            JOIN users ON comments.user_id = users.user_id
                                            WHERE comments.message_id = '$messageId'
                                            ORDER BY comments.created_at DESC";
                                $commentRes = mysqli_query($conn, $commentSql);
                                while ($comment = mysqli_fetch_assoc($commentRes)) {
                                    $commentId = $comment['comment_id'];
                                    echo "<p id='comment-$commentId' style='margin-right: 20px'>
                                            <strong>{$comment['username']}:</strong> {$comment['comment']} 
                                            <small class='text-warning'>{$comment['created_at']}</small>
                                            <i class='fa fa-trash text-danger delete-comment' 
                                                        style='cursor:pointer;' 
                                                        data-comment-id='$commentId'></i>
                                        </p>";
                                }
                                ?>
                                <a class="btn btn-link text-primary text-gradient px-3 mb-0 comment-btn" href="javascript:;" data-message-id="<?= $messageId ?>">
                                        <i class="material-symbols-rounded text-sm me-2">comment</i>Comment
                                    </a>
                                </div>
                                    <div class="comment-box" id="commentBox-<?= $messageId ?>" style="display: none; margin-top: 10px;">
                                        <textarea class="form-control mb-2 comment-input" name="comment" placeholder="Write a comment..."></textarea>
                                        <button type="button" class="btn btn-sm btn-primary post-comment" data-message-id="<?= $messageId ?>">Post Comment</button>
                                    </div>
                                <?php } ?>
                            </span>
                        </li>
                    <?php } ?>
                </ul>
            </div>
            <?php
$user_role = $_SESSION['title']; // Get user role from session
$allowed_roles = ['Master', 'Dos'];
if (in_array($user_role, $allowed_roles)) :
?>
<style>
    .activecmess {
        background-color: rgba(3, 29, 54, 0.56);
        color: white;
    }
</style>
    <div class="card-footer">
        <form role="form text-left" method="POST" action="send_message.php">
            <div class="d-flex gap-2">
                <div class="flex-grow-1">
                    <textarea class="form-control" placeholder="Message" name="message"></textarea>
                </div>
                <div style="width: 100px; height: 3.5rem">
                    <button type="submit" class="btn bg-gradient-dark w-100" style="height: 100%">Send</button>
                </div>
            </div>
        </form>
    </div>
<?php else : ?>
    <div class="card-footer text-center text-danger">
        <p>You do not have permission to send messages! Only Comments</p>
    </div>
<?php endif; ?>
        </div>
    </div>
</div>
<script>
                                        document.addEventListener("DOMContentLoaded", function () {
                                            document.querySelectorAll(".delete-comment").forEach(button => {
                                                button.addEventListener("click", function () {
                                                    let commentId = this.getAttribute("data-comment-id");
                                                    fetch("delete_comment.php", {
                                                        method: "POST",
                                                        headers: { "Content-Type": "application/x-www-form-urlencoded" },
                                                        body: "comment_id=" + commentId
                                                    })
                                                    .then(response => response.json())
                                                    .then(data => {
                                                        if (data.status === "success") {
                                                            document.getElementById("comment-" + commentId).remove();
                                                        }
                                                    })
                                                    .catch(error => console.error("Error:", error));
                                                });
                                            });
                                        });
                                        </script>
<script>
    document.addEventListener("DOMContentLoaded", function () {
        document.querySelectorAll('.comment-btn').forEach(function (button) {
            button.addEventListener('click', function () {
                var messageId = this.getAttribute('data-message-id');
                var commentBox = document.getElementById("commentBox-" + messageId);
                commentBox.style.display = commentBox.style.display === "none" ? "block" : "none";
            });
        });
        document.querySelectorAll('.copy-message').forEach(function (button) {
            button.addEventListener('click', function () {
                var messageText = this.getAttribute('data-message');
                navigator.clipboard.writeText(messageText).then(() => {
                    alert("Message copied!");
                }).catch(err => {
                    console.error("Failed to copy: ", err);
                });
            });
        });
    });
</script>
<script>
    document.addEventListener("DOMContentLoaded", function () {
        document.querySelectorAll('.comment-btn').forEach(function (button) {
            button.addEventListener('click', function () {
                var messageId = this.getAttribute('data-message-id');
                var commentBox = document.getElementById("commentBox-" + messageId);
                commentBox.style.display = commentBox.style.display === "none" ? "block" : "none";
            });
        });
        document.querySelectorAll('.post-comment').forEach(function (button) {
            button.addEventListener('click', function () {
                var messageId = this.getAttribute('data-message-id');
                var commentInput = document.querySelector("#commentBox-" + messageId + " .comment-input");
                var commentText = commentInput.value.trim();
                if (commentText !== "") {
                    var xhr = new XMLHttpRequest();
                    xhr.open("POST", "add_comment.php", true);
                    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                    xhr.onreadystatechange = function () {
                        if (xhr.readyState === 4 && xhr.status === 200) {
                            var response = JSON.parse(xhr.responseText);
                            if (response.success) {
                                var commentList = document.getElementById("comments-" + messageId);
                                var newComment = document.createElement("p");
                                newComment.innerHTML = `<strong>${response.username}:</strong> ${response.comment} <small class="text-muted">${response.created_at}</small>`;
                                commentList.appendChild(newComment);
                                commentInput.value = ""; 
                            }
                        }
                    };
                    xhr.send("message_id=" + messageId + "&comment=" + encodeURIComponent(commentText));
                }
            });
        });
    });
</script>
<script>
    document.addEventListener("DOMContentLoaded", function () {
        var messageContainer = document.getElementById("messageContainer");
        function scrollToBottom() {
            messageContainer.scrollTop = messageContainer.scrollHeight;
        }
        scrollToBottom();
        var observer = new MutationObserver(scrollToBottom);
        observer.observe(messageContainer, { childList: true, subtree: true });
        document.querySelectorAll('.comment-btn').forEach(function (button) {
            button.addEventListener('click', function () {
                var messageId = this.getAttribute('data-message-id');
                var commentBox = document.getElementById("commentBox-" + messageId);
                if (commentBox.style.display === "none") {
                    commentBox.style.display = "block";
                } else {
                    commentBox.style.display = "none";
                }
            });
        });
    });
</script>
<?php require 'footer.php'; ?> 
