<?php
require 'header.php';
?>

<div class="limiter">
    <div class="container-login100" style="background: transparent">
        <div class="wrap-login100 col-lg-6 p-4">
            <?php
            include('connection.php');

            if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                $username = $_POST['username'];
                $nat_id = $_POST['nat_id'];
                $tel = $_POST['tel'];
                $degree = $_POST['degree'];
                $title = $_POST['title'];
                $school_id = $_POST['school'];
                $email = $_POST['email'];
                $password = $_POST['pass'];
                $re_password = $_POST['re_pass'];
                $user_image = $_FILES['user_image']['name'];
                $target_dir = "uploaded_file/";
                $target_file = $target_dir . basename($user_image);

                if (empty($username) || empty($nat_id) || empty($tel) || empty($degree) || empty($title) || empty($email) || empty($password) || empty($re_password) || $password !== $re_password || empty($user_image)) {
                    echo "<div id='error-message' class='alert alert-danger'>Make sure passwords match and all fields are filled.</div>";
                } else {
                    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                    if (move_uploaded_file($_FILES['user_image']['tmp_name'], $target_file)) {
                        $stmt = $conn->prepare("INSERT INTO users (username, nat_id, tel, degree, title, school, email, password, re_password, user_image) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                        $stmt->bind_param("ssssssssss", $username, $nat_id, $tel, $degree, $title, $school_id, $email, $hashed_password, $re_password, $user_image);

                        if ($stmt->execute()) {
                            echo "<script>alert('Trainer Added successfully! He/she will use that information to view account'); window.location.href='trainers.php';</script>";
                        } else {
                            echo "<div id='error-message' class='alert alert-danger'>Error: " . $stmt->error . "</div>";
                        }
                        $stmt->close();
                    } else {
                        echo "<div id='error-message' class='alert alert-danger'>Sorry, there was an error uploading your file.</div>";
                    }
                    $conn->close();
                }
            }
            ?>

            <form id="trainer-form" class="login100-form validate-form" action="" method="POST" enctype="multipart/form-data">
                <span class="login100-form-title">Add Trainer</span>

                <div class="form-group">
                    <label for="username">Full Names</label>
                    <input id="username" class="form-control" type="text" name="username" placeholder="Full Names" required>
                </div>
                <div class="form-group">
                    <label for="nat_id">National ID</label>
                    <input id="nat_id" class="form-control" type="number" name="nat_id" placeholder="National ID" required>
                </div>
                <div class="form-group">
                    <label for="tel">Telephone No</label>
                    <input id="tel" class="form-control" type="text" name="tel" placeholder="Telephone No" required>
                </div>
                
                <div class="form-group">
                    <label for="degree">Degree Level</label>
                    <select id="title" name="degree" class="form-control" required>
                        <option value="A2">A2</option>
                        <option value="A1">A1</option>
                        <option value="A0">A0</option>
                        <option value="Master">Master</option>
                        <option value="Professor">Professor</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="title">Title</label>
                    <select id="title" name="title" class="form-control" required>
                        <option value="Trainer">Trainer</option>
                        <option value="Dos">Dos</option>
                        <option value="Master">Master</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input id="email" class="form-control" type="email" name="email" placeholder="Email" required>
                </div>
                <div class="form-group">
                    <label for="school">School Name</label>
                    <?php
                    include ('connection.php');
                    $school = $_SESSION['school'];
                    $select = mysqli_query($conn, "SELECT * FROM schools WHERE school_id = '$school'");
                    while ($row = mysqli_fetch_assoc($select)) {
                    ?>
                    <input id="school" class="form-control" type="hidden" name="school" value="<?=$row['school_id']?>">
                    <input class="form-control" type="text" value="<?=$row['school_name']?>" readonly>
                    <?php
                    }
                    ?>
                </div>
                <div class="form-group">
                    <label for="pass">Password</label>
                    <input id="pass" class="form-control" type="password" name="pass" placeholder="Password" required>
                </div>
                <div class="form-group">
                    <label for="re_pass">Repeat Password</label>
                    <input id="re_pass" class="form-control" type="password" name="re_pass" placeholder="Repeat Password" required>
                </div>
                <div class="form-group">
                    <label for="user_image">Upload Image</label>
                    <input id="user_image" class="form-control-file" type="file" name="user_image" required>
                </div>
                <div class="form-group">
                    <button id="submit-btn" class="btn btn-primary btn-block" type="submit">Sign Up</button>
                </div>
                <div class="text-center">
                    <a class="txt2" href="index.php">Login if you have an account</a>
                </div>
            </form>
        </div>
    </div>
</div>