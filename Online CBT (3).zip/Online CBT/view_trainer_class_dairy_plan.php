<?php
require 'header.php';
?>
<style>
    .nav-link.activetd {
        background-color: rgba(3, 29, 54, 0.56);
        color: white;
    }
</style>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<div class="event text-right">
    <p class="p-t-13"><a href="add_dairy_plan.php"><i class="fa fa-download"></i> </a></p>
</div>

<?php
require 'connection.php';
$today = date('Y-m-d');
$date = $_GET['date'] ?? '';
$user = $_GET['user'] ?? '';

if (!$date || !$user) {
    echo "<script>
        Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'Invalid request! Missing parameters.',
        }).then(() => {
            window.location.href = 'dairy_plans.php';
        });
    </script>";
    exit();
}

// if ($today == $date) {
?>
    <div class="today-plans" style="border: 1px solid #ccc; padding: 20px;">
        <h4 class="text-center">Trainer's Class Dairy Plans</h4>
        <div class="row" style="overflow-x: scroll;">
            <table class="table table-hover table-bordered bg-white" id="sampleTable">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Period</th>
                        <th>Trade</th>
                        <th>Level</th>
                        <th>Module Name <br> (Code)</th>
                        <th>Topic</th>
                        <th>Activity <br> (Main Content)</th>
                        <th>Application</th>
                        <th>Observation</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $title = $_SESSION['title'];
                    $school = $_SESSION['school'];
                    $usr_id = $_SESSION['user_id'];
                    
                    if ($title == 'Master' || $title == 'Dos') {
                        $sql_today = "SELECT * FROM dairy_plan 
                                      INNER JOIN users ON dairy_plan.duser_id = users.user_id
                                      INNER JOIN schools ON dairy_plan.school_id = schools.school_id
                                      INNER JOIN courses ON dairy_plan.course_id = courses.course_id
                                      WHERE dairy_plan.school_id = '$school'
                                      AND dairy_plan.date = '$date'
                                      AND dairy_plan.duser_id = '$user'";
                    } elseif ($title == 'Admin') {
                        $sql_today = "SELECT * FROM dairy_plan 
                                      INNER JOIN users ON dairy_plan.duser_id = users.user_id
                                      INNER JOIN schools ON dairy_plan.school_id = schools.school_id
                                      INNER JOIN courses ON dairy_plan.course_id = courses.course_id
                                      WHERE dairy_plan.date = '$date'";
                    } elseif ($title == 'Trainer') {
                        $sql_today = "SELECT * FROM dairy_plan 
                                      INNER JOIN users ON dairy_plan.duser_id = users.user_id
                                      INNER JOIN schools ON dairy_plan.school_id = schools.school_id
                                      INNER JOIN courses ON dairy_plan.course_id = courses.course_id
                                      WHERE dairy_plan.duser_id = '$usr_id' 
                                      AND dairy_plan.date = '$date'";
                    }

                    $select_today = mysqli_query($conn, $sql_today);
                    while ($rows = mysqli_fetch_array($select_today)) {
                    ?>
                        <tr>
                            <td><?= $rows['date'] ?></td>
                            <td><?= $rows['start_time'] ?> - <?= $rows['end_time'] ?></td>
                            <td><?= $rows['trade'] ?></td>
                            <td><?= $rows['level'] ?></td>
                            <td><?= $rows['course_name'] ?></td>
                            <td><?= $rows['topic'] ?></td>
                            <td><?= $rows['activity'] ?></td>
                            <td><?= $rows['application'] ?></td>
                            <td><?= $rows['observation'] ?></td>
                            <td>
                                <a href="delete_dairy_plan.php?dairy_id=<?= $rows['dairy_id'] ?>" onclick="return confirmDelete(event)">
                                    <i class="fa fa-x text-danger" style="font-size: 25px" title="Delete Class Dairy Plan"></i>
                                </a>
                            </td>
                        </tr>
                    <?php
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
<?php
// }
require 'footer.php';
?>
<script>
function confirmDelete(event) {
    event.preventDefault();
    const url = event.currentTarget.href;
    Swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = url;
        }
    });
}
</script>