<?php
session_start(); // Start session to track repeat visitors
include('connection.php'); // Include database connection

// Get visitor IP address
$ip_address = $_SERVER['REMOTE_ADDR'];

// Check if the visitor has already visited during this session
if (!isset($_SESSION['visited'])) {
    // Insert the new visitor into the database
    $sql = "INSERT INTO visitors (ip_address) VALUES ('$ip_address')";
    mysqli_query($conn, $sql);

    // Mark session to avoid duplicate counting in one visit
    $_SESSION['visited'] = true;
}

// Get the total number of visitors
// $result = mysqli_query($conn, "SELECT COUNT(*) as total_visitors FROM visitors");
// $row = mysqli_fetch_assoc($result);
// $total_visitors = $row['total_visitors'];

// // Display visitor count
// echo "Total Visitors: " . $total_visitors;
?>
