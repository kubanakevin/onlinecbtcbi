-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 17, 2025 at 09:33 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `trainer_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `academic_year`
--

CREATE TABLE `academic_year` (
  `academic_id` int(11) NOT NULL,
  `acuser_id` int(11) NOT NULL,
  `year` varchar(200) NOT NULL,
  `term` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `academic_year`
--

INSERT INTO `academic_year` (`academic_id`, `acuser_id`, `year`, `term`) VALUES
(7, 9, '2024 - 2025', 'Second Term');

-- --------------------------------------------------------

--
-- Table structure for table `assessment_plan`
--

CREATE TABLE `assessment_plan` (
  `assessment_id` int(11) NOT NULL,
  `aschl_id` int(11) NOT NULL,
  `auser_id` int(11) NOT NULL,
  `term` varchar(200) NOT NULL,
  `sector` varchar(200) NOT NULL,
  `trade` varchar(100) NOT NULL,
  `level` varchar(100) NOT NULL,
  `ascourse_id` int(11) NOT NULL,
  `type_of_module` varchar(100) NOT NULL,
  `lo` varchar(100) NOT NULL,
  `type_of_assessment` varchar(100) NOT NULL,
  `res_trainer` int(11) NOT NULL,
  `no_of_condidate` varchar(100) NOT NULL,
  `no_of_invigilator` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `resources` varchar(100) NOT NULL,
  `place` varchar(100) NOT NULL,
  `time_of_assessment` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `observation` text NOT NULL,
  `assessment_doc` varchar(250) NOT NULL,
  `on_status` enum('not yet done','done') NOT NULL DEFAULT 'not yet done',
  `astatus` enum('none','pending','approved') NOT NULL DEFAULT 'none',
  `action_time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `assessment_plan`
--

INSERT INTO `assessment_plan` (`assessment_id`, `aschl_id`, `auser_id`, `term`, `sector`, `trade`, `level`, `ascourse_id`, `type_of_module`, `lo`, `type_of_assessment`, `res_trainer`, `no_of_condidate`, `no_of_invigilator`, `date`, `resources`, `place`, `time_of_assessment`, `observation`, `assessment_doc`, `on_status`, `astatus`, `action_time`) VALUES
(1, 1, 2, 'Second', 'Tourism ', 'Tourism ', '4', 11, 'dsdcd', 'hmn', 'Formative', 2, '89', '8', '2025-03-11', 'Paper and Pen', 'dfsdf', '2025-03-11 14:43:06', 'l;kl;', 'file.pdf', 'done', 'pending', '2025-03-11 13:57:15'),
(2, 1, 2, 'Second', 'Tourism ', 'Tourism ', '3', 13, 'dsdcd', 'hmn', 'Formative', 2, '7868', '78', '2025-03-29', 'Paper and Pen', 'dfsdf', '2025-03-11 14:01:51', 'kj', 'file (1).pdf', 'not yet done', 'none', '2025-03-11 14:01:51');

-- --------------------------------------------------------

--
-- Table structure for table `checklist`
--

CREATE TABLE `checklist` (
  `list_id` int(11) NOT NULL,
  `usr_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `schol_id` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `period` varchar(100) NOT NULL,
  `trade` varchar(100) NOT NULL,
  `level` varchar(50) NOT NULL,
  `no_trainees` varchar(10) NOT NULL,
  `mcdco` varchar(250) NOT NULL,
  `topic` varchar(100) NOT NULL,
  `sowr` varchar(10) NOT NULL,
  `spaef` varchar(10) NOT NULL,
  `cdau` varchar(10) NOT NULL,
  `caleu` varchar(10) NOT NULL,
  `tmsbpcetrewa` varchar(10) NOT NULL,
  `fta` varchar(10) NOT NULL,
  `taau` varchar(10) NOT NULL,
  `dmau` varchar(10) NOT NULL,
  `tsp` varchar(10) NOT NULL,
  `ciwm` varchar(10) NOT NULL,
  `leic` varchar(10) NOT NULL,
  `avg_sum` varchar(20) NOT NULL,
  `strong_point` varchar(250) NOT NULL,
  `area_of_improv` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `checklist`
--

INSERT INTO `checklist` (`list_id`, `usr_id`, `course_id`, `schol_id`, `date`, `period`, `trade`, `level`, `no_trainees`, `mcdco`, `topic`, `sowr`, `spaef`, `cdau`, `caleu`, `tmsbpcetrewa`, `fta`, `taau`, `dmau`, `tsp`, `ciwm`, `leic`, `avg_sum`, `strong_point`, `area_of_improv`) VALUES
(1, 7, 19, 3, '2025-02-18 11:25:06', '40 min', 'Tourism', '4', '18', 'Concstruction', 'Session', '4', '5', '4', '5', '4', '5', '4', '1', '4', '5', '1', '42', 'You aare not able', 'try other carrier'),
(2, 5, 11, 1, '2025-02-18 11:58:56', '40 min', 'Tourism', '4', '18', 'Backend', 'Topic session', '5', '5', '5', '5', '5', '5', '5', '5', '5', '5', '5', '55', '', 'Well Done '),
(3, 2, 13, 1, '2025-02-18 12:01:56', '40 min', 'Software Development', '5', '18', 'Conc', 'Topic session', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '11', 'You aare not able', 'try other carrier'),
(4, 4, 12, 1, '2025-02-19 13:19:50', '90 hours', 'Computer system', '3', '34', 'Matrics', ' 3 similtaniours', '5', '2', '4', '5', '1', '3', '4', '2', '3', '5', '3', '37', '', 'Well Done '),
(5, 4, 12, 1, '2025-02-20 07:37:49', '30 hours', 'Software Development', '4', '54', 'Concstruction', 'Mining and seling', '4', '4', '3', '1', '4', '4', '2', '4', '3', '2', '5', '36', '', 'Well Done success'),
(6, 2, 13, 1, '2025-02-20 07:48:01', '10 min', 'Tourism', '5', '54', 'Matrics', ' 3 similtaniours', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1', '11', 'You aare not able', 'try other carrier'),
(7, 2, 13, 1, '2025-03-05 14:47:54', '40 hours', 'Tourism', '5', '8', 'Matrics', ' 3 similtaniours', '4', '3', '1', '4', '2', '5', '2', '3', '2', '4', '5', '35', 'hello', 'try other carrier'),
(8, 2, 11, 1, '2025-03-10 09:39:34', '20 hours', 'MAS', '5', '34', 'Backend', ' 3 similtaniours', '2', '1', '3', '5', '3', '5', '4', '3', '5', '4', '3', '38', 'You aare not able', 'try other carrier');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `comment_id` int(11) NOT NULL,
  `message_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `comment` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`comment_id`, `message_id`, `user_id`, `comment`, `created_at`) VALUES
(10, 42, 2, 'mn', '2025-03-09 20:29:19');

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `course_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `schl_id` int(11) NOT NULL,
  `trade` varchar(250) NOT NULL,
  `course_name` varchar(250) NOT NULL,
  `period` varchar(200) NOT NULL,
  `course_level` varchar(50) NOT NULL,
  `file` varchar(255) NOT NULL,
  `session_plan` int(11) DEFAULT 0,
  `schema_of_work` int(11) DEFAULT 0,
  `assessment_plan` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`course_id`, `user_id`, `schl_id`, `trade`, `course_name`, `period`, `course_level`, `file`, `session_plan`, `schema_of_work`, `assessment_plan`) VALUES
(11, 2, 1, 'SOD', 'Backend (SODB501)', '10 min', '4', 'Market Validation_4.pdf', 0, 1, 1),
(12, 4, 1, 'NET', 'Mathemathic', '40 hours', '5', 'Go to market.pdf', 0, 1, 0),
(13, 2, 1, 'MAS', 'Kiswahili', '20 hours', '3', 'GTM plan .pdf', 1, 2, 1),
(18, 3, 3, 'TOR', 'Chemistry', '10 min', '3', 'Market Validation_4.pdf', 0, 1, 0),
(19, 7, 3, 'SOD', 'France', '40 min', '5', 'business plan.pdf', 0, 1, 0),
(22, 2, 1, 'Software Development', 'Business Requirement', '10 min', '3', 'm.pdf', 4, 2, 0),
(23, 5, 1, 'Software Development', 'Phisical (Phs501qw)', '5 hours', '5', 'm_1.pdf', 0, 1, 0),
(24, 5, 1, 'Software Development', 'Kinyarwanda (KINY501r)', '14 hours', '5', 'm_2.pdf', 0, 2, 0);

-- --------------------------------------------------------

--
-- Table structure for table `dairy_plan`
--

CREATE TABLE `dairy_plan` (
  `dairy_id` int(11) NOT NULL,
  `duser_id` int(11) NOT NULL,
  `school_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `trade` varchar(255) NOT NULL,
  `level` int(11) NOT NULL,
  `topic` varchar(255) NOT NULL,
  `activity` text NOT NULL,
  `application` text DEFAULT NULL,
  `observation` text DEFAULT NULL,
  `academic_year` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `dairy_plan`
--

INSERT INTO `dairy_plan` (`dairy_id`, `duser_id`, `school_id`, `course_id`, `date`, `start_time`, `end_time`, `trade`, `level`, `topic`, `activity`, `application`, `observation`, `academic_year`) VALUES
(8, 3, 3, 18, '2025-03-05', '14:40:00', '15:40:00', 'TOR', 5, ' 3 similtaniours', 'activity test', 'sflkssd', 'sd msdf', 7),
(9, 3, 3, 18, '2025-03-06', '14:40:00', '15:40:00', 'TOR', 5, 'Ibisazi', 'Maybe dascocmkzxl', 'sflkssd', 'sd msdf', 7),
(10, 3, 3, 18, '2025-03-06', '14:40:00', '15:40:00', 'TOR', 5, 'Ibisazi', 'Maybe dascocmkzxl', 'sflkssd', 'sd msdf', 7),
(11, 3, 3, 18, '2025-03-07', '14:40:00', '15:40:00', 'TOR', 5, 'Ibisazi', 'Maybe dascocmkzxl', 'sflkssd', 'sd msdf', 7),
(12, 2, 1, 13, '2025-03-07', '16:53:00', '18:53:00', 'MAS', 3, 'Ibisazi', 'Maybe dascocmkzxl', 'jn,', 'ijlk', 7),
(13, 2, 1, 13, '2025-03-08', '16:53:00', '18:53:00', 'MAS', 3, 'Ibisazi', 'Maybe dascocmkzxl', 'jn,', 'ijlk', 7),
(14, 2, 1, 11, '2025-03-07', '16:25:00', '17:25:00', 'MAS', 3, 'Session', 'Active hours', 'kmzxv', 'euryuier', 7),
(15, 2, 1, 11, '2025-03-07', '16:25:00', '17:25:00', 'MAS', 3, 'Session', 'Active hours', 'kmzxv', 'euryuier', 7),
(16, 2, 1, 12, '2025-03-07', '16:30:00', '16:34:00', 'MAS', 3, 'Session', 'Active hours', 'xzc', 'sac', 7),
(18, 2, 1, 12, '2025-03-09', '16:34:00', '17:35:00', 'MAS', 4, 'Mining and seling', 'Active hours', '12qs', 'asdasd', 7),
(19, 2, 1, 13, '2025-03-08', '16:40:00', '16:41:00', 'MAS', 4, 'Session', 'Active hours', 'asd', 'addcad', 7),
(29, 2, 1, 13, '2025-03-10', '12:55:00', '15:55:00', 'Software Development', 3, ' 3 similtaniours', 'Active hours', 'dvsv', 'asdas', 7),
(30, 2, 1, 13, '2025-03-10', '12:55:00', '15:55:00', 'Software Development', 3, ' 3 similtaniours', 'Active hours', 'dvsv', 'asdas', 7),
(31, 5, 1, 23, '2025-03-10', '13:29:00', '14:29:00', 'Software Development', 4, ' 3 similtaniours', 'Active hours', ',mdskmkdnf', 'wiorje89ruoewirlmkdmc.,', 7),
(32, 2, 1, 13, '2025-03-12', '12:07:00', '13:07:00', 'SOD', 5, ' 3 similtaniours', 'Active hours', '', '', 7);

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `message_id` int(11) NOT NULL,
  `muser_id` int(11) NOT NULL,
  `mschl_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` enum('read','unread') DEFAULT 'unread'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`message_id`, `muser_id`, `mschl_id`, `message`, `time`, `status`) VALUES
(42, 1, 1, 'wertyuiio', '2025-03-11 11:11:50', 'read'),
(43, 1, 1, 'kevin', '2025-03-11 11:11:50', 'read'),
(44, 1, 1, 'jksa', '2025-03-11 11:11:50', 'read'),
(45, 1, 1, 'jkhds', '2025-03-11 11:11:50', 'read'),
(46, 1, 1, 'iouweiof', '2025-03-11 11:05:18', 'read'),
(47, 1, 1, 'mkomiasd', '2025-03-11 11:52:27', 'read'),
(48, 6, 3, 'ulala', '2025-03-11 13:28:04', 'unread'),
(49, 15, 1, 'nm', '2025-03-11 13:29:51', 'unread');

-- --------------------------------------------------------

--
-- Table structure for table `schema_of_work`
--

CREATE TABLE `schema_of_work` (
  `schema_id` int(11) NOT NULL,
  `ssschl_id` int(11) NOT NULL,
  `ssuser_id` int(11) NOT NULL,
  `sscourse_id` int(11) NOT NULL,
  `ssdate` date NOT NULL,
  `schema_doc` varchar(250) NOT NULL,
  `action_time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `ssstatus` enum('none','pending','approved','rejected') DEFAULT 'none'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `schema_of_work`
--

INSERT INTO `schema_of_work` (`schema_id`, `ssschl_id`, `ssuser_id`, `sscourse_id`, `ssdate`, `schema_doc`, `action_time`, `ssstatus`) VALUES
(1, 1, 2, 12, '2025-03-07', '2. Session plan for PHP PROGRAMMING.pdf', '2025-03-11 12:16:53', 'none'),
(2, 1, 2, 12, '2025-03-07', 'text.pdf', '2025-03-11 12:16:53', 'none'),
(3, 1, 2, 12, '2025-03-07', 'text.pdf', '2025-03-11 12:16:53', 'none'),
(4, 1, 5, 24, '2025-03-10', 'text.pdf', '2025-03-11 12:16:53', 'none'),
(5, 1, 2, 22, '2025-03-11', 'file (1).pdf', '2025-03-11 12:33:43', 'pending'),
(6, 1, 2, 22, '2025-03-11', 'file.pdf', '2025-03-11 12:16:53', 'none');

-- --------------------------------------------------------

--
-- Table structure for table `schools`
--

CREATE TABLE `schools` (
  `school_id` int(11) NOT NULL,
  `school_name` varchar(100) NOT NULL,
  `location` varchar(250) NOT NULL,
  `school_logo` varchar(250) NOT NULL,
  `school_desc` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `schools`
--

INSERT INTO `schools` (`school_id`, `school_name`, `location`, `school_logo`, `school_desc`) VALUES
(1, 'Matare TSS', 'Rusizi-nkungu', 'icon.png', 'Lived soon'),
(3, 'Giheke Tss', 'Rusizi-Giheke', '67af39641cd77.PNG', 'Better school'),
(6, 'Muganza', 'Rusizi - Bugarama', '67b6dd7f7b8c7.jpg', 'Better school looere'),
(7, 'SoftKeva', 'Rusizi-kmb', 'icon.png', 'description');

-- --------------------------------------------------------

--
-- Table structure for table `session_plan`
--

CREATE TABLE `session_plan` (
  `session_id` int(11) NOT NULL,
  `sschl_id` int(11) NOT NULL,
  `suser_id` int(11) NOT NULL,
  `scourse_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `session_doc` varchar(250) NOT NULL,
  `action_time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `sstatus` enum('none','pending','approved','rejected') NOT NULL DEFAULT 'none'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `session_plan`
--

INSERT INTO `session_plan` (`session_id`, `sschl_id`, `suser_id`, `scourse_id`, `date`, `session_doc`, `action_time`, `sstatus`) VALUES
(7, 1, 2, 22, '2025-03-10', 'School Organizer .pptx.pdf', '2025-03-10 13:24:38', 'approved'),
(10, 1, 5, 24, '2025-03-11', 'School Organizer .pptx.pdf', '2025-03-11 08:45:36', 'none'),
(12, 1, 2, 22, '2025-03-11', 'file.pdf', '2025-03-14 07:02:39', 'pending'),
(13, 1, 2, 13, '2025-03-11', 'file.pdf', '2025-03-14 07:03:59', 'approved'),
(14, 1, 2, 22, '2025-03-14', 'm.pdf', '2025-03-14 07:03:52', 'rejected');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(200) NOT NULL,
  `nat_id` varchar(20) NOT NULL,
  `tel` varchar(20) NOT NULL,
  `degree` varchar(50) NOT NULL,
  `title` varchar(100) NOT NULL,
  `email` varchar(250) NOT NULL,
  `school` int(11) NOT NULL,
  `password` varchar(100) NOT NULL,
  `re_password` varchar(100) NOT NULL,
  `user_image` varchar(250) NOT NULL,
  `user_status` enum('pending','approved') NOT NULL DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `nat_id`, `tel`, `degree`, `title`, `email`, `school`, `password`, `re_password`, `user_image`, `user_status`) VALUES
(1, 'kubana kevin', '1234567891234569', '0788804113', 'A0', 'Master', 'kubanakevin@gmail.com', 1, '$2y$10$7tADcr.tc8x6g3gXc/9fiuFnNaOrmaggOPN3VIU6qOWh1GnCAhk5W', '123', 'kevin logo.PNG', 'approved'),
(2, 'Regis Niyoyandemye', '1234567891234566', '0788804110', 'A2', 'Trainer', 'regis@gmail.com', 1, '$2y$10$Nl5HNpF4DVGZXRxeQzvfQOOlLBlUO7o.Z9029mRkk0qujJin8v4km', '123', 'jjustin.PNG', 'approved'),
(3, 'Niyonzima Pacifique', '1234567891234567', '0788804116', 'A1', 'Trainer', 'pacifique587@gmail.com ', 3, '$2y$10$RYQgvZ9aum4vAQLfxr0EteeT.CNocxk2wEvSXkHwStCT8mELCWoYq', '123', 'FB_IMG_1704384945150.jpg', 'approved'),
(4, 'Olivier niyongabo', '765342145', '0788804116', 'A2', 'Trainer', 'kevin@gmail.com', 1, '$2y$10$EnC1YiEdijYUKC.6NoksEeNKT7CGWfw2YtuVAWhEk.29UPncnpIb.', '123', 'WhatsApp Image 2025-02-28 at 13.33.36.jpeg', 'approved'),
(5, 'Christian nshuti', '523465645', '0788894113', 'A0', 'Trainer', 'nibosedavid@gmail.com', 1, '$2y$10$q2FBFhKRgoUoKh0LQ8sl/ujpVAO37bONjypFIdU.ZjbL.mKZpp262', '123', 'FB_IMG_1722715646242.jpg', 'approved'),
(6, 'Nibose David', '1234567891234569', '0788804113', 'A0', 'Master', 'bibosedavid@gmail.com', 3, '$2y$10$zia5epa1PT1Q6S1Z84bjZefNCWIjl2DdYghpvJiOFOV54rvCMaCg.', '123', 'Anitha.PNG', 'approved'),
(7, 'divine', '1234567891234567', '0788804116', 'A2', 'Trainer', 'Divine@devias.io', 3, '$2y$10$DnP3emY8CtJFt29VJIarveZymKy4HfRKfAHw/BMl9QGi4NnLX32VS', '123', 'Screenshot (7).png', 'approved'),
(9, 'System Admin', '0000000000000', '0000000', 'Prof', 'Admin', 'admin@gmail.com', 7, '$2y$10$vdiqysYB1EiPWQgEMU5ZZOwI2YN5wwNMGretAZDwu6tQuUD1TSJfe', '123', 'icon.png', 'approved'),
(15, 'Matare Dos', '1234567891234566', '0788804116', 'A0', 'Dos', 'mataredos@gmail.com', 1, '$2y$10$RKz02EUDtyc42N4inJYqJO5So7vPDW2aYgk19QbMD.hmiBU1rupum', '123', 'WhatsApp Image 2025-02-21 at 13.06.51.jpeg', 'approved'),
(16, 'Muganza User 2', '1234567891234567', '0788894113', 'A1', 'Trainer', 'muganza2@gmail.com', 6, '$2y$10$5mMKqrMNVM8M9GovSAdUfeEJ4SbjQlifat9FQCy3V3kJ91hOZapvS', '123', 'WhatsApp Image 2025-02-21 at 20.52.25.jpeg', 'approved'),
(17, 'Muganza User', '1234567891234567', '0788894113', 'A0', 'Master', 'master@gmail.com', 6, '$2y$10$jQ5OJtUHS1CxbltkvrGppu1LuO6CDA5d.OERIqRS55zCenLB2SP8C', '123', '20f10922d8494cd6a112c260e2257086-free.png', 'approved'),
(18, 'divine', '1234567891234567', '0788804113', 'A2', 'Trainer', 'oacifique587@gmail.com', 3, '$2y$10$sRCyT37TAC7YM15ZSE49fuStzbxrqeKfInFFJyMVaCc6lDd8BUgny', '123', 'defout_image.png', 'pending'),
(19, 'libose David', '1234567891234567', '0788804113', 'A2', 'Trainer', 'tacifique587@gmail.com', 3, '$2y$10$DZVgTRvtngdUnaVitRMKF.Pic.iew2EawbSjyXZcM90jV6a0MTqKa', '111', 'defout.png', 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `visitors`
--

CREATE TABLE `visitors` (
  `id` int(11) NOT NULL,
  `ip_address` varchar(50) NOT NULL,
  `visit_time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `visitors`
--

INSERT INTO `visitors` (`id`, `ip_address`, `visit_time`) VALUES
(1, '::1', '2025-03-06 12:25:22'),
(2, '::1', '2025-03-06 12:26:21'),
(3, '::1', '2025-03-06 13:39:20'),
(4, '::1', '2025-03-06 14:15:10'),
(5, '::1', '2025-03-06 18:53:05'),
(6, '::1', '2025-03-06 19:00:35'),
(7, '::1', '2025-03-06 19:01:17'),
(8, '::1', '2025-03-07 11:41:52'),
(9, '::1', '2025-03-07 13:59:06'),
(10, '::1', '2025-03-08 20:35:13'),
(11, '::1', '2025-03-08 20:39:03'),
(12, '::1', '2025-03-08 21:08:04'),
(13, '::1', '2025-03-08 21:37:52'),
(14, '::1', '2025-03-08 21:41:45'),
(15, '::1', '2025-03-08 22:01:41'),
(16, '::1', '2025-03-08 22:02:20'),
(17, '::1', '2025-03-08 23:52:26'),
(18, '::1', '2025-03-09 00:04:46'),
(19, '::1', '2025-03-09 00:08:45'),
(20, '::1', '2025-03-09 19:59:47'),
(21, '::1', '2025-03-09 20:07:03'),
(22, '::1', '2025-03-10 08:33:39'),
(23, '::1', '2025-03-10 08:34:15'),
(24, '::1', '2025-03-10 11:26:28'),
(25, '::1', '2025-03-10 11:32:13'),
(26, '::1', '2025-03-10 12:39:42'),
(27, '::1', '2025-03-10 12:54:23'),
(28, '::1', '2025-03-11 08:09:31'),
(29, '::1', '2025-03-11 08:44:57'),
(30, '::1', '2025-03-11 09:06:47'),
(31, '::1', '2025-03-11 11:04:40'),
(32, '::1', '2025-03-11 13:25:39'),
(33, '::1', '2025-03-11 13:28:27'),
(34, '127.0.0.1', '2025-03-12 08:24:18'),
(35, '::1', '2025-03-12 08:40:00'),
(36, '::1', '2025-03-12 08:42:37'),
(37, '::1', '2025-03-12 09:14:14'),
(38, '::1', '2025-03-12 09:35:47'),
(39, '::1', '2025-03-12 10:31:45'),
(40, '::1', '2025-03-13 10:43:04'),
(41, '::1', '2025-03-14 06:56:22'),
(42, '::1', '2025-03-14 07:03:24'),
(43, '::1', '2025-03-14 07:04:41'),
(44, '::1', '2025-03-14 07:05:11'),
(45, '::1', '2025-03-14 07:08:45'),
(46, '::1', '2025-03-14 07:09:31'),
(47, '::1', '2025-03-14 07:12:22'),
(48, '::1', '2025-03-14 07:28:14'),
(49, '::1', '2025-03-15 09:59:17'),
(50, '::1', '2025-03-17 08:09:39');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `academic_year`
--
ALTER TABLE `academic_year`
  ADD PRIMARY KEY (`academic_id`),
  ADD KEY `acuser_id` (`acuser_id`);

--
-- Indexes for table `assessment_plan`
--
ALTER TABLE `assessment_plan`
  ADD PRIMARY KEY (`assessment_id`),
  ADD KEY `school_id` (`aschl_id`),
  ADD KEY `user_id` (`auser_id`),
  ADD KEY `course_id` (`ascourse_id`),
  ADD KEY `res_trainer` (`res_trainer`);

--
-- Indexes for table `checklist`
--
ALTER TABLE `checklist`
  ADD PRIMARY KEY (`list_id`),
  ADD KEY `course_id` (`course_id`),
  ADD KEY `user_id` (`usr_id`),
  ADD KEY `schol_id` (`schol_id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`comment_id`),
  ADD KEY `message_id` (`message_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`course_id`),
  ADD KEY `schl_id` (`schl_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `dairy_plan`
--
ALTER TABLE `dairy_plan`
  ADD PRIMARY KEY (`dairy_id`),
  ADD KEY `user_id` (`duser_id`),
  ADD KEY `school_id` (`school_id`),
  ADD KEY `course_id` (`course_id`),
  ADD KEY `academic_year` (`academic_year`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`message_id`),
  ADD KEY `user_id` (`muser_id`),
  ADD KEY `schl_id` (`mschl_id`);

--
-- Indexes for table `schema_of_work`
--
ALTER TABLE `schema_of_work`
  ADD PRIMARY KEY (`schema_id`),
  ADD KEY `sscourse_id` (`sscourse_id`),
  ADD KEY `ssschl_id` (`ssschl_id`),
  ADD KEY `ssuser_id` (`ssuser_id`);

--
-- Indexes for table `schools`
--
ALTER TABLE `schools`
  ADD PRIMARY KEY (`school_id`);

--
-- Indexes for table `session_plan`
--
ALTER TABLE `session_plan`
  ADD PRIMARY KEY (`session_id`),
  ADD KEY `sschl_id` (`sschl_id`),
  ADD KEY `suser_id` (`suser_id`),
  ADD KEY `scourse_id` (`scourse_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD KEY `school_id` (`school`);

--
-- Indexes for table `visitors`
--
ALTER TABLE `visitors`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `academic_year`
--
ALTER TABLE `academic_year`
  MODIFY `academic_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `assessment_plan`
--
ALTER TABLE `assessment_plan`
  MODIFY `assessment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `checklist`
--
ALTER TABLE `checklist`
  MODIFY `list_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `comment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `course_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `dairy_plan`
--
ALTER TABLE `dairy_plan`
  MODIFY `dairy_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `message_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `schema_of_work`
--
ALTER TABLE `schema_of_work`
  MODIFY `schema_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `schools`
--
ALTER TABLE `schools`
  MODIFY `school_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `session_plan`
--
ALTER TABLE `session_plan`
  MODIFY `session_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `visitors`
--
ALTER TABLE `visitors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `academic_year`
--
ALTER TABLE `academic_year`
  ADD CONSTRAINT `academic_year_ibfk_1` FOREIGN KEY (`acuser_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `assessment_plan`
--
ALTER TABLE `assessment_plan`
  ADD CONSTRAINT `assessment_plan_ibfk_1` FOREIGN KEY (`aschl_id`) REFERENCES `schools` (`school_id`),
  ADD CONSTRAINT `assessment_plan_ibfk_3` FOREIGN KEY (`ascourse_id`) REFERENCES `courses` (`course_id`),
  ADD CONSTRAINT `assessment_plan_ibfk_4` FOREIGN KEY (`res_trainer`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `checklist`
--
ALTER TABLE `checklist`
  ADD CONSTRAINT `checklist_ibfk_1` FOREIGN KEY (`course_id`) REFERENCES `courses` (`course_id`),
  ADD CONSTRAINT `checklist_ibfk_2` FOREIGN KEY (`usr_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `checklist_ibfk_3` FOREIGN KEY (`schol_id`) REFERENCES `schools` (`school_id`);

--
-- Constraints for table `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `comments_ibfk_1` FOREIGN KEY (`message_id`) REFERENCES `messages` (`message_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `comments_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `courses`
--
ALTER TABLE `courses`
  ADD CONSTRAINT `courses_ibfk_1` FOREIGN KEY (`schl_id`) REFERENCES `schools` (`school_id`),
  ADD CONSTRAINT `courses_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `dairy_plan`
--
ALTER TABLE `dairy_plan`
  ADD CONSTRAINT `dairy_plan_ibfk_1` FOREIGN KEY (`duser_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `dairy_plan_ibfk_2` FOREIGN KEY (`school_id`) REFERENCES `schools` (`school_id`),
  ADD CONSTRAINT `dairy_plan_ibfk_3` FOREIGN KEY (`course_id`) REFERENCES `courses` (`course_id`),
  ADD CONSTRAINT `dairy_plan_ibfk_4` FOREIGN KEY (`academic_year`) REFERENCES `academic_year` (`academic_id`);

--
-- Constraints for table `messages`
--
ALTER TABLE `messages`
  ADD CONSTRAINT `messages_ibfk_1` FOREIGN KEY (`muser_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `messages_ibfk_2` FOREIGN KEY (`mschl_id`) REFERENCES `schools` (`school_id`);

--
-- Constraints for table `schema_of_work`
--
ALTER TABLE `schema_of_work`
  ADD CONSTRAINT `schema_of_work_ibfk_1` FOREIGN KEY (`sscourse_id`) REFERENCES `courses` (`course_id`),
  ADD CONSTRAINT `schema_of_work_ibfk_2` FOREIGN KEY (`ssschl_id`) REFERENCES `schools` (`school_id`),
  ADD CONSTRAINT `schema_of_work_ibfk_3` FOREIGN KEY (`ssuser_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `session_plan`
--
ALTER TABLE `session_plan`
  ADD CONSTRAINT `session_plan_ibfk_1` FOREIGN KEY (`sschl_id`) REFERENCES `schools` (`school_id`),
  ADD CONSTRAINT `session_plan_ibfk_2` FOREIGN KEY (`suser_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `session_plan_ibfk_3` FOREIGN KEY (`scourse_id`) REFERENCES `courses` (`course_id`);

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`school`) REFERENCES `schools` (`school_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
