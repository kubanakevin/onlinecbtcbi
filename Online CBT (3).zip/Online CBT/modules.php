<?php
require 'header.php';
require 'connection.php';

// session_start();
$school = $_SESSION['school'];
$user = $_SESSION['user_id'];

$itemsPerPage = 12;
$currentPage = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($currentPage - 1) * $itemsPerPage;

// Fetch courses securely
$sql = "SELECT * FROM courses WHERE schl_id = ? AND user_id = ? ORDER BY course_id DESC LIMIT ? OFFSET ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("iiii", $school, $user, $itemsPerPage, $offset);
$stmt->execute();
$result = $stmt->get_result();

// Count total courses
$sqlCount = "SELECT COUNT(*) AS total_items FROM courses WHERE schl_id = ? AND user_id = ?";
$stmtCount = $conn->prepare($sqlCount);
$stmtCount->bind_param("ii", $school, $user);
$stmtCount->execute();
$countResult = $stmtCount->get_result();
$row = $countResult->fetch_assoc();
$totalItems = $row['total_items'];
$totalPages = ceil($totalItems / $itemsPerPage);

?>
<style>
    .nav-link.activecmo {
        background-color: rgba(3, 29, 54, 0.56);
        color: white;
    }
    .item-card {
        background-color: #f8f9fa;
        transition: background-color 0.3s ease;
    }
    .item-card:hover {
        background-color: #e9ecef;
    }
</style>

<body>
    <div class="container mt-3">
        <h5>Trainer Modules</h5>
        <div class="row">
            <?php
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $courseId = $row['course_id'];

                    // Check counts of session_plan, schema_of_work, and assessment_plan
                    $query = "SELECT 
                                (SELECT COUNT(*) FROM session_plan WHERE scourse_id = ?) AS session_plan_count,
                                (SELECT COUNT(*) FROM schema_of_work WHERE sscourse_id = ?) AS schema_of_work_count,
                                (SELECT COUNT(*) FROM assessment_plan WHERE ascourse_id = ?) AS assessment_plan_count";
                    $stmtCheck = $conn->prepare($query);
                    $stmtCheck->bind_param("iii", $courseId, $courseId, $courseId);
                    $stmtCheck->execute();
                    $checkResult = $stmtCheck->get_result()->fetch_assoc();

                    $sessionPlanCount = $checkResult['session_plan_count'];
                    $schemaOfWorkCount = $checkResult['schema_of_work_count'];
                    $assessmentPlanCount = $checkResult['assessment_plan_count'];
            ?>
                    <div class="col-lg-3 mb-3">
                        <div class="d-flex justify-content-between align-items-center border p-3 rounded item-card">
                            <div>
                                <h5 class="mb-1"><?php echo htmlspecialchars($row['course_name']); ?></h5>
                                <p class="mb-0 text-muted">Level: <?php echo htmlspecialchars($row['course_level']); ?></p>

                                <span class="<?php echo $sessionPlanCount > 0 ? 'text-success' : 'text-danger'; ?>">
                                    Session Plan: 
                                    <?php echo $sessionPlanCount > 0 ? $sessionPlanCount . ' <i class="fa fa-check"></i>' : '<i class="fa fa-times"></i>'; ?>
                                </span><br>

                                <span class="<?php echo $schemaOfWorkCount > 0 ? 'text-success' : 'text-danger'; ?>">
                                    Schema of Work: 
                                    <?php echo $schemaOfWorkCount > 0 ? $schemaOfWorkCount . ' <i class="fa fa-check"></i>' : '<i class="fa fa-times"></i>'; ?>
                                </span><br>

                                <span class="<?php echo $assessmentPlanCount > 0 ? 'text-success' : 'text-danger'; ?>">
                                    Assessment Plan: 
                                    <?php echo $assessmentPlanCount > 0 ? $assessmentPlanCount . ' <i class="fa fa-check"></i>' : '<i class="fa fa-times"></i>'; ?>
                                </span><br>
                            </div>
                            <div class="dropdown">
                                <button class="btn btn-light border dropdown-toggle" type="button" data-bs-toggle="dropdown">
                                    <i class="fas fa-ellipsis-v"></i>
                                </button>
                                <ul class="dropdown-menu dropdown-menu-end">
                                    <li><a class="dropdown-item" href="add_session_plan.php?module=<?= $courseId ?>">Add Session Plan</a></li>
                                    <li><a class="dropdown-item" href="add_schema_of_work.php?module=<?= $courseId ?>">Add Schema of Work</a></li>
                                    <li><a class="dropdown-item" href="add_assessment_plan.php?module=<?= $courseId ?>">Add Assessment Plan</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
            <?php
                }
            } else {
                echo "<p class='text-center'>No Data found.</p>";
            }
            ?>
        </div>

        <!-- Pagination Controls -->
        <nav>
            <ul class="pagination mt-3 justify-content-center">
                <?php for ($i = 1; $i <= $totalPages; $i++) { ?>
                    <li class="page-item <?= ($i == $currentPage) ? 'active' : ''; ?>">
                        <a class="page-link" href="?page=<?= $i; ?>"><?= $i; ?></a>
                    </li>
                <?php } ?>
            </ul>
        </nav>
    </div>
</body>

<?php require 'footer.php'; ?>

<script src="https://kit.fontawesome.com/a076d05399.js"></script>
