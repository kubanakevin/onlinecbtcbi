<?php
require 'header.php';
include('connection.php'); // Include the database connection

// Handle school deletion via AJAX
if (isset($_POST['delete_school_id'])) {
    $school_id = $_POST['delete_school_id'];

    $sql = "DELETE FROM schools WHERE school_id = '$school_id'";
    if (mysqli_query($conn, $sql)) {
        echo json_encode(['status' => 'success', 'message' => 'The school has been deleted successfully.']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'There was an issue deleting the school.']);
    }
    exit();
}

// Handle fetching school data for editing
if (isset($_POST['fetch_school_id'])) {
    $school_id = $_POST['fetch_school_id'];
    $query = "SELECT * FROM schools WHERE school_id = '$school_id'";
    $result = mysqli_query($conn, $query);

    if ($row = mysqli_fetch_assoc($result)) {
        echo json_encode(['status' => 'success', 'data' => $row]);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'School not found.']);
    }
    exit();
}

// Handle adding and updating school
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['school_name'])) {
    $school_id = $_POST['school_id'] ?? null;
    $school_name = $_POST['school_name'];
    $location = $_POST['location'];
    $school_desc = $_POST['school_desc'];
    $school_logo_name = null;

    // Handle file upload
    if (isset($_FILES['school_logo']) && $_FILES['school_logo']['error'] == 0) {
        $school_logo = $_FILES['school_logo']['name'];
        $tmp_name = $_FILES['school_logo']['tmp_name'];
        $file_extension = pathinfo($school_logo, PATHINFO_EXTENSION);
        $allowed_extensions = ['jpg', 'jpeg', 'png'];

        if (in_array($file_extension, $allowed_extensions)) {
            $school_logo_name = uniqid() . '.' . $file_extension;
            $upload_folder = 'uploaded_file/' . $school_logo_name;
            move_uploaded_file($tmp_name, $upload_folder);
        } else {
            echo "<script>alert('Invalid file type for school logo.');</script>";
            exit();
        }
    }

    if (!empty($school_name) && !empty($location) && !empty($school_desc)) {
        if ($school_id) {
            // Update school
            $sql = "UPDATE schools SET school_name='$school_name', location='$location', school_desc='$school_desc' ";
            if ($school_logo_name) {
                $sql .= ", school_logo='$school_logo_name' ";
            }
            $sql .= "WHERE school_id='$school_id'";
        } else {
            // Insert new school
            $sql = "INSERT INTO schools (school_name, location, school_desc, school_logo) 
                    VALUES ('$school_name', '$location', '$school_desc', '$school_logo_name')";
        }

        if (mysqli_query($conn, $sql)) {
            echo "<script>alert('School saved successfully'); window.location.href = 'schools.php';</script>";
        } else {
            echo "<script>alert('Error: Unable to save school.');</script>";
        }
    } else {
        echo "<script>alert('Please fill in all fields');</script>";
    }
}
?>
<style>
    .nav-link.actives {
        background-color: rgba(3, 29, 54, 0.56);
        color: white;
    }
</style>
<!-- Add School Button -->
<div class="event text-right">
    <p class="p-t-13">
        <a href="#" data-toggle="modal" data-target="#addSchoolModal"><i class="fa fa-plus"></i> Add School</a>
    </p>
</div>

<!-- School Table -->
<div class="row" style="overflow-x: scroll;">
    <table class="table table-hover table-bordered bg-white" id="sampleTable">
        <thead>
            <tr>
                <th>School Logo</th>
                <th>School Name</th>
                <th>Location</th>
                <th>School Motto</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $sql = "SELECT * FROM schools ORDER BY school_id DESC";
            $select = mysqli_query($conn, $sql);
            while ($rows = mysqli_fetch_array($select)) {
            ?>
                <tr>
                    <td><img src="uploaded_file/<?=$rows['school_logo']?>" alt="" style="width: 4rem;height: 4rem;border-radius: 20px;"></td>
                    <td><?=$rows['school_name']?></td>
                    <td><?=$rows['location']?></td>
                    <td><?=$rows['school_desc']?></td>
                    <td>
                        <a href="#" class="edit-school" data-id="<?=$rows['school_id']?>"><i class="fa fa-edit text-info" style="font-size: 25px; margin-right: 10px;"></i></a>
                        <a href="#" class="delete-school" data-id="<?=$rows['school_id']?>"  data-target="#addSchoolModal"><i class="fa fa-trash text-danger" style="font-size: 25px;"></i></a>
                    </td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</div>

<!-- Add/Edit School Modal -->
<div class="modal fade" id="addSchoolModal" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">School Form</h5>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <form id="schoolForm" method="POST" enctype="multipart/form-data">
                    <input type="hidden" id="school_id" name="school_id">
                    
                    <label>School Name</label>
                    <input type="text" id="school_name" name="school_name" class="form-control" required><br>

                    <label>Location</label>
                    <input type="text" id="location" name="location" class="form-control" required><br>

                    <label>School Motto</label>
                    <input type="text" id="school_desc" name="school_desc" class="form-control" required><br>

                    <label>School Logo</label>
                    <input type="file" id="school_logo" name="school_logo" class="form-control"><br>
                    <!-- <img id="school_logo_preview" src="" style="width: 100px; height: 100px; border-radius: 10px;"><br> -->

                    <input type="submit" class="btn btn-dark col-lg-12" value="Save School">
                </form>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    $(".edit-school").click(function() {
        var school_id = $(this).data("id");

        $.ajax({
            url: "",
            type: "POST",
            data: { fetch_school_id: school_id },
            dataType: "json",
            success: function(response) {
                if (response.status === "success") {
                    $("#school_id").val(response.data.school_id);
                    $("#school_name").val(response.data.school_name);
                    $("#location").val(response.data.location);
                    $("#school_desc").val(response.data.school_desc);
                    $("#school_logo_preview").attr("src", "uploaded_file/" + response.data.school_logo);
                    $("#addSchoolModal").modal("show");
                } else {
                    Swal.fire("Error", "Failed to load school data.", "error");
                }
            }
        });
    });

    $(".delete-school").click(function(e) {
        e.preventDefault();
        var school_id = $(this).data("id");

        Swal.fire({
            title: "Are you sure?",
            text: "This action cannot be undone.",
            icon: "warning",
            showCancelButton: true,
            confirmButtonText: "Yes, delete it!",
        }).then((result) => {
            if (result.isConfirmed) {
                $.post("", { delete_school_id: school_id }, function(response) {
                    location.reload();
                });
            }
        });
    });
});
</script>

<?php require 'footer.php'; ?>
