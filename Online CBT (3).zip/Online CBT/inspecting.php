<?php
// Include connection to the database
include('connection.php');

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Get the form data
    $user_id = $_POST['user_id'];
    $course_id = $_POST['course_id']; // Fixed the extra space issue
    $school_id = $_POST['schol_id'];
    // $date = $_POST['date'];
    $period = $_POST['period'];
    $trade = $_POST['trade'];
    $level = $_POST['level'];
    $num_trainees = $_POST['num_trainees'];
    $module_name = $_POST['mcdco'];
    $topic = $_POST['topic'];

    // Pedagogical Documents
    $sowr = $_POST['sowr'];
    $spaef = $_POST['spaef'];
    $cdau = $_POST['cdau'];
    $caleu = $_POST['caleu'];

    // Session Delivery
    $tmsbpcetrewa = $_POST['tmsbpcetrewa'];
    $fta = $_POST['fta'];
    $taau = $_POST['taau'];
    $dmau = $_POST['dmau'];
    $tsp = $_POST['tsp'];
    $ciwm = $_POST['ciwm'];
    $leic = $_POST['leic'];
    $avg_sum = $sowr + $spaef + $cdau + $caleu + $tmsbpcetrewa + $fta + $taau + $dmau + $tsp + $ciwm + $leic;
    // Strong Points and Area of Improvement
    $strong_point = $_POST['strong_point'];
    $area_of_improv = $_POST['area_of_improv'];

    // Prepare SQL query to insert data into the checklist table
    $query = "INSERT INTO checklist (
        usr_id, course_id, schol_id, period, trade, level, no_trainees, mcdco, topic, 
        sowr, spaef, cdau, caleu, tmsbpcetrewa, fta, taau, dmau, tsp, ciwm, leic, avg_sum, strong_point, area_of_improv
    ) VALUES (
        '$user_id', '$course_id', '$school_id', '$period', '$trade', '$level', '$num_trainees', '$module_name', '$topic', 
        '$sowr', '$spaef', '$cdau', '$caleu', '$tmsbpcetrewa', '$fta', '$taau', '$dmau', '$tsp', '$ciwm', '$leic', '$avg_sum', '$strong_point', '$area_of_improv'
    )";

    // Execute the query
    if (mysqli_query($conn, $query)) {
        echo "<script> alert('Inpection finished up!')</script>" . "<script>location.href='trainers.php'</script>";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>

<?php
require 'header.php';
include('connection.php'); // Include the database connection
?>
<style>
    .nav-link.activet {
        background-color: rgba(3, 29, 54, 0.56);
        color: white;
    }
</style>
<!-- Add the Step Indicator -->
<div class="row">
    <div class="col-lg-12 text-center">
    <h5>Trainer Checklist</h5>
        <h4>Step <span id="step-indicator">1</span> of 4</h4> <!-- Display current step -->
        <div class="progress" style="height: 25px;">
            <div id="progress-bar" class="progress-bar progress-bar-striped" style="width: 25%;"></div>
        </div>
    </div>
</div><br>

<div class="row">
    <div class="form-container col-lg-12 bg-white" style="padding: 30px">
        

        <form action="" method="POST" enctype="multipart/form-data" id="trainer-form">

            <!-- ============= Step 1 Trainer Information ================= -->
            <div class="form-step" id="step-1">
                <h4>Trainer Information</h4>
                <div class="input-group input-group-outline">
                    <label for="">Trainer Name</label>
                    <select name="user_id" class="form-control">
                        <?php
                        include('connection.php');
                        $trainer = $_GET['trainer'];
                        $school = $_SESSION['school'];
                        $select = mysqli_query($conn, "SELECT * FROM users, schools WHERE users.school = schools.school_id AND user_id = '$trainer' AND school = '$school'");
                        while ($row = mysqli_fetch_array($select)) {
                        ?>
                            <option value="<?=$row['user_id']?>"><?=$row['username']?></option>
                        <?php
                        }
                        ?>
                    </select>
                </div><br>
                <div class="input-group input-group-outline">
                    <label for="">Course Name</label>
                    <select name="course_id" class="form-control">
                        <?php
                        include('connection.php');
                        $select = mysqli_query($conn, "SELECT * FROM courses WHERE user_id = '$trainer'");
                        while ($row = mysqli_fetch_array($select)) {
                        ?>
                            <option value="<?=$row['course_id']?>"><?=$row['course_name']?></option>
                        <?php
                        }
                        ?>
                    </select>
                </div><br>

                <?php
                include('connection.php');
                $id = $_SESSION['user_id'];
                $select = mysqli_query($conn, "SELECT * FROM users, schools WHERE users.school = schools.school_id AND user_id='$id'");
                while ($row = mysqli_fetch_assoc($select)) {
                ?>
                    <input class="input100" type="hidden" name="schol_id" value="<?=$row['school']?>" class="form-control">
                <?php
                }
                ?>
                <div class="input-group input-group-outline">
                    <label class="form-label">Period</label>
                    <input type="text" name="period" class="form-control" required>
                </div><br>

                <div class="input-group input-group-outline">
                    <label class="form-label">Trade</label>
                    <input type="text" name="trade" class="form-control" required>
                </div><br>

                <div class="input-group input-group-outline">
                    <label class="form-label">Level</label>
                    <input type="text" name="level" class="form-control" required>
                </div><br>

                <div class="input-group input-group-outline">
                    <label class="form-label">Number Of Trainees</label>
                    <input type="text" name="num_trainees" class="form-control" required>
                </div><br>

                <div class="input-group input-group-outline">
                    <label class="form-label">Module Name</label>
                    <input type="text" name="mcdco" class="form-control" required>
                </div><br>

                <div class="input-group input-group-outline">
                    <label class="form-label">Topic Of Session</label>
                    <input type="text" name="topic" class="form-control" required>
                </div><br>

                <button type="button" class="btn btn-dark next-btn" onclick="nextStep(2)">Next</button>
            </div>

            <!-- ============= Step 2 Pedagogical Documents ================= -->
            <div class="form-step" id="step-2" style="display: none;">
                <h4>Pedagogical Documents</h4>
                
                <!-- Repeated Inputs for Pedagogical Section -->
                <?php
                $pedagogical_fields = [
                    'Scheme of work is respected' => 'sowr',
                    'Session plan is available and effectively followed' => 'spaef',
                    'Class Daily is available and up to time' => 'cdau',
                    'Class Attendance list is effectively used' => 'caleu'
                ];
                foreach ($pedagogical_fields as $label => $name) {
                ?>
                    <div class="input-group input-group-outline">
                        <label class="form-label"><?= $label ?></label>
                        <select name="<?= $name ?>" class="form-control">
                            <option value=""></option>
                            <option value="1">Very poor</option>
                            <option value="2">Poor</option>
                            <option value="3">Good</option>
                            <option value="4">Very good</option>
                            <option value="5">Excellent</option>
                        </select>
                    </div><br>
                <?php } ?>
                
                <button type="button" class="btn btn-dark prev-btn" onclick="prevStep(1)">Previous</button>
                <button type="button" class="btn btn-dark next-btn" onclick="nextStep(3)">Next</button>
            </div>

            <!-- ============= Step 3 Session Delivery ================= -->
            <div class="form-step" id="step-3" style="display: none;">
                <h4>Session Delivery</h4>
                
                <!-- Repeated Inputs for Session Delivery Section -->
                <?php
                $session_delivery_fields = [
                    'Trainer masters the subject by providing clear explanations' => 'tmsbpcetrewa',
                    'Facilitation techniques (Variation, Relevance, Quality of Handling questions) is applied' => 'fta',
                    'Teaching aids are used (Variation, Relevance, Quality, Effectiveness)' => 'taau',
                    'Didactic materials are used (Variation, Relevance, Quality, Effectiveness)' => 'dmau',
                    'Trainer\'s Self-presentation (proper work attire, language, body language)' => 'tsp',
                    'Class is well managed (Handling interruptions)' => 'ciwm',
                    'Learning environment is conducive (Organization, Safety, cleanliness)' => 'leic'
                ];
                foreach ($session_delivery_fields as $label => $name) {
                ?>
                    <div class="input-group input-group-outline">
                        <label class="form-label"><?= $label ?></label>
                        <select name="<?= $name ?>" class="form-control">
                            <option value=""></option>
                            <option value="1">Very poor</option>
                            <option value="2">Poor</option>
                            <option value="3">Good</option>
                            <option value="4">Very good</option>
                            <option value="5">Excellent</option>
                        </select>
                    </div><br>
                <?php } ?>
                
                <button type="button" class="btn btn-dark prev-btn" onclick="prevStep(2)">Previous</button>
                <button type="button" class="btn btn-dark next-btn" onclick="nextStep(4)">Next</button>
            </div>

            <!-- ============= Step 4 Strong Point and Improvement ================= -->
            <div class="form-step" id="step-4" style="display: none;">
                <h4>Strong Point & Area of Improvement</h4>

                <div class="input-group input-group-outline">
                    <label class="form-label">Strong Point</label>
                    <input type="text" name="strong_point" class="form-control" style="height: 4rem;">
                </div><br>

                <div class="input-group input-group-outline">
                    <label class="form-label">Area Of Improvement</label>
                    <input type="text" name="area_of_improv" class="form-control" style="height: 4rem;">
                </div><br>

                <button type="button" class="btn btn-dark prev-btn" onclick="prevStep(3)">Previous</button>
                <input type="submit" class="btn btn-dark col-lg-12" value="Finish Checking">
            </div>
            
        </form>
    </div>
</div>

<script>
    // JavaScript to handle next/previous buttons functionality
    function nextStep(step) {
        document.getElementById('step-' + (step - 1)).style.display = 'none';
        document.getElementById('step-' + step).style.display = 'block';
        updateProgress(step);
    }

    function prevStep(step) {
        document.getElementById('step-' + (step + 1)).style.display = 'none';
        document.getElementById('step-' + step).style.display = 'block';
        updateProgress(step);
    }

    function updateProgress(step) {
        // Update the step indicator and progress bar
        document.getElementById('step-indicator').innerText = step;
        let progress = (step - 1) * 33.33; // Each step represents 25% of the progress
        document.getElementById('progress-bar').style.width = progress + '%';
    }
</script>

<?php
require 'footer.php';
?>
