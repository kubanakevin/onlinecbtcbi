<?php
// Include database connection
include('connection.php');

// Folder where files will be uploaded
$uploadDir = 'uploaded_files/';

// Check if the folder exists, create it if not
if (!file_exists($uploadDir)) {
    mkdir($uploadDir, 0777, true);
}

$message = ''; // For storing messages to be displayed in the alert box
$alertType = ''; // For storing the alert type (success or error)

// Insert data into the database if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['file'])) {
    // Get the form inputs
    $user_id = $_POST['user_id'];
    $schl_id = $_POST['school_id'];
    $trade = $_POST['trade'];
    $course_name = $_POST['course_name'];
    $period = $_POST['period'];
    $course_level = $_POST['course_level'];

    // Check if the school ID exists in the schools table
    $checkSchoolQuery = "SELECT * FROM schools WHERE school_id = ?";
    $stmtCheckSchool = $conn->prepare($checkSchoolQuery);
    $stmtCheckSchool->bind_param("i", $schl_id);
    $stmtCheckSchool->execute();
    $schoolResult = $stmtCheckSchool->get_result();

    if ($schoolResult->num_rows === 0) {
        // School ID does not exist in the database
        $message = 'The selected School ID does not exist. Please select a valid School.';
        $alertType = 'error';
    } else {
        // Proceed with file upload and database insertion if the school ID is valid
        // Get file details
        $fileName = $_FILES['file']['name']; // Original file name
        $fileTmpName = $_FILES['file']['tmp_name'];
        $fileSize = $_FILES['file']['size'];
        $fileError = $_FILES['file']['error'];
        $fileType = $_FILES['file']['type'];

        // Allow only PDF files
        $allowedExtensions = array('pdf');
        $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

        if (in_array($fileExt, $allowedExtensions)) {
            if ($fileError === 0) {
                if ($fileSize < 5000000) {  // Limit to 5MB size
                    // Move the file to the upload directory using the original file name
                    $fileDestination = $uploadDir . $fileName;

                    // Check if file already exists, if so append a number to the name to avoid overwriting
                    $filePath = $fileDestination;
                    $i = 1;
                    while (file_exists($filePath)) {
                        $filePath = $uploadDir . pathinfo($fileName, PATHINFO_FILENAME) . '_' . $i . '.' . $fileExt;
                        $i++;
                    }

                    // Move the file to the upload directory
                    if (move_uploaded_file($fileTmpName, $filePath)) {
                        // Store only the file name in the database (not the full path)
                        $fileNameOnly = basename($filePath); // Extract just the file name

                        // Insert data into the database with the file name
                        $sql = "INSERT INTO courses (user_id, schl_id, trade, course_name, period, course_level, file) 
                                VALUES (?, ?, ?, ?, ?, ?, ?)";
                        $stmt = $conn->prepare($sql);
                        $stmt->bind_param("iisssss", $user_id, $schl_id, $trade, $course_name, $period, $course_level, $fileNameOnly);

                        if ($stmt->execute()) {
                            // Set message for success
                            $message = "<script> alert('Course uploaded and information stored successfully!')</script>";
                            $alertType = 'success';
                            
                            // Redirect to courses.php after success
                            header("Location: trainer_documents.php");
                            exit; // Ensure the script stops executing after the redirect
                        } else {
                            $message = 'Error: ' . $stmt->error;
                            $alertType = 'error';
                        }
                    } else {
                        $message = 'There was an error uploading the file.';
                        $alertType = 'error';
                    }
                } else {
                    $message = 'File is too large!';
                    $alertType = 'error';
                }
            } else {
                $message = 'Error uploading file!';
                $alertType = 'error';
            }
        } else {
            $message = 'Only PDF files are allowed!';
            $alertType = 'error';
        }
    }
}

require 'header.php';

// Fetch users for user_id dropdown
$school = $_SESSION['school'];
$title = $_SESSION['title'];
$user = $_SESSION['user_id'];
$user_id = $_GET['trainer'];
$userQuery = "SELECT * FROM users WHERE school = ? AND title = 'Trainer' AND user_id = '$user_id'";
$stmtUser = $conn->prepare($userQuery);
$stmtUser->bind_param("s", $school);
$stmtUser->execute();
$userResult = $stmtUser->get_result();

// Fetch schools for schl_id dropdown
$schoolQuery = "SELECT * FROM schools WHERE school_id = ?";
$stmtSchool = $conn->prepare($schoolQuery);
$stmtSchool->bind_param("s", $school);
$stmtSchool->execute();
$schoolResult = $stmtSchool->get_result();
?>

<div class="container mt-5">
    <div class="row">
        <div class="form-container col-lg-6 bg-white" style="padding: 30px">
            <h5>Add Course</h5>
            <form action="" method="POST" enctype="multipart/form-data">
                <!-- User ID Dropdown -->
                <div class="input-group input-group-outline mb-3">
                    <label class="">Trainer Name</label>
                    <select name="user_id" class="form-control" required>
                        <?php
                        if ($userResult->num_rows > 0) {
                            while ($user = $userResult->fetch_assoc()) {
                                echo "<option value='" . $user['user_id'] . "'>" . $user['username'] . "</option>";
                            }
                        }
                        ?>
                    </select>
                </div>

                <!-- School ID Dropdown -->
                <div class="input-group input-group-outline mb-3">
                    <label class="">School Name</label><br>
                    <select name="school_id" class="form-control" required>
                        <?php
                        if ($schoolResult->num_rows > 0) {
                            while ($school = $schoolResult->fetch_assoc()) {
                                echo "<option value='" . $school['school_id'] . "'>" . $school['school_name'] . "</option>";
                            }
                        }
                        ?>
                    </select>
                </div>

                <!-- Trade Name -->
                <div class="input-group input-group-outline mb-3">
                    <label class="form-label">Trade Name</label>
                    <input type="text" name="trade" class="form-control" required>
                </div>
                <!-- Course Name -->
                <div class="input-group input-group-outline mb-3">
                    <label class="form-label">Course Name & Code</label>
                    <input type="text" name="course_name" class="form-control" required>
                </div>

                <!-- Period -->
                <div class="input-group input-group-outline mb-3">
                    <label class="form-label">Period</label>
                    <input type="text" name="period" class="form-control" required>
                </div>

                <!-- Course Level -->
                <div class="input-group input-group-outline mb-3">
                    <label class="form-label">Course Level</label>
                    <input type="text" name="course_level" class="form-control" required>
                </div>

                <!-- File Upload -->
                <div class="input-group input-group-outline mb-3">
                    <label class="">Choose PDF file</label>
                    <input type="file" name="file" class="form-control" accept=".pdf" required>
                </div>

                <!-- Submit Button -->
                <div class="smt-btn">
                    <input type="submit" class="btn btn-dark col-lg-12" value="Upload Course">
                </div>
            </form>
        </div>
    </div>
</div>

<?php if ($message): ?>
    <script>
        Swal.fire({
            icon: '<?php echo $alertType; ?>',
            title: '<?php echo $alertType === 'error' ? 'Error!' : 'Success!'; ?>',
            text: '<?php echo $message; ?>',
            confirmButtonText: 'OK'
        });
    </script>
<?php endif; ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<!-- Bootstrap JS and dependencies -->
<?php
require 'footer.php';
?>
