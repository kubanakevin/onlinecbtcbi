<?php
require 'header.php';
?>
<style>
    .nav-link.activet {
        background-color: rgba(3, 29, 54, 0.56);
        color: white;
    }
</style>
<div class="event text-right">
    <p class="p-t-13"><a href="add_trainer.php"><i class="fa fa-plus"></i> Add Trainer</a></p>
</div>
<div class="row" style="overflow-x: scroll;">
    <?php
    require 'connection.php';
    $school = $_SESSION['school'];
    $user_id = $_SESSION['user_id'];
    $title = $_SESSION['title'];
    if ($title == 'Admin') {
        $sql = "SELECT * FROM users, schools WHERE users.school = schools.school_id AND user_status = 'approved' ORDER BY user_id DESC";
    } elseif ($title == 'Master' || $title == 'Dos') {
        $sql = "SELECT * FROM users, schools WHERE users.school = schools.school_id AND users.school = '$school' AND user_status = 'approved' ORDER BY user_id DESC";
    }
    $select = mysqli_query($conn, $sql);
    if (!$select) {
        echo "<script>Swal.fire({ icon: 'error', title: 'Database Error', text: 'Failed to fetch trainers!' });</script>";
        exit;
    }
    ?>
    <table class="table table-hover table-bordered bg-white" id="sampleTable">
        <thead>
            <tr>
                <th>Trainer Image</th>
                <th>Trainer Name</th>
                <th>National Id</th>
                <th>Telephone</th>
                <th>Degree</th>
                <th>Title</th>
                <th>Email</th>
                <?php if ($title == 'Admin') echo '<th>School</th>'; ?>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
        <?php while ($rows = mysqli_fetch_array($select)) { ?>
            <tr>
                <td><a href="#" data-toggle="modal" data-target="#imageModal" data-image="uploaded_file/<?=$rows['user_image']?>"><img src="uploaded_file/<?=$rows['user_image']?>" alt="" style="width: 4rem;height: 4rem;border-radius: 350px;border: 1px solid green"></a></td>
                <td><?=$rows['username']?></td>
                <td><?=$rows['nat_id']?></td>
                <td><?=$rows['tel']?></td>
                <td><?=$rows['degree']?></td>
                <td><?=$rows['title']?></td>
                <td><?=$rows['email']?></td>
                <?php if ($title == 'Admin') echo '<td>' . $rows['school_name'] . '</td>'; ?>
                <td>
                    <a href="update_user_profile.php?user_id=<?=$rows['user_id']?>" class="edit-btn"><i class="fa fa-edit text-info" style="font-size: 25px;margin-right: 10px" title="Edit Trainer"></i></a>
                    <a href="#" class="delete-btn" data-id="<?=$rows['user_id']?>" data-name="<?=$rows['username']?>"><i class="fa fa-times-circle text-danger" style="font-size: 25px;margin-right: 10px" title="Delete Trainer"></i></a>
                </td>
            </tr>
        <?php } ?>
        </tbody>
    </table>
</div>
<div class="modal fade" id="imageModal" tabindex="-1" role="dialog" aria-labelledby="imageModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="imageModalLabel">Trainer Image</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <img src="" alt="Trainer Image" id="fullImage" style="width: 100%; height: auto;">
            </div>
        </div>
    </div>
</div>
<?php require 'footer.php'; ?>
<script>
    $('#imageModal').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget);
        var imageSrc = button.data('image');
        $(this).find('#fullImage').attr('src', imageSrc);
    });

    $('.delete-btn').click(function () {
        var userId = $(this).data('id');
        var userName = $(this).data('name');
        
        Swal.fire({
            title: 'Are you sure?',
            text: 'If you Delete ' + userName + '\'s Information And Account will be lost.',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    url: 'delete_trainer.php',
                    type: 'POST',
                    data: { delete: userId },
                    success: function (response) {
                        if(response == 'success') {
                            Swal.fire({
                                icon: 'success',
                                title: 'Deleted!',
                                text: 'Trainer has been removed.',
                                showConfirmButton: false,
                                timer: 1500
                            }).then(() => {
                                location.reload();
                            });
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Failed!',
                                text: 'There was an issue deleting the trainer. Please try again.',
                            });
                        }
                    },
                    error: function () {
                        Swal.fire({ icon: 'error', title: 'Error', text: 'Failed to delete trainer.' });
                    }
                });
            }
        });
    });
</script>
<link href="https://cdn.jsdelivr.net/npm/sweetalert2@11.3.0/dist/sweetalert2.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.3.0/dist/sweetalert2.min.js"></script>
