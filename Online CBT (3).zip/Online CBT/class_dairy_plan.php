<?php
require 'header.php';
?>
<style>
    .nav-link.activetd {
        background-color: rgba(3, 29, 54, 0.56);
        color: white;
    }
</style>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<div class="event text-right">
    <?php
    $title = $_SESSION['title'];
    if ($title == 'Trainer') {
        echo '<p class="p-t-13"><a href="add_dairy_plan.php"><i class="fa fa-plus"></i> Add Class Dairy Plan</a></p>';
    } else {
        echo '<p class="p-t-13"><a href=""><i class="fa fa-file"></i> </a></p>';
    }
    ?>
</div>

<!-- Display Today's Dairy Plans -->
<div class="today-plans" style="border: 1px solid #ccc; padding: 20px;">
    <h4 class="text-center">Class Dairy Plans</h4>
    <div class="row" style="overflow-x: scroll;">
        <table class="table table-hover table-bordered bg-white" id="sampleTable">
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Period</th>
                    <th>Trade</th>
                    <th>Level</th>
                    <th>Module Name <br> (Code)</th>
                    <th>Topic</th>
                    <th>Activity <br> (Main Content)</th>
                    <th>Application</th>
                    <th>Observation</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
            <?php
            require 'connection.php';
            $title = $_SESSION['title'];
            $school = $_SESSION['school'];
            $usr_id = $_SESSION['user_id']; 
            $today = date('Y-m-d'); 
            if ($title == 'Admin') {
                $sql_today = "SELECT * FROM dairy_plan WHERE date = '$today' ORDER BY dairy_id DESC";
            } elseif ($title == 'Trainer') {
                $sql_today = "SELECT * FROM dairy_plan,courses WHERE dairy_plan.course_id = courses.course_id AND duser_id = '$usr_id' AND date = '$today' ORDER BY dairy_id DESC";
            } else {
                $user = $_GET['trainer'] ?? '';
                $sql_today = "SELECT * FROM dairy_plan,courses WHERE dairy_plan.course_id = courses.course_id AND school_id = '$school' AND date = '$today' AND duser_id = '$user' ORDER BY dairy_id DESC";
            }

            $select_today = mysqli_query($conn, $sql_today);
            if (!$select_today) {
                echo "<script>Swal.fire({icon: 'error', title: 'Database Error', text: 'Failed to fetch data!'})</script>";
            }
            while ($rows = mysqli_fetch_array($select_today)) {
            ?>
                <tr>
                    <td><?=$rows['date']?></td>
                    <td><?=$rows['start_time']?> - <?=$rows['end_time']?></td>
                    <td><?=$rows['trade']?></td>
                    <td><?=$rows['level']?></td>
                    <td><?=$rows['course_name']?></td>
                    <td><?=$rows['topic']?></td>
                    <td><?=$rows['activity']?></td>
                    <td><?=$rows['application']?></td>
                    <td><?=$rows['observation']?></td>
                    <td>
                        <a href="#" onclick="confirmDelete(<?=$rows['dairy_id']?>)"><i class="fa fa-x text-danger" style="font-size: 25px;margin-right: 10px" title="Delete Dairy Plan"></i></a>
                    </td>
                </tr>
            <?php } ?>
            </tbody>
        </table>
    </div>
</div>
<div class="other-plans">
    <h3 class="text-center">Past Class Dairy Plans</h3>
    <div class="row" style="overflow-x: scroll;">
    
        <?php
        require 'connection.php';

        // Fetch all other plans not today
        if ($title == 'Admin') {
            $sql_other = "SELECT DISTINCT dairy_plan.date, dairy_plan.duser_id, users.username 
                          FROM dairy_plan
                          INNER JOIN users ON dairy_plan.duser_id = users.user_id
                          WHERE dairy_plan.date != '$today'
                          GROUP BY dairy_plan.date, dairy_plan.duser_id
                          ORDER BY dairy_plan.date DESC";
        } elseif ($title == 'Trainer') {
            $sql_other = "SELECT DISTINCT dairy_plan.date, dairy_plan.duser_id, users.username 
                          FROM dairy_plan
                          INNER JOIN users ON dairy_plan.duser_id = users.user_id
                          WHERE dairy_plan.duser_id = '$usr_id' AND dairy_plan.date != '$today'
                          GROUP BY dairy_plan.date, dairy_plan.duser_id
                          ORDER BY dairy_plan.date DESC";
        } elseif ($title == 'Master' || $title == 'Dos') {
            $user = $_GET['trainer'];
            $sql_other = "SELECT DISTINCT dairy_plan.date, dairy_plan.duser_id, users.username 
                          FROM dairy_plan
                          INNER JOIN users ON dairy_plan.duser_id = users.user_id
                          WHERE dairy_plan.school_id = '$school' AND dairy_plan.date != '$today'
                          AND dairy_plan.duser_id = '$user'
                          GROUP BY dairy_plan.date, dairy_plan.duser_id
                          ORDER BY dairy_plan.date DESC";
        }

        // Execute the query for other plans
        $select_other = mysqli_query($conn, $sql_other);
        while ($rows = mysqli_fetch_array($select_other)) {
        ?>
            <div class="col-xl-3 col-sm-6 mb-xl-0 mb-4">
                <div class="card">
                    <div class="card-header p-2 ps-3">
                        <div class="d-flex justify-content-between">
                            <div>
                                <p class="text-sm mb-0 text-capitalize">The date</p>
                                <h4 class="mb-0">
                                    <a href="view_trainer_class_dairy_plan.php?date=<?= $rows['date'] ?>&user=<?= $rows['duser_id'] ?>">
                                        <?= $rows['date'] ?>
                                    </a>
                                </h4>
                                <h6>Trainer: <?= $rows['username'] ?></h6>
                            </div>
                            <div class="icon icon-md icon-shape bg-gradient-dark shadow-dark shadow text-center border-radius-lg">
                                <i class="material-symbols-rounded opacity-10 fa fa-clock"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php
        }
        ?>
    </div>
</div>
<script>
function confirmDelete(id) {
    Swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = 'delete_dairy_plan.php?delete=' + id;
        }
    });
}
</script>
<?php
  require 'footer.php';
?>
