<?php
// Start the session
session_start();

// Check if the user is logged in (session is set)
if (!isset($_SESSION['user_id'])) {
    // Redirect to the login page if not logged in
    header("Location: index.php");
    exit();
}
if ($_SESSION['title'] == 'Admin'){ 
?>
<?php
require 'connection.php'
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="apple-touch-icon" sizes="76x76" href="asset/img/apple-icon.png">
  <link rel="icon" type="image/png" href="images/icon.png">
  <title>
    Softkeva Dashboard
  </title>
  <!--     Fonts and icons     -->
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Inter:300,400,500,600,700,900" />
  <!-- Nucleo Icons -->
  <link href="asset/css/nucleo-icons.css" rel="stylesheet" />
  <link href="asset/css/nucleo-svg.css" rel="stylesheet" />
  <!-- Font Awesome Icons -->
  <script src="https://kit.fontawesome.com/42d5adcbca.js" crossorigin="anonymous"></script>
  <!-- Material Icons -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@24,400,0,0" />
  <!-- CSS Files -->
  <link id="pagestyle" href="asset/css/material-dashboard.css?v=3.2.0" rel="stylesheet" />
  <link rel="stylesheet" type="text/css" href="css/main.css">
    <!-- Font-icon css-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body class="g-sidenav-show  bg-gray-100">
  <aside class="sidenav navbar navbar-vertical navbar-expand-xs border-radius-lg fixed-start ms-2  bg-white my-2" id="sidenav-main">
    <div class="sidenav-header">
      <i class="fas fa-times p-3 cursor-pointer text-dark opacity-5 position-absolute end-0 top-0 d-none d-xl-none" aria-hidden="true" id="iconSidenav"></i>
      <a class="navbar-brand px-4 py-3 m-0" href="dashboard.php" target="_blank">
        <img src="images/icon.png" style="border-radius: 250px;" class="navbar-brand-img" width="26" height="26" alt="main_logo">
        <span class="ms-1 text-sm text-dark">SoftKeva</span>
      </a>
    </div>
    <hr class="horizontal dark mt-0 mb-2">
    <div class="collapse navbar-collapse  w-auto " id="sidenav-collapse-main" style="height: auto;">
      <div class="photo text-center">
        <div class="image" style="padding: 0px 0px 10px 2px;"> 
        <?php
                  include ('connection.php');
                  $id=$_SESSION['user_id'];
                  $select = mysqli_query($conn, "SELECT * FROM users WHERE user_id='$id'");
                  while ($row=mysqli_fetch_assoc($select)) {
                  ?>
      <img src="uploaded_file/<?php echo $row['user_image']; ?>" style="width: 7rem;height:7rem;border-radius: 250px;border: 3px  solid green" alt="">
      <?php
                  }
                  ?>
          <div class="info">
            <span style="font-weight: bold;"><?php echo $_SESSION['username']; ?></span><br>
            <span style="font-weight: bold;font-size: 18px"><?php echo $_SESSION['title']; ?></span>
          </div>
        </div>
      </div>
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link actived" href="dashboard.php">
            <i class="material-symbols-rounded opacity-5 text-dark">dashboard</i>
            <span class="-text ms-1 text-dark">Dashboard</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link actives " href="schools.php">
            <i class="material-symbols-rounded fa fa-school opacity-5 text-dark"></i>
            <span class="-text ms-1 text-dark">Schools </span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-dark activet" href="trainers.php">
            <i class="material-symbols-rounded fa fa-users opacity-5"></i>
            <span class="nav-link-text ms-1">Trainer's </span>
          </a>
        </li>
        <li class="nav-item">
        <?php
                                    // Include database connection
                                    include 'connection.php';
                                    // Query to count courses where session_plan is 'not done'
                                    $query = "SELECT COUNT(*) AS total FROM users WHERE user_status = 'pending'";
                                    $result = mysqli_query($conn, $query);
                                    $row = mysqli_fetch_assoc($result);
                                    $sessionPlanCount = $row['total'];
                                    ?>
          <a class="nav-link text-dark activepa" href="pending_account.php">
            <i class="material-symbols-rounded fa fa-hourglass-half opacity-5"></i>
            <span class="nav-link-text ms-1">Pending Account 
            <?php if ($sessionPlanCount > 0) { ?>
                <span class="badge bg-danger"><?php echo $sessionPlanCount ?></span>
            <?php } ?>
            </span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-dark activetc" href="trainer_checklist.php">
            <i class="material-symbols-rounded fa fa-user-tie opacity-5"></i>
            <span class="nav-link-text ms-1">Inspections </span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-dark activetac" href="academic_year.php">
            <i class="material-symbols-rounded fa fa-clock opacity-5"></i>
            <span class="nav-link-text ms-1">Academin Year </span>
          </a>
        </li>
        
        
      </ul>
    </div>
    
  </aside>
  <main class="main-content position-relative max-height-vh-100 h-100 border-radius-lg ">
    <!-- Navbar -->
    <nav class="navbar navbar-main navbar-expand-lg px-0 mx-3 shadow-none border-radius-xl" id="navbarBlur" data-scroll="true">
      <div class="container-fluid py-1 px-3">
        <nav aria-label="breadcrumb">
          
          <h6 class="mb-0 text-danger-emphasis"><span style="font-size: 20px;">Academic Year : </span> <?php
                        include ('connection.php');
                        $user_id = $_SESSION['user_id'];
                        $school = $_SESSION['school'];
                        $sql="SELECT * FROM academic_year";
                        $select=mysqli_query($conn,$sql);
                        $num=mysqli_fetch_array($select);
                        
                          ?>
                          
                         <?=$num['year']?></h6>
        </nav>
        <div class="collapse navbar-collapse mt-sm-0 mt-2 me-md-0 me-sm-4" id="navbar">
          <div class="ms-md-auto pe-md-3 d-flex align-items-center">
          <h6 class="mb-0 text-warning-emphasis"><span style="font-size: 18px;">Term :</span> <?php
                        include ('connection.php');
                        $user_id = $_SESSION['user_id'];
                        $school = $_SESSION['school'];
                        $sql="SELECT * FROM academic_year";
                        $select=mysqli_query($conn,$sql);
                        $num=mysqli_fetch_array($select);
                        
                          ?>
                          
                         <?=$num['term']?></h6>
          </div>
          <ul class="navbar-nav d-flex align-items-center  justify-content-end">
           
            <li class="nav-item d-xl-none ps-3 d-flex align-items-center">
              <a href="javascript:;" class="nav-link text-body p-0" id="iconNavbarSidenav">
                <div class="sidenav-toggler-inner">
                  <i class="sidenav-toggler-line"></i>
                  <i class="sidenav-toggler-line"></i>
                  <i class="sidenav-toggler-line"></i>
                </div>
              </a>
            </li>
            <li class="nav-item px-3 d-flex align-items-center">
              <a href="javascript:;" class="nav-link text-body p-0">
                <i class="material-symbols-rounded fixed-plugin-button-nav">settings</i>
              </a>
            </li>
           
            
          </ul>
        </div>
      </div>
    </nav>
    <!-- End Navbar -->
    <div class="container-fluid py-2">
                <!--ADMIN CODE -->
      <?php
} elseif ($_SESSION['title'] == 'Master' || $_SESSION['title'] == 'Dos'){
  ?>
  <!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="apple-touch-icon" sizes="76x76" href="asset/img/apple-icon.png">
  <link rel="icon" type="image/png" href="images/icon.png">
  <title>

  <?php
  $school = $_SESSION['school'];
  $user_id = $_SESSION['user_id'];
                        include ('connection.php');
                        $sql="SELECT * FROM schools WHERE school_id='$school'";
                        $select=mysqli_query($conn,$sql);
                        $num=mysqli_fetch_array($select);                        
                          ?>
                          
                         <?=$num['school_name']?> Dashboard
  </title>
  <!--     Fonts and icons     -->
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Inter:300,400,500,600,700,900" />
  <!-- Nucleo Icons -->
  <link href="asset/css/nucleo-icons.css" rel="stylesheet" />
  <link href="asset/css/nucleo-svg.css" rel="stylesheet" />
  <!-- Font Awesome Icons -->
  <script src="https://kit.fontawesome.com/42d5adcbca.js" crossorigin="anonymous"></script>
  <!-- Material Icons -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@24,400,0,0" />
  <!-- CSS Files -->
  <link id="pagestyle" href="asset/css/material-dashboard.css?v=3.2.0" rel="stylesheet" />
  <link rel="stylesheet" type="text/css" href="css/main.css">
    <!-- Font-icon css-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body class="g-sidenav-show  bg-gray-100">
  <aside class="sidenav navbar navbar-vertical navbar-expand-xs border-radius-lg fixed-start ms-2  bg-white my-2" id="sidenav-main">
    <div class="sidenav-header">
      <i class="fas fa-times p-3 cursor-pointer text-dark opacity-5 position-absolute end-0 top-0 d-none d-xl-none" aria-hidden="true" id="iconSidenav"></i>
      <a class="navbar-brand px-4 py-3 m-0" href="dashboard.php" target="">
        <!-- <img src="images/icon.png" style="border-radius: 250px;" class="navbar-brand-img" width="26" height="26" alt="main_logo"> -->
        <?php
                  include ('connection.php');
                  $id=$_SESSION['user_id'];
                  $select = mysqli_query($conn, "SELECT * FROM users,schools WHERE users.school = schools.school_id AND user_id='$id'");
                  while ($row=mysqli_fetch_assoc($select)) {
                  ?>
      <!-- <img src="uploaded_file/<?php echo $row['user_image']; ?>" style="width: 7rem;height:7rem;border-radius: 250px;border: 3px  solid green" alt=""> -->
      <img src="uploaded_file/<?php echo $row['school_logo']; ?>" style="border-radius: 250px;" class="navbar-brand-img" width="35" height="35" alt="main_logo">
      <span class="ms-2 text-lg text-dark"><b><?=$row['school_name']?></b></span>
      <?php
                  }
                  ?>
        <?php
        
        ?>
        
      </a>
    </div>
    <hr class="horizontal dark mt-0 mb-2">
    <div class="collapse navbar-collapse  w-auto " id="sidenav-collapse-main" style="height: auto;">
      <div class="photo text-center">
        <div class="image" style="padding: 0px 0px 10px 2px;"> 
        <?php
                  include ('connection.php');
                  $id=$_SESSION['user_id'];
                  $select = mysqli_query($conn, "SELECT * FROM users WHERE user_id='$id'");
                  while ($row=mysqli_fetch_assoc($select)) {
                  ?>
      <img src="uploaded_file/<?php echo $row['user_image']; ?>" style="width: 7rem;height:7rem;border-radius: 250px;border: 3px  solid green" alt="">
      <?php
                  }
                  ?>
          <div class="info">
            <span style="font-weight: bold;"><?php echo $_SESSION['username']; ?></span><br>
            <span style="font-weight: bold;font-size: 18px"><?php echo $_SESSION['title']; ?></span>
          </div>
        </div>
      </div>
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link actived" href="dashboard.php">
            <i class="material-symbols-rounded opacity-5 fa fa-dashboard text-dark"></i>
            <span class="-text ms-1 text-dark">Dashboard</span>
          </a>
        </li>
        <li class="nav-item">
        <?php
                                    // Include database connection
                                    include 'connection.php';
                                    $school = $_SESSION['school'];
                                    $user_id = $_SESSION['user_id'];
                                    $date = date('Y-m-d');
                                    // Query to count courses where session_plan is 'not done'
                                    $query = "SELECT COUNT(*) AS total FROM users WHERE school = '$school'";
                                    $result = mysqli_query($conn, $query);
                                    $row = mysqli_fetch_assoc($result);
                                    $sessionPlanCount = $row['total'];
                                    ?>
          <a class="nav-link text-dark activet" href="trainers.php">
            <i class="material-symbols-rounded fa fa-users opacity-5"></i>
            <span class="nav-link-text ms-1">Trainer's 
            <?php if ($sessionPlanCount > 0) { ?>
                <span class="badge bg-primary"><?php echo $sessionPlanCount ?></span>
            <?php } ?>
            </span>
          </a>
        </li>
        <li class="nav-item">
        <?php
                                    // Include database connection
                                    include 'connection.php';
                                    $school = $_SESSION['school'];
                                    $user_id = $_SESSION['user_id'];
                                    $date = date('Y-m-d');
                                    // Query to count courses where session_plan is 'not done'
                                    $query = "SELECT COUNT(*) AS total FROM users WHERE user_status = 'pending' AND school = '$school'";
                                    $result = mysqli_query($conn, $query);
                                    $row = mysqli_fetch_assoc($result);
                                    $sessionPlanCount = $row['total'];
                                    ?>
          <a class="nav-link text-dark activepa" href="school_trainer_padding_accounts.php">
            <i class="material-symbols-rounded fa fa-hourglass-half opacity-5"></i>
            <span class="nav-link-text ms-1">Trainer's Pending Account
            <?php if ($sessionPlanCount > 0) { ?>
                <span class="badge bg-warning"><?php echo $sessionPlanCount ?></span>
            <?php } ?>
            </span>
          </a>
        </li>
        <li class="nav-item">
          <li class="nav-item">
            <a class="nav-link text-dark activetd" href="trainer_documents.php">
              <i class="material-symbols-rounded fa fa-book opacity-5"></i>
              <span class="nav-link-text ms-1">Trainer's Documents</span>
            </a>
          </li>
          <li class="nav-item">
    <?php
    // Include database connection
    include 'connection.php';
    $school = $_SESSION['school'];
    $user_id = $_SESSION['user_id'];
    
    // Query to count the pending documents in session_plan, schema_of_work, and assessment_plan separately and add them
    $query = "
        SELECT 
            (SELECT COUNT(*) FROM session_plan WHERE sschl_id = '$school' AND sstatus = 'pending') AS session_plan_pending,
            (SELECT COUNT(*) FROM schema_of_work WHERE ssschl_id = '$school' AND ssstatus = 'pending') AS schema_of_work_pending,
            (SELECT COUNT(*) FROM assessment_plan WHERE aschl_id = '$school' AND astatus = 'pending') AS assessment_plan_pending
    ";
    
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);
    
    // Summing up the total count of pending documents from all three tables
    $sessionPlanCount = $row['session_plan_pending'] + $row['schema_of_work_pending'] + $row['assessment_plan_pending'];
    ?>
    <a class="nav-link text-dark activecdfa" href="document_for_approval.php">
        <i class="material-symbols-rounded fa fa-hourglass-half opacity-5"></i>
        <span class="nav-link-text ms-1">Documents for Approval
            <?php if ($sessionPlanCount > 0) { ?>
                <span class="badge bg-danger"><?php echo $sessionPlanCount ?></span>
            <?php } ?>
        </span>
    </a>
</li>


          <!-- <li class="nav-item">
            <a class="nav-link text-dark activecm" href="courses.php">
              <i class="material-symbols-rounded fa fa-thumbs-up opacity-5"></i>
              <span class="nav-link-text ms-1">Approved Documents</span>
            </a>
          </li> -->
          <!-- <a class="nav-link text-dark activetc" href="trainer_checklist.php">
            <i class="material-symbols-rounded fa fa-user-tie opacity-5"></i>
            <span class="nav-link-text ms-1">Inspections</span>
          </a>
        </li> -->
        <!-- <li class="nav-item">
          <a class="nav-link activeplan" href="#" data-bs-toggle="collapse" data-bs-target="#plansCollapse" aria-expanded="false" aria-controls="plansCollapse">
            <i class="material-symbols-rounded opacity-5 text-dark fa fa-clock"></i>
            <span class="ms-1 text-dark">Plans</span>
          </a>
          <div class="collapse" id="plansCollapse">
            <ul class="nav">
              <li class="nav-item">
                <a class="nav-link" href="trainer_dairy_plan.php">
                  <span class="ms-1 text-dark"> <i class="fa fa-chalkboard-teacher" style="margin-left: 10px;"></i> Class Dairy Plan</span>
                </a>
              </li>
              
              <li class="nav-item">
                <a class="nav-link" href="trainer_session_plan.php">
                  <span class="ms-1 text-dark"> <i class="fa fa-clock" style="margin-left: 10px;"></i> Session Plan</span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="trainer_assessments_plan.php">
                  <span class="ms-1 text-dark"> <i class="fa fa-clipboard-list" style="margin-left: 10px;"></i> Assessment Plan</span>
                </a>
              </li>
            </ul>
          </div>
        </li> -->
        <li class="nav-item">
          <a class="nav-link text-dark activecmess" href="messages.php">
            <i class="material-symbols-rounded fa fa-sms opacity-5"></i>
            <span class="nav-link-text ms-1">Messages</span>
          </a>
        </li>
        <!-- <li class="nav-item">
          <a class="nav-link text-dark" href="#">
            <i class="material-symbols-rounded opacity-5">person</i>
            <span class="nav-link-text ms-1">Profile</span>
          </a>
        </li> -->
        
      </ul>
    </div>
    
  </aside>
  <main class="main-content position-relative max-height-vh-100 h-100 border-radius-lg ">
    <!-- Navbar -->
    <nav class="navbar navbar-main navbar-expand-lg px-0 mx-3 shadow-none border-radius-xl" id="navbarBlur" data-scroll="true">
      <div class="container-fluid py-1 px-3">
        <nav aria-label="breadcrumb">
          
          <h6 class="mb-0 text-danger-emphasis"><span style="font-size: 20px;">Academic Year : </span> <?php
                        include ('connection.php');
                        $user_id = $_SESSION['user_id'];
                        $school = $_SESSION['school'];
                        $sql="SELECT * FROM academic_year";
                        $select=mysqli_query($conn,$sql);
                        $num=mysqli_fetch_array($select);
                        
                          ?>
                          
                         <?=$num['year']?></h6>
        </nav>
        <div class="collapse navbar-collapse mt-sm-0 mt-2 me-md-0 me-sm-4" id="navbar">
          <div class="ms-md-auto pe-md-3 d-flex align-items-center">
          <h6 class="mb-0 text-warning-emphasis"><span style="font-size: 18px;">Term :</span> <?php
                        include ('connection.php');
                        $user_id = $_SESSION['user_id'];
                        $school = $_SESSION['school'];
                        $sql="SELECT * FROM academic_year";
                        $select=mysqli_query($conn,$sql);
                        $num=mysqli_fetch_array($select);
                        
                          ?>
                          
                         <?=$num['term']?></h6>
          </div>          <ul class="navbar-nav d-flex align-items-center  justify-content-end">
           
            <li class="nav-item d-xl-none ps-3 d-flex align-items-center">
              <a href="javascript:;" class="nav-link text-body p-0" id="iconNavbarSidenav">
                <div class="sidenav-toggler-inner">
                  <i class="sidenav-toggler-line"></i>
                  <i class="sidenav-toggler-line"></i>
                  <i class="sidenav-toggler-line"></i>
                </div>
              </a>
            </li>
            <li class="nav-item px-3 d-flex align-items-center">
              <a href="javascript:;" class="nav-link text-body p-0">
                <i class="material-symbols-rounded fixed-plugin-button-nav">settings</i>
              </a>
            </li>
           
            
          </ul>
        </div>
      </div>
    </nav>
    <!-- End Navbar -->
    <div class="container-fluid py-2">
  <?php
}elseif ($_SESSION['title'] == 'Trainer') {
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="apple-touch-icon" sizes="76x76" href="asset/img/apple-icon.png">
  <link rel="icon" type="image/png" href="images/icon.png">
  <title>
    <?php
  $school = $_SESSION['school'];
  $user_id = $_SESSION['user_id'];
                        include ('connection.php');
                        $sql="SELECT * FROM schools WHERE school_id='$school'";
                        $select=mysqli_query($conn,$sql);
                        $num=mysqli_fetch_array($select);                        
                          ?>
                          
                         <?=$num['school_name']?> Dashboard
                        
  </title>
  <!--     Fonts and icons     -->
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Inter:300,400,500,600,700,900" />
  <!-- Nucleo Icons -->
  <link href="asset/css/nucleo-icons.css" rel="stylesheet" />
  <link href="asset/css/nucleo-svg.css" rel="stylesheet" />
  <!-- Font Awesome Icons -->
  <script src="https://kit.fontawesome.com/42d5adcbca.js" crossorigin="anonymous"></script>
  <!-- Material Icons -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Rounded:opsz,wght,FILL,GRAD@24,400,0,0" />
  <!-- CSS Files -->
  <link id="pagestyle" href="asset/css/material-dashboard.css?v=3.2.0" rel="stylesheet" />
  <link rel="stylesheet" type="text/css" href="css/main.css">
    <!-- Font-icon css-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body class="g-sidenav-show  bg-gray-100">
  <aside class="sidenav navbar navbar-vertical navbar-expand-xs border-radius-lg fixed-start ms-2  bg-white my-2" id="sidenav-main">
    <div class="sidenav-header">
      <i class="fas fa-times p-3 cursor-pointer text-dark opacity-5 position-absolute end-0 top-0 d-none d-xl-none" aria-hidden="true" id="iconSidenav"></i>
      <a class="navbar-brand px-4 py-3 m-0" href="dashboard.php" target="_blank">
        <!-- <img src="images/icon.png" style="border-radius: 250px;" class="navbar-brand-img" width="26" height="26" alt="main_logo"> -->
        <?php
                  include ('connection.php');
                  $id=$_SESSION['user_id'];
                  $select = mysqli_query($conn, "SELECT * FROM users,schools WHERE users.school = schools.school_id AND user_id='$id'");
                  while ($row=mysqli_fetch_assoc($select)) {
                  ?>
      <!-- <img src="uploaded_file/<?php echo $row['user_image']; ?>" style="width: 7rem;height:7rem;border-radius: 250px;border: 3px  solid green" alt=""> -->
      <img src="uploaded_file/<?php echo $row['school_logo']; ?>" style="border-radius: 250px;" class="navbar-brand-img" width="35" height="35" alt="main_logo">
      <span class="ms-2 text-lg text-dark"><b><?=$row['school_name']?></b></span>
      <?php
                  }
                  ?>
        <?php
        
        ?>
      </a>
    </div>
    <hr class="horizontal dark mt-0 mb-2">
    <div class="collapse navbar-collapse  w-auto " id="sidenav-collapse-main" style="height: auto;">
      <div class="photo text-center">
        <div class="image" style="padding: 0px 0px 10px 2px;"> 
        <?php
                  include ('connection.php');
                  $id=$_SESSION['user_id'];
                  $select = mysqli_query($conn, "SELECT * FROM users WHERE user_id='$id'");
                  while ($row=mysqli_fetch_assoc($select)) {
                  ?>
      <img src="uploaded_file/<?php echo $row['user_image']; ?>" style="width: 7rem;height:7rem;border-radius: 250px;border: 3px  solid green" alt="">
      <?php
                  }
                  ?>
          <div class="info">
            <span style="font-weight: bold;"><?php echo $_SESSION['username']; ?></span><br>
            <span style="font-weight: bold;font-size: 18px"><?php echo $_SESSION['title']; ?></span>
          </div>
        </div>
      </div>
          <ul class="navbar-nav">
              <li class="nav-item">
                  <a class="nav-link actived" href="dashboard.php">
                      <i class="material-symbols-rounded opacity-5 text-dark">dashboard</i>
                      <span class="-text ms-1 text-dark">Dashboard</span>
                  </a>
              </li>

              <li class="nav-item">
              <?php
                                    // Include database connection
                                    include 'connection.php';
                                    $school = $_SESSION['school'];
                                    $user_id = $_SESSION['user_id'];
                                    $date = date('Y-m-d');
                                    // Query to count courses where session_plan is 'not done'
                                    $query = "SELECT COUNT(*) AS total FROM dairy_plan WHERE school_id = '$school' AND duser_id = '$user_id' AND date = '$date'";
                                    $result = mysqli_query($conn, $query);
                                    $row = mysqli_fetch_assoc($result);
                                    $sessionPlanCount = $row['total'];
                                    ?>
                  <a class="nav-link text-dark activetd" href="class_dairy_plan.php">
                      <i class="material-symbols-rounded fa fa-chalkboard-teacher opacity-5"></i>
                      <span class="nav-link-text ms-1">Class Dairy Plan 
                      <?php if ($sessionPlanCount > 0) { ?>
                <span class="badge bg-warning"><?php echo  $sessionPlanCount ?></span>
            <?php } ?>
                      </span>
                  </a>
              </li>
              <li class="nav-item">
              <?php
                                    // Include database connection
                                    include 'connection.php';
                                    $school = $_SESSION['school'];
                                    $user_id = $_SESSION['user_id'];
                                    // Query to count courses where session_plan is 'not done'
                                    $query = "SELECT COUNT(*) AS total FROM courses WHERE schl_id = '$school' AND user_id = '$user_id'";
                                    $result = mysqli_query($conn, $query);
                                    $row = mysqli_fetch_assoc($result);
                                    $sessionPlanCount = $row['total'];
                                    ?>
                  <a class="nav-link text-dark activecmo" href="modules.php">
                      <i class="material-symbols-rounded fa fa-book opacity-5"></i>
                      <span class="nav-link-text ms-1">My Documents
                      <?php if ($sessionPlanCount > 0) { ?>
                <span class="badge bg-primary"><?php echo  $sessionPlanCount ?></span>
            <?php } ?>
                      </span>
                  </a>
              </li>
          <!-- Module With Document -->
          <?php
              // Include database connection
              include 'connection.php';
              $school = $_SESSION['school'];
              $user_id = $_SESSION['user_id'];
              // Query to count courses where session_plan is 'not done'
              $query = "SELECT COUNT(*) AS total FROM courses WHERE schema_of_work <= 0 OR session_plan <= 0 OR assessment_plan <= 0 AND schl_id = '$school' AND user_id = '$user_id'";
              $result = mysqli_query($conn, $query);
              $row = mysqli_fetch_assoc($result);
              $sessionPlanCount = $row['total'];
              ?>
              <!-- Module With No Document -->
              <li class="nav-item">
                  <a class="nav-link activenon" href="#" data-bs-toggle="collapse" data-bs-target="#noDocumentCollapse" aria-expanded="false" aria-controls="noDocumentCollapse">
                      <i class="material-symbols-rounded opacity-5 text-dark fa fa-file-alt"></i>
                      <span class="ms-1 text-dark">Non Document Module
                      <?php if ($sessionPlanCount > 0) { ?>
                <span class="badge bg-danger"><?php echo "<i class='fa fa-circle'></i>" ?></span>
            <?php } ?>
                      </span>
                  </a>
                  <div class="collapse" id="noDocumentCollapse">
                         
                      <ul class="nav">
                          <li class="nav-item">
                                        <?php
                                      // Include database connection
                                      include 'connection.php';
                                      $school = $_SESSION['school'];
                                      $user_id = $_SESSION['user_id'];
                                      // Query to count courses where session_plan is 'not done'
                                      $query = "SELECT COUNT(*) AS total FROM courses WHERE session_plan = 0 AND schl_id = '$school' AND user_id = '$user_id'";
                                      $result = mysqli_query($conn, $query);
                                      $row = mysqli_fetch_assoc($result);
                                      $sessionPlanCount = $row['total'];
                                      ?>
                              <a class="nav-link" href="module_with_no_session_plan.php">
                                  <span class="ms-1 text-dark"><i class="fa fa-chalkboard-teacher" style="margin-left: 10px;"></i> No Session plan
                                  <?php if ($sessionPlanCount > 0) { ?>
                                      <span class="badge bg-danger"><?php echo $sessionPlanCount ?></span>
                                  <?php } ?>
                                </span>
                              </a>
                          </li>
                          <li class="nav-item">
                                      <?php
                                    // Include database connection
                                    include 'connection.php';
                                    $school = $_SESSION['school'];
                                    $user_id = $_SESSION['user_id'];
                                    // Query to count courses where session_plan is 'not done'
                                    $query = "SELECT COUNT(*) AS total FROM courses WHERE schema_of_work = 0 AND schl_id = '$school' AND user_id = '$user_id'";
                                    $result = mysqli_query($conn, $query);
                                    $row = mysqli_fetch_assoc($result);
                                    $sessionPlanCount = $row['total'];
                                    ?>
                              <a class="nav-link" href="module_with_no_scheme_of_work.php">
                                  <span class="ms-1 text-dark"><i class="fa fa-clock" style="margin-left: 10px;"></i> No Schema of work
                                  <?php if ($sessionPlanCount > 0) { ?>
                                      <span class="badge bg-danger"><?php echo $sessionPlanCount ?></span>
                                  <?php } ?>
                                </span>
                              </a>
                          </li>
                          <li class="nav-item">
                              <a class="nav-link" href="module_with_no_assessment_plan.php">
                              <?php
                                    // Include database connection
                                    include 'connection.php';
                                    $school = $_SESSION['school'];
                                    $user_id = $_SESSION['user_id'];
                                    // Query to count courses where session_plan is 'not done'
                                    $query = "SELECT COUNT(*) AS total FROM courses WHERE assessment_plan = 0 AND schl_id = '$school' AND user_id = '$user_id'";
                                    $result = mysqli_query($conn, $query);
                                    $row = mysqli_fetch_assoc($result);
                                    $sessionPlanCount = $row['total'];
                                    ?>
                                  <span class="ms-1 text-dark"><i class="fa fa-clipboard-list" style="margin-left: 10px;"></i> No Assessment plan 
                                  <?php if ($sessionPlanCount > 0) { ?>
                                      <span class="badge bg-danger"><?php echo $sessionPlanCount ?></span>
                                  <?php } ?>
                                </span>
                              </a>
                          </li>
                      </ul>
                  </div>
              </li>

    

                  <li class="nav-item ">
                      <a class="nav-link activewith" href="#" data-bs-toggle="collapse" data-bs-target="#documentCollapse" aria-expanded="false" aria-controls="documentCollapse">
                                      <?php
                                      // Include database connection
                                      include 'connection.php';
                                      $school = $_SESSION['school'];
                                      $user_id = $_SESSION['user_id'];
                                      // Query to count courses where session_plan is 'not done'
                                      $query = "SELECT COUNT(*) AS total FROM courses WHERE schema_of_work > 0 OR session_plan > 0 OR assessment_plan > 0 AND schl_id = '$school' AND user_id = '$user_id'";
                                      $result = mysqli_query($conn, $query);
                                      $row = mysqli_fetch_assoc($result);
                                      $sessionPlanCount = $row['total'];
                                      ?>
        <i class="material-symbols-rounded opacity-5 text-dark fa fa-file"></i>
        <span class="ms-1 text-dark">
            Module With Document 
            <?php if ($sessionPlanCount > 0) { ?>
                <span class="badge bg-primary"><?php echo "<i class='fa fa-circle'></i>" ?></span>
            <?php } ?>
        </span>
    </a>
    <div class="collapse" id="documentCollapse">
        <ul class="nav">
            <li class="nav-item">
              <?php
            // Include database connection
                                      include 'connection.php';
                                      $school = $_SESSION['school'];
                                      $user_id = $_SESSION['user_id'];
                                      // Query to count courses where session_plan is 'not done'
                                      $query = "SELECT COUNT(*) AS total FROM courses WHERE session_plan > 0 AND schl_id = '$school' AND user_id = '$user_id'";
                                      $result = mysqli_query($conn, $query);
                                      $row = mysqli_fetch_assoc($result);
                                      $sessionPlanCount = $row['total'];
                                      ?>
                <a class="nav-link" href="module_with_session_plan.php">
                    <span class="ms-1 text-dark">
                        <i class="fa fa-chalkboard-teacher" style="margin-left: 10px;"></i> Session plan
                        <?php if ($sessionPlanCount > 0) { ?>
                                      <span class="badge bg-primary"><?php echo $sessionPlanCount ?></span>
                                  <?php } ?>
                    </span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="module_with_schema_of_work.php">
                <?php
                                    // Include database connection
                                    include 'connection.php';
                                    $school = $_SESSION['school'];
                                    $user_id = $_SESSION['user_id'];
                                    // Query to count courses where session_plan is 'not done'
                                    $query = "SELECT COUNT(*) AS total FROM courses WHERE schema_of_work > 0 AND schl_id = '$school' AND user_id = '$user_id'";
                                    $result = mysqli_query($conn, $query);
                                    $row = mysqli_fetch_assoc($result);
                                    $sessionPlanCount = $row['total'];
                                    ?>
                    <span class="ms-1 text-dark">
                        <i class="fa fa-clock" style="margin-left: 10px;"></i> Schema of work
                        <?php if ($sessionPlanCount > 0) { ?>
                                      <span class="badge bg-primary"><?php echo $sessionPlanCount ?></span>
                                  <?php } ?>
                    </span>
                </a>
            </li>
            <li class="nav-item">
                                    <?php
                                    // Include database connection
                                    include 'connection.php';
                                    $school = $_SESSION['school'];
                                    $user_id = $_SESSION['user_id'];
                                    // Query to count courses where session_plan is 'not done'
                                    $query = "SELECT COUNT(*) AS total FROM courses WHERE assessment_plan > 0 AND schl_id = '$school' AND user_id = '$user_id'";
                                    $result = mysqli_query($conn, $query);
                                    $row = mysqli_fetch_assoc($result);
                                    $sessionPlanCount = $row['total'];
                                    ?>
                <a class="nav-link" href="module_with_assessment_plan.php">
                    <span class="ms-1 text-dark">
                        <i class="fa fa-clipboard-list" style="margin-left: 10px;"></i> Assessment plan
                        <?php if ($sessionPlanCount > 0) { ?>
                                      <span class="badge bg-primary"><?php echo $sessionPlanCount ?></span>
                                  <?php } ?>
                    </span>
                </a>
            </li>
        </ul>
    </div>
</li>

              
              <li class="nav-item">
              <?php
                                    // Include database connection
                                    include 'connection.php';
                                    $school = $_SESSION['school'];
                                    $user_id = $_SESSION['user_id'];
                                    // Query to count courses where session_plan is 'not done'
                                    $query = "SELECT COUNT(*) AS total FROM checklist WHERE schol_id = '$school' AND usr_id = '$user_id'";
                                    $result = mysqli_query($conn, $query);
                                    $row = mysqli_fetch_assoc($result);
                                    $sessionPlanCount = $row['total'];
                                    ?>
                  <a class="nav-link activetcm" href="my_inspections.php">
                      <i class="material-symbols-rounded fa fa-user-tie opacity-5 text-dark"></i>
                      <span class="-text ms-1 text-dark">My Inspections 
                      <?php if ($sessionPlanCount > 0) { ?>
                                      <span class="badge bg-warning"><?php echo $sessionPlanCount ?></span>
                                  <?php } ?>
                      </span>
                  </a>
              </li>

              <li class="nav-item">
                        <?php
                        // Include database connection
                        include 'connection.php';
                        $school = $_SESSION['school'];
                        $user_id = $_SESSION['user_id'];
                        $today = date('Y-m-d');

                        // Query to count unread messages (status = 'unread')
                        $query = "SELECT COUNT(*) AS total FROM messages WHERE mschl_id = '$school' AND status = 'unread'";
                        $result = mysqli_query($conn, $query);
                        $row = mysqli_fetch_assoc($result);
                        $unreadCount = $row['total'];
                        ?>
                        <a class="nav-link text-dark activecmess" href="messages.php" id="messageLink">
                            <i class="material-symbols-rounded fa fa-sms opacity-5"></i>
                            <span class="nav-link-text ms-1">School Messages
                                <?php if ($unreadCount > 0) { ?>
                                    <span class="badge bg-danger"><?php echo $unreadCount ?></span>
                                <?php } ?>
                            </span>
                        </a>
                    </li>

                    <script>
                        document.getElementById('messageLink').addEventListener('click', function () {
                            // Send an AJAX request to mark messages as read when the user clicks on the message link
                            fetch('mark_messages_as_read.php', {
                                method: 'POST',
                                headers: {
                                    'Content-Type': 'application/x-www-form-urlencoded'
                                },
                                body: 'school_id=<?php echo $school; ?>&user_id=<?php echo $user_id; ?>'
                            })
                            .then(response => response.json())
                            .then(data => {
                                if (data.status === 'success') {
                                    // Update the message badge count to zero
                                    const badge = document.querySelector('.badge');
                                    if (badge) {
                                        badge.style.display = 'none';
                                    }
                                }
                            })
                            .catch(error => console.error('Error:', error));
                        });
                    </script>

          </ul>

    </div>
    
  </aside>
  <main class="main-content position-relative max-height-vh-100 h-100 border-radius-lg ">
    <!-- Navbar -->
    <nav class="navbar navbar-main navbar-expand-lg px-0 mx-3 shadow-none border-radius-xl" id="navbarBlur" data-scroll="true">
      <div class="container-fluid py-1 px-3">
        <nav aria-label="breadcrumb">
          
          <h6 class="mb-0 text-danger-emphasis"><span style="font-size: 20px;">Academic Year : </span> <?php
                        include ('connection.php');
                        $user_id = $_SESSION['user_id'];
                        $school = $_SESSION['school'];
                        $sql="SELECT * FROM academic_year";
                        $select=mysqli_query($conn,$sql);
                        $num=mysqli_fetch_array($select);
                        
                          ?>
                          
                         <?=$num['year']?></h6>
        </nav>
        <div class="collapse navbar-collapse mt-sm-0 mt-2 me-md-0 me-sm-4" id="navbar">
          <div class="ms-md-auto pe-md-3 d-flex align-items-center">
          <h6 class="mb-0 text-warning-emphasis"><span style="font-size: 18px;">Term :</span> <?php
                        include ('connection.php');
                        $user_id = $_SESSION['user_id'];
                        $school = $_SESSION['school'];
                        $sql="SELECT * FROM academic_year";
                        $select=mysqli_query($conn,$sql);
                        $num=mysqli_fetch_array($select);
                        
                          ?>
                          
                         <?=$num['term']?></h6>
          </div>          <ul class="navbar-nav d-flex align-items-center  justify-content-end">
           
            <li class="nav-item d-xl-none ps-3 d-flex align-items-center">
              <a href="javascript:;" class="nav-link text-body p-0" id="iconNavbarSidenav">
                <div class="sidenav-toggler-inner">
                  <i class="sidenav-toggler-line"></i>
                  <i class="sidenav-toggler-line"></i>
                  <i class="sidenav-toggler-line"></i>
                </div>
              </a>
            </li>
            <li class="nav-item px-3 d-flex align-items-center">
              <a href="javascript:;" class="nav-link text-body p-0">
                <i class="material-symbols-rounded fixed-plugin-button-nav">settings</i>
              </a>
            </li>
           
            
          </ul>
        </div>
      </div>
    </nav>
    <!-- End Navbar -->
    <div class="container-fluid py-2">
      <?php
}
?>