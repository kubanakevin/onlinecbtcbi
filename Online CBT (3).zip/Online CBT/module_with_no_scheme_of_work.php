<?php
require 'header.php'; // Include header
require 'connection.php'; // Include database connection

// Pagination setup
$school = $_SESSION['school'];
$user = $_SESSION['user_id'];
$itemsPerPage = 12; // Number of items per page
$currentPage = isset($_GET['page']) ? $_GET['page'] : 1; // Current page number
$offset = ($currentPage - 1) * $itemsPerPage; // Offset for database query

// Fetch data from the database (adjust your table name and column names)
$sql = "SELECT * FROM courses WHERE schl_id = '$school' AND user_id = '$user' AND schema_of_work = 'not done' ORDER BY course_id DESC LIMIT $itemsPerPage OFFSET $offset";
$result = $conn->query($sql);

// Total items count for pagination (used to calculate total pages)
$sqlCount = "SELECT COUNT(*) AS total_items FROM courses WHERE schl_id = '$school' AND user_id = '$user'";
$countResult = $conn->query($sqlCount);
$row = $countResult->fetch_assoc();
$totalItems = $row['total_items'];
$totalPages = ceil($totalItems / $itemsPerPage);

?>
<style>
    .activenon {
        background-color: rgba(3, 29, 54, 0.56);
        color: white;
    }
</style>
<div class="container mt-3">
    <h4>Modules With No Schema of Work</h4>
    <div class="row">
        <?php
        // Loop through the fetched data and display it in cards
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                ?>
                <div class="col-md-4 mb-3">
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">Module Name: <strong><?php echo $row['course_name']; ?></strong></h5>
                            <p class="card-text">Level: <strong><?php echo $row['course_level']; ?></strong></p>
                            <a href="add_schema_of_work.php?module=<?=$row['course_id']?>"><button class="btn btn-danger" data-toggle="modal" data-target="#sessionModal"><i class="fa fa-plus"></i> Add Schema of Work</button></a>
                        </div>
                    </div>
                </div>
                <?php
            }
        } else {
            echo "<p class='text-center'>No Data found.</p>";
        }
        ?>
    </div>

    <!-- Pagination Controls -->
    <nav>
        <ul class="pagination mt-3 justify-content-center">
            <?php
            // Generate pagination links
            for ($i = 1; $i <= $totalPages; $i++) {
                ?>
                <li class="page-item <?php echo ($i == $currentPage) ? 'active' : ''; ?>">
                    <a class="page-link" href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                </li>
                <?php
            }
            ?>
        </ul>
    </nav>
</div>


<!-- Include jQuery and Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>

</body>
</html>

<?php require 'footer.php'; // Include footer ?>
