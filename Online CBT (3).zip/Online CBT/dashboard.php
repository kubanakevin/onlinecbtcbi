
<?php
require 'header.php';
require 'connection.php'
?>
<style>
    .nav-link.actived{
        background-color: rgba(3, 29, 54, 0.56);
        color: white;
    }
</style>
    <?php
    if ($_SESSION['title'] == 'Master' || $_SESSION['title'] == 'Dos') {
        ?>
        <div class="row">
        <div class="ms-3">
          <h3 class="mb-0 h4 font-weight-bolder">Dashboard</h3>
          <p class="mb-4">
            Check the Trainer's, Dairy and all time Performace.
          </p>
        </div>
        <div class="col-xl-3 col-sm-6 mb-xl-0 mb-4">
          <div class="card">
            <div class="card-header p-2 ps-3">
              <div class="d-flex justify-content-between">
                <div>
                  <p class="text-sm mb-0 text-capitalize">Trainers</p>
                  <h4 class="mb-0"><?php
                        include ('connection.php');
                        $school = $_SESSION['school'];
                        $sql="SELECT * FROM users WHERE school = '$school'";
                        $select=mysqli_query($conn,$sql);
                        $num=mysqli_num_rows($select);
                        
                          ?>
                          
                         <?=$num?></h4>
                </div>
                <a href="trainers.php"><div class="icon icon-md icon-shape bg-gradient-dark shadow-dark shadow text-center border-radius-lg">
                  <i class="material-symbols-rounded opacity-10 fa fa-users"></i>
                </div></a>
              </div>
            </div>
            <hr class="dark horizontal my-0">
            <div class="card-footer p-2 ps-3">
              <p class="mb-0 text-sm"><span class="text-success font-weight-bolder">+85% </span>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nostrum autem unde vel a vitae accusanti.</p>
            </div>
          </div>
        </div>
        <div class="col-xl-3 col-sm-6 mb-xl-0 mb-4">
          <div class="card">
            <div class="card-header p-2 ps-3">
              <div class="d-flex justify-content-between">
                <div>
                  <p class="text-sm mb-0 text-capitalize">Trainers</p>
                  <h4 class="mb-0"><?php
                        include ('connection.php');
                        $sql="SELECT * FROM users  WHERE school = '$school'";
                        $select=mysqli_query($conn,$sql);
                        $num=mysqli_num_rows($select);
                        
                          ?>
                          
                         <?=$num?>/ 
                         <?php
                        $sql="SELECT * FROM users WHERE user_status = 'pending' AND school = '$school'";
                        $select=mysqli_query($conn,$sql);
                        $num=mysqli_num_rows($select);
                        
                          ?>
                         <span style="font-size: 15px;" class="text-danger">  <?=$num?> <span style="margin-left: 10px;"> <i class="fa fa-spinner fa-spin"></i></span></span></h4>
                </div>
                <div class="icon icon-md icon-shape bg-gradient-dark shadow-dark shadow text-center border-radius-lg">
                  <i class="material-symbols-rounded opacity-10">people</i>
                </div>
              </div>
            </div>
            <hr class="dark horizontal my-0">
            <div class="card-footer p-2 ps-3">
              <p class="mb-0 text-sm"><span class="text-danger font-weight-bolder"><i class="fa fa-spinner fa-spin"></i></span> It shows the Trainer account that is Pending And needs to be approved <i class="fa fa-check-circle text-success"></i> or rejected <i class="fa fa-times-circle text-danger"></i>.</p>
            </div>
          </div>
        </div>
        <div class="col-xl-3 col-sm-6 mb-xl-0 mb-4">
          <div class="card">
            <div class="card-header p-2 ps-3">
              <div class="d-flex justify-content-between">
                <div>
                  <p class="text-sm mb-0 text-capitalize">Courses/Modules</p>
                  <h4 class="mb-0"><?php
                        include ('connection.php');
                        $user_id = $_SESSION['user_id'];
                        $school = $_SESSION['school'];
                        $sql="SELECT * FROM courses WHERE schl_id = '$school'";
                        $select=mysqli_query($conn,$sql);
                        $num=mysqli_num_rows($select);
                        
                          ?>
                          
                         <?=$num?></h4>
                </div>
                <a href="trainer_documents.php"><div class="icon icon-md icon-shape bg-gradient-dark shadow-dark shadow text-center border-radius-lg">
                  <i class="material-symbols-rounded opacity-10 fa fa-clipboard-list"></i>
                </div></a>
              </div>
            </div>
            <hr class="dark horizontal my-0">
            <div class="card-footer p-2 ps-3">
              <p class="mb-0 text-sm"><span class="text-success font-weight-bolder">+85% </span>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nostrum autem unde vel a vitae accusanti.</p>
            </div>
          </div>
        </div>
        <div class="col-xl-3 col-sm-6">
          <div class="card">
            <div class="card-header p-2 ps-3">
              <div class="d-flex justify-content-between">
                <div>
                  <p class="text-sm mb-0 text-capitalize">Inspections</p>
                  <h4 class="mb-0"><?php
                        include ('connection.php');
                        $school = $_SESSION['school'];
                        $sql="SELECT * FROM checklist WHERE schol_id = '$school'";
                        $select=mysqli_query($conn,$sql);
                        $num=mysqli_num_rows($select);
                        
                          ?>
                          
                         <?=$num?></h4>
                </div>
                <a href="trainer_documents.php"><div class="icon icon-md icon-shape bg-gradient-dark shadow-dark shadow text-center border-radius-lg">
                  <i class="material-symbols-rounded opacity-10 fa fa-user-tie"></i>
                </div></a>
              </div>
            </div>
            <hr class="dark horizontal my-0">
            <div class="card-footer p-2 ps-3">
              <p class="mb-0 text-sm"><span class="text-success font-weight-bolder">+85% </span>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nostrum autem unde vel a vitae accusanti.</p>
            </div>
          </div>
        </div>
        <div class="col-xl-3 col-sm-6 mb-xl-0 mb-4">
          <div class="card">
            <div class="card-header p-2 ps-3">
              <div class="d-flex justify-content-between">
                <div>
                  <p class="text-sm mb-0 text-capitalize">Unread Messages</p>
                  <h4 class="mb-0"><?php
                        include ('connection.php');
                        $school = $_SESSION['school'];
                        $sql="SELECT * FROM messages WHERE mschl_id = '$school' AND status = 'unread'";
                        $select=mysqli_query($conn,$sql);
                        $num=mysqli_num_rows($select);
                        
                          ?>
                          
                         <?=$num?></h4>
                </div>
                <a href="messages.php"><div class="icon icon-md icon-shape bg-gradient-dark shadow-dark shadow text-center border-radius-lg">
                  <i class="material-symbols-rounded opacity-10 fa fa-sms"></i>
                </div></a>
              </div>
            </div>
            <hr class="dark horizontal my-0">
            <div class="card-footer p-2 ps-3">
              <p class="mb-0 text-sm"><span class="text-success font-weight-bolder">+89% </span>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nostrum autem unde vel a vitae accusanti.</p>
            </div>
          </div>
        </div>
        <div class="col-xl-3 col-sm-6 mb-xl-0 mb-4" style="margin-top: 10px">
          <div class="card">
            <div class="card-header p-2 ps-3">
              <div class="d-flex justify-content-between">
                <div>
                  <p class="text-sm mb-0 text-capitalize">Class Dairy Plan</p>
                  <h4 class="mb-0"><?php
                        include ('connection.php');
                        $school = $_SESSION['school'];
                        $user_id = $_SESSION['user_id'];
                        $sql="SELECT * FROM dairy_plan WHERE school_id = '$school'";
                        $select=mysqli_query($conn,$sql);
                        $num=mysqli_num_rows($select);
                        
                          ?>
                          
                         <?=$num?></h4>
                </div>
                <a href="trainer_documents.php"><div class="icon icon-md icon-shape bg-gradient-dark shadow-dark shadow text-center border-radius-lg">
                  <i class="material-symbols-rounded opacity-10 fa fa-chalkboard-teacher"></i>
                </div></a>
              </div>
            </div>
            <hr class="dark horizontal my-0">
            <div class="card-footer p-2 ps-3">
              <p class="mb-0 text-sm"><span class="text-success font-weight-bolder">+89% </span>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nostrum autem unde vel a vitae accusanti.</p>
            </div>
          </div>
        </div>
        <div class="col-xl-3 col-sm-6 mb-xl-0 mb-4" style="margin-top: 10px">
          <div class="card">
            <div class="card-header p-2 ps-3">
              <div class="d-flex justify-content-between">
                <div>
                  <p class="text-sm mb-0 text-capitalize">Session Plan</p>
                  <h4 class="mb-0"><?php
                        include ('connection.php');
                        $school = $_SESSION['school'];
                        $sql="SELECT * FROM session_plan WHERE sschl_id = '$school'";
                        $select=mysqli_query($conn,$sql);
                        $num=mysqli_num_rows($select);
                        
                          ?>
                          
                         <?=$num?> /<?php
                        include ('connection.php');
                        $school = $_SESSION['school'];
                        $user_id = $_SESSION['user_id'];
                        $sql="SELECT * FROM session_plan WHERE sschl_id = '$school' AND sstatus = 'pending'";
                        $select=mysqli_query($conn,$sql);
                        $num=mysqli_num_rows($select);
                        
                          ?>
                         <span style="font-size: 15px;" class="text-primary">  <?=$num?> <span style="margin-left: 3px;"> <i class="fa fa-spinner fa-spin text-primary"></i></span></span></h4>
                </div>
                <a href="trainer_documents.php"><div class="icon icon-md icon-shape bg-gradient-dark shadow-dark shadow text-center border-radius-lg">
                  <i class="material-symbols-rounded opacity-10 fa fa-clock"></i>
                </div></a>
              </div>
            </div>
            <hr class="dark horizontal my-0">
            <div class="card-footer p-2 ps-3">
              <p class="mb-0 text-sm"><span class="text-success font-weight-bolder"><i class="fa fa-spinner fa-spin text-primary"></i> </span> It shows the session plan that is pending that needs to be approved <i class="fa fa-check-circle text-success"></i> or rejected <i class="fa fa-times-circle text-danger"></i></p>
            </div>
          </div>
        </div>
        <div class="col-xl-3 col-sm-6 mb-xl-0 mb-4" style="margin-top: 10px">
          <div class="card">
            <div class="card-header p-2 ps-3">
              <div class="d-flex justify-content-between">
                <div>
                  <p class="text-sm mb-0 text-capitalize">Assessments Plan</p>
                  <h4 class="mb-0 text-primary"><?php
                        include ('connection.php');
                        $school = $_SESSION['school'];
                        $sql="SELECT * FROM assessment_plan WHERE aschl_id = '$school'";
                        $select=mysqli_query($conn,$sql);
                        $num=mysqli_num_rows($select);
                        
                          ?>
                          
                         <?=$num?> / 
                         <?php
                        include ('connection.php');
                        $school = $_SESSION['school'];
                        $sql="SELECT * FROM assessment_plan WHERE aschl_id = '$school' AND on_status = 'not yet done'";
                        $select=mysqli_query($conn,$sql);
                        $num=mysqli_num_rows($select);
                        
                          ?>
                         <span style="font-size: 15px;" class="text-danger">  <?=$num?> <span style="margin-left: 10px;">Not yet Done</span></span></h4>
                </div>
                <a href="trainer_documents.php"><div class="icon icon-md icon-shape bg-gradient-dark shadow-dark shadow text-center border-radius-lg">
                  <i class="material-symbols-rounded opacity-10 fa fa-clipboard-list"></i>
                </div></a>
              </div>
            </div>
            <hr class="dark horizontal my-0">
            <div class="card-footer p-2 ps-3">
              <p class="mb-0 text-sm"><span class="text-success font-weight-bolder">+89% </span>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nostrum autem unde vel a vitae accusanti.</p>
            </div>
          </div>
        </div>
    </div>
    <?php
    }elseif ($_SESSION['title'] == 'Admin') {
      ?>
      <div class="row">
        <div class="ms-3">
          <h3 class="mb-0 h4 font-weight-bolder">Dashboard</h3>
          <p class="mb-4">
            Check the Trainer's, Dairy and all time Performace.
          </p>
        </div>
        <div class="col-xl-3 col-sm-6 mb-xl-0 mb-4">
          <div class="card">
            <div class="card-header p-2 ps-3">
              <div class="d-flex justify-content-between">
                <div>
                  <p class="text-sm mb-0 text-capitalize">Trainers</p>
                  <h4 class="mb-0"><?php
                        include ('connection.php');
                        $sql="SELECT * FROM users";
                        $select=mysqli_query($conn,$sql);
                        $num=mysqli_num_rows($select);
                        
                          ?>
                          
                         <?=$num?>/ 
                         <?php
                        $sql="SELECT * FROM users WHERE user_status = 'pending'";
                        $select=mysqli_query($conn,$sql);
                        $num=mysqli_num_rows($select);
                        
                          ?>
                         <span style="font-size: 15px;" class="text-danger">  <?=$num?> <span style="margin-left: 10px;"> <i class="fa fa-spinner fa-spin"></i></span></span></h4>
                </div>
                <div class="icon icon-md icon-shape bg-gradient-dark shadow-dark shadow text-center border-radius-lg">
                  <i class="material-symbols-rounded opacity-10">people</i>
                </div>
              </div>
            </div>
            <hr class="dark horizontal my-0">
            <div class="card-footer p-2 ps-3">
              <p class="mb-0 text-sm"><span class="text-danger font-weight-bolder"><i class="fa fa-spinner fa-spin"></i></span> It shows the Trainer account that is Pending And needs to be approved <i class="fa fa-check-circle text-success"></i> or rejected <i class="fa fa-times-circle text-danger"></i>.</p>
            </div>
          </div>
        </div>
        <div class="col-xl-3 col-sm-6 mb-xl-0 mb-4">
          <div class="card">
            <div class="card-header p-2 ps-3">
              <div class="d-flex justify-content-between">
                <div>
                  <p class="text-sm mb-0 text-capitalize">schools</p>
                  <h4 class="mb-0"><?php
                        include ('connection.php');
                        $sql="SELECT * FROM schools";
                        $select=mysqli_query($conn,$sql);
                        $num=mysqli_num_rows($select);
                        
                          ?>
                          
                         <?=$num?></h4>
                </div>
                <div class="icon icon-md icon-shape bg-gradient-dark shadow-dark shadow text-center border-radius-lg">
                  <i class="material-symbols-rounded opacity-10 fa fa-school"></i>
                </div>
              </div>
            </div>
            <hr class="dark horizontal my-0">
            <div class="card-footer p-2 ps-3">
              <p class="mb-0 text-sm"><span class="text-success font-weight-bolder">+89% </span>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nostrum autem unde vel a vitae accusanti.</p>
            </div>
          </div>
        </div>
        <div class="col-xl-3 col-sm-6 mb-xl-0 mb-4">
          <div class="card">
            <div class="card-header p-2 ps-3">
              <div class="d-flex justify-content-between">
                <div>
                  <p class="text-sm mb-0 text-capitalize">Courses/Modules</p>
                  <h4 class="mb-0"><?php
                        include ('connection.php');
                        $sql="SELECT * FROM courses";
                        $select=mysqli_query($conn,$sql);
                        $num=mysqli_num_rows($select);
                        
                          ?>
                          
                         <?=$num?></h4>
                </div>
                <div class="icon icon-md icon-shape bg-gradient-dark shadow-dark shadow text-center border-radius-lg">
                  <i class="material-symbols-rounded opacity-10 fa fa-clipboard-list"></i>
                </div>
              </div>
            </div>
            <hr class="dark horizontal my-0">
            <div class="card-footer p-2 ps-3">
              <p class="mb-0 text-sm"><span class="text-success font-weight-bolder">+85% </span>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nostrum autem unde vel a vitae accusanti.</p>
            </div>
          </div>
        </div>
        <div class="col-xl-3 col-sm-6">
          <div class="card">
            <div class="card-header p-2 ps-3">
              <div class="d-flex justify-content-between">
                <div>
                  <p class="text-sm mb-0 text-capitalize">Inspections</p>
                  <h4 class="mb-0"><?php
                        include ('connection.php');
                        $sql="SELECT * FROM checklist";
                        $select=mysqli_query($conn,$sql);
                        $num=mysqli_num_rows($select);
                        
                          ?>
                          
                         <?=$num?></h4>
                </div>
                <div class="icon icon-md icon-shape bg-gradient-dark shadow-dark shadow text-center border-radius-lg">
                  <i class="material-symbols-rounded opacity-10 fa fa-user-tie"></i>
                </div>
              </div>
            </div>
            <hr class="dark horizontal my-0">
            <div class="card-footer p-2 ps-3">
              <p class="mb-0 text-sm"><span class="text-success font-weight-bolder">+85% </span>This is the Inspections that made by head of schools for there trainers.</p>
            </div>
          </div>
        </div>
        <div class="col-xl-3 col-sm-6">
          <div class="card">
            <div class="card-header p-2 ps-3">
              <div class="d-flex justify-content-between">
                <div>
                  <p class="text-sm mb-0 text-capitalize">System Visitors</p>
                  <h4 class="mb-0"><?php
                        $result = mysqli_query($conn, "SELECT COUNT(*) as total_visitors FROM visitors");
                        $row = mysqli_fetch_assoc($result);
                        $total_visitors = $row['total_visitors'];
                        
                        // Display visitor count
                        echo  $total_visitors;
                        $today = date('Y-m-d');
                        $result = mysqli_query($conn, "SELECT COUNT(*) as total_visitors FROM visitors WHERE visit_time LIKE '$today%'");
                        $row = mysqli_fetch_assoc($result);
                        $total_visitors = $row['total_visitors'];
                          ?>
                         / <span style="font-size: 15px;" class="text-primary">  <?=$total_visitors?> <span style="margin-left: 5px;"> New </span></span></h4>
                        </h4>
                </div>
                <div class="icon icon-md icon-shape bg-gradient-dark shadow-dark shadow text-center border-radius-lg">
                  <i class="material-symbols-rounded opacity-10 fa fa-file-o"></i>
                </div>
              </div>
            </div>
            <hr class="dark horizontal my-0">
            <div class="card-footer p-2 ps-3">
              <p class="mb-0 text-sm">This is the number of visitors that visit the system there you will found to day and past visitors</p>
            </div>
          </div>
        </div>
    </div>
       <?php
    }elseif ($_SESSION['title'] == 'Trainer') {
      ?>
      <div class="row">
        <div class="ms-3">
          <h3 class="mb-0 h4 font-weight-bolder">Dashboard</h3>
          <p class="mb-4">
            Check Your Dairy and all time Performace.
          </p>
        </div>
        
        <div class="col-xl-3 col-sm-6 mb-xl-0 mb-4">
          <div class="card">
            <div class="card-header p-2 ps-3">
              <div class="d-flex justify-content-between">
                <div>
                  <p class="text-sm mb-0 text-capitalize">Courses</p>
                  <h4 class="mb-0"><?php
                        include ('connection.php');
                        $user_id = $_SESSION['user_id'];
                        $sql="SELECT * FROM courses WHERE user_id = '$user_id'";
                        $select=mysqli_query($conn,$sql);
                        $num=mysqli_num_rows($select);
                        
                          ?>
                          
                         <?=$num?></h4>
                </div>
                <a href="modules.php"><div class="icon icon-md icon-shape bg-gradient-dark shadow-dark shadow text-center border-radius-lg">
                  <i class="material-symbols-rounded opacity-10 fa fa-book"></i>
                </div></a>
              </div>
            </div>
            <hr class="dark horizontal my-0">
            <div class="card-footer p-2 ps-3">
              <p class="mb-0 text-sm"><span class="text-success font-weight-bolder">+89% </span>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nostrum autem unde vel a vitae accusanti.</p>
            </div>
          </div>
        </div>
        <div class="col-xl-3 col-sm-6 mb-xl-0 mb-4">
          <div class="card">
            <div class="card-header p-2 ps-3">
              <div class="d-flex justify-content-between">
                <div>
                  <p class="text-sm mb-0 text-capitalize">Class Dairy Plan</p>
                  <h4 class="mb-0"><?php
                        include ('connection.php');
                        $school = $_SESSION['school'];
                        $user_id = $_SESSION['user_id'];
                        $sql="SELECT * FROM dairy_plan WHERE duser_id = '$user_id' AND school_id = '$school'";
                        $select=mysqli_query($conn,$sql);
                        $num=mysqli_num_rows($select);
                        
                          ?>
                          
                         <?=$num?> / 
                         <?php
                        include ('connection.php');
                        $school = $_SESSION['school'];
                        $user_id = $_SESSION['user_id'];
                        $today = date('Y-m-d');
                        $sql="SELECT * FROM dairy_plan WHERE duser_id = '$user_id' AND school_id = '$school' AND date = '$today'";
                        $select=mysqli_query($conn,$sql);
                        $num=mysqli_num_rows($select);
                        
                          ?>
                         <span style="font-size: 15px;" class="text-primary">  <?=$num?> <span style="margin-left: 10px;">To day Class dairy Plan</span></span></h4>
                </div>
                <a href="class_dairy_plan.php"><div class="icon icon-md icon-shape bg-gradient-dark shadow-dark shadow text-center border-radius-lg">
                  <i class="material-symbols-rounded opacity-10 fa fa-chalkboard-teacher"></i>
                </div></a>
              </div>
            </div>
            <hr class="dark horizontal my-0">
            <div class="card-footer p-2 ps-3">
              <p class="mb-0 text-sm"><span class="text-success font-weight-bolder">+89% </span>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nostrum autem unde vel a vitae accusanti.</p>
            </div>
          </div>
        </div>
        <div class="col-xl-3 col-sm-6 mb-xl-0 mb-4">
          <div class="card">
            <div class="card-header p-2 ps-3">
              <div class="d-flex justify-content-between">
                <div>
                  <p class="text-sm mb-0 text-capitalize">Session  Plan</p>
                  <h4 class="mb-0"><?php
                        include ('connection.php');
                        $school = $_SESSION['school'];
                        $user_id = $_SESSION['user_id'];
                        $sql="SELECT * FROM session_plan WHERE suser_id = '$user_id' AND sschl_id = '$school'";
                        $select=mysqli_query($conn,$sql);
                        $num=mysqli_num_rows($select);
                        
                          ?>
                          
                         <?=$num?> /<?php
                        include ('connection.php');
                        $school = $_SESSION['school'];
                        $user_id = $_SESSION['user_id'];
                        $sql="SELECT * FROM session_plan WHERE sschl_id = '$school' AND suser_id = '$user_id' AND sstatus = 'rejected'";
                        $select=mysqli_query($conn,$sql);
                        $num=mysqli_num_rows($select);
                        
                          ?>
                         <span style="font-size: 15px;" class="text-danger">  <?=$num?> <span style="margin-left: 3px;"> <i class="fa fa-times-circle text-danger"></i></span></span> & <?php
                        include ('connection.php');
                        $school = $_SESSION['school'];
                        $user_id = $_SESSION['user_id'];
                        $sql="SELECT * FROM session_plan WHERE sschl_id = '$school' AND suser_id = '$user_id' AND sstatus = 'pending'";
                        $select=mysqli_query($conn,$sql);
                        $num=mysqli_num_rows($select);
                        
                          ?>
                         <span style="font-size: 15px;" class="text-primary">  <?=$num?> <span style="margin-left: 3px;"> <i class="fa fa-spinner fa-spin text-primary"></i></span></span>
                        </h4>
                </div>
                <a href="module_with_session_plan.php"><div class="icon icon-md icon-shape bg-gradient-dark shadow-dark shadow text-center border-radius-lg">
                  <i class="material-symbols-rounded opacity-10 fa fa-clock"></i>
                </div></a>
              </div>
            </div>
            <hr class="dark horizontal my-0">
            <div class="card-footer p-2 ps-3">
              <p class="mb-0 text-sm">When session plan rejected ( <i class="fa fa-times-circle text-danger"></i> ) the system  waits for <span class="text-danger font-weight-bolder">24 HOURS  </span> to be removed into Your session Plans.</p>
            </div>
          </div>
        </div>
        <div class="col-xl-3 col-sm-6 mb-xl-0 mb-4">
          <div class="card">
            <div class="card-header p-2 ps-3">
              <div class="d-flex justify-content-between">
                <div>
                  <p class="text-sm mb-0 text-capitalize">Assessments Plan</p>
                  <h4 class="mb-0 text-primary"><?php
                        include ('connection.php');
                        $school = $_SESSION['school'];
                        $user_id = $_SESSION['user_id'];
                        $sql="SELECT * FROM assessment_plan WHERE aschl_id = '$school' AND auser_id = '$user_id'";
                        $select=mysqli_query($conn,$sql);
                        $num=mysqli_num_rows($select);
                        
                          ?>
                          
                         <?=$num?> / 
                         <?php
                        include ('connection.php');
                        $school = $_SESSION['school'];
                        $user_id = $_SESSION['user_id'];
                        $sql="SELECT * FROM assessment_plan WHERE aschl_id = '$school' AND auser_id = '$user_id' AND on_status = 'not yet done'";
                        $select=mysqli_query($conn,$sql);
                        $num=mysqli_num_rows($select);
                        
                          ?>
                         <span style="font-size: 15px;" class="text-danger">  <?=$num?> <span style="margin-left: 10px;">Not yet Done</span></span></h4>
                </div>
                <a href="module_with_assessment_plan.php"><div class="icon icon-md icon-shape bg-gradient-dark shadow-dark shadow text-center border-radius-lg">
                  <i class="material-symbols-rounded opacity-10 fa fa-clipboard-list"></i>
                </div></a>
              </div>
            </div>
            <hr class="dark horizontal my-0">
            <div class="card-footer p-2 ps-3">
              <p class="mb-0 text-sm"><span class="text-success font-weight-bolder">+89% </span>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nostrum autem unde vel a vitae accusanti.</p>
            </div>
          </div>
        </div>
        <div class="col-xl-3 col-sm-6 mb-xl-0 mb-4">
          <div class="card">
            <div class="card-header p-2 ps-3">
              <div class="d-flex justify-content-between">
                <div>
                  <p class="text-sm mb-0 text-capitalize">Inspections</p>
                  <h4 class="mb-0"><?php
                        include ('connection.php');
                        $user_id = $_SESSION['user_id'];
                        $school = $_SESSION['school'];
                        $sql="SELECT * FROM checklist WHERE usr_id = '$user_id' AND schol_id = '$school'";
                        $select=mysqli_query($conn,$sql);
                        $num=mysqli_num_rows($select);
                        
                          ?>
                          
                         <?=$num?></h4>
                </div>
                <a href="my_inspections.php"><div class="icon icon-md icon-shape bg-gradient-dark shadow-dark shadow text-center border-radius-lg">
                  <i class="material-symbols-rounded fa fa-user-tie opacity-10"></i>
                </div></a>
              </div>
            </div>
            <hr class="dark horizontal my-0">
            <div class="card-footer p-2 ps-3">
              <p class="mb-0 text-sm"><span class="text-success font-weight-bolder">+85% </span>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nostrum autem unde vel a vitae accusanti.</p>
            </div>
          </div>
        </div>
        <div class="col-xl-3 col-sm-6" style="margin-top: 10px;">
          <div class="card">
            <div class="card-header p-2 ps-3">
              <div class="d-flex justify-content-between">
                <div>
                  <p class="text-sm mb-0 text-capitalize">School message</p>
                  <h4 class="mb-0"><?php
                        include ('connection.php');
                        $school = $_SESSION['school'];
                        $user_id = $_SESSION['user_id'];
                        $sql="SELECT * FROM messages WHERE  mschl_id = '$school'";
                        $select=mysqli_query($conn,$sql);
                        $num=mysqli_num_rows($select);
                        
                          ?>
                          
                         <?=$num?> / 
                         <?php
                        include ('connection.php');
                        $school = $_SESSION['school'];
                        $user_id = $_SESSION['user_id'];
                        $today = date('Y-m-d'); // Get only the current date (without time)

                        // Use LIKE to match messages from today, ignoring the exact time
                        $sql = "SELECT * FROM messages WHERE mschl_id = '$school' AND time LIKE '$today%'";

                        $select=mysqli_query($conn,$sql);
                        $num=mysqli_num_rows($select);
                        
                          ?>
                         <span style="font-size: 15px;" class="text-primary">  <?=$num?> <span style="margin-left: 10px;">To day <i class="fa fa-envelope-open"></i></span></span> /
                         <?php
                        include ('connection.php');
                        $school = $_SESSION['school'];
                        $user_id = $_SESSION['user_id'];
                        $sql="SELECT * FROM messages WHERE mschl_id = '$school' AND status = 'unread'";
                        $select=mysqli_query($conn,$sql);
                        $num=mysqli_num_rows($select);
                        
                          ?>
                         <span style="font-size: 15px;" class="text-danger">  <?=$num?> <span style="margin-left: 10px;"><i class="fa fa-envelope"></i></span></span>
                          <!-- <i class="fa fa-envelope"></i><span class="badge">3</span> -->
                         </h4>
                </div>
                <a href="messages.php"><div class="icon icon-md icon-shape bg-gradient-dark shadow-dark shadow text-center border-radius-lg">
                  <i class="material-symbols-rounded opacity-10 fa fa-envelope-open"></i>
                </div></a>
              </div>
            </div>
            <hr class="dark horizontal my-0">
            <div class="card-footer p-2 ps-3">
              <p class="mb-0 text-sm"><span class="text-primary font-weight-bolder"><i class="fa fa-envelope-open"></i> </span> shows the message that you have read and <i class="fa fa-envelope text-danger"></i> shows the unread messages.</p>
            </div>
          </div>
        </div>
    </div>
      <?php
    }
    ?>
<?php
require 'footer.php';
?>