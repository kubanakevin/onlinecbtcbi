<?php
$conn = mysqli_connect("localhost","root","","trainer_system") or die("connection fail");
?>