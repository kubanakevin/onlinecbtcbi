<?php
require 'header.php';
require 'connection.php';

// Handle the form submission for course update
if (isset($_POST['course_id'])) {
    // Retrieve the updated course details from the form
    $course_id = $_POST['course_id'];
    $course_level = mysqli_real_escape_string($conn, $_POST['course_level']);
    $trade = mysqli_real_escape_string($conn, $_POST['trade']);
    $course_name = mysqli_real_escape_string($conn, $_POST['course_name']);
    $period = mysqli_real_escape_string($conn, $_POST['period']);
    $file = mysqli_real_escape_string($conn, $_POST['file']);

    // Prepare the SQL query to update the course
    $sql = "UPDATE courses 
            SET course_level = '$course_level', 
                trade = '$trade', 
                course_name = '$course_name', 
                period = '$period', 
                file = '$file'
            WHERE course_id = '$course_id'";

    // Execute the query and show SweetAlert messages
    if (mysqli_query($conn, $sql)) {
        echo "<script>
                Swal.fire({
                    title: 'Success!',
                    text: 'Course updated successfully.',
                    icon: 'success',
                    confirmButtonText: 'Okay'
                }).then((result) => {
                    if (result.isConfirmed) {
                        window.location.href = 'trainer_modules.php';
                    }
                });
              </script>";
    } else {
        echo "<script>
                Swal.fire({
                    title: 'Error!',
                    text: 'There was an issue updating the course. Please try again.',
                    icon: 'error',
                    confirmButtonText: 'Close'
                }).then((result) => {
                    if (result.isConfirmed) {
                        window.location.href = 'trainer_modules.php'; // Redirect on error
                    }
                });
              </script>";
    }
}

?>

<style>
    .nav-link.activetd {
        background-color: rgba(3, 29, 54, 0.56);
        color: white;
    }
    .form-group {
        margin-bottom: 15px;
    }
</style>

<div class="event text-right">
    <?php
    $user_id = $_GET['trainer'];
    $select = mysqli_query($conn, "SELECT * FROM users WHERE user_id = '$user_id'");
    $user = mysqli_fetch_array($select);
    ?>

    <p class="p-t-13"><a href="add_course.php?trainer=<?=$user['user_id']?>"><i class="fa fa-plus"></i> Add Course</a></p>
</div>

<div class="row" style="overflow-x: scroll;">
    <table class="table table-hover table-bordered bg-white" id="sampleTable">
        <thead>
            <tr>
                <th>Course Level</th>
                <th>Trade</th>
                <th>Course / Module Name</th>
                <th>Period</th>
                <th>Notes</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody id="courseTable">
        <?php
        $user_id = $_GET['trainer'];

        $sql = "SELECT DISTINCT courses.course_id, users.username, schools.school_name, courses.trade, courses.course_name, courses.period, courses.course_level, courses.file 
                FROM courses
                INNER JOIN users ON courses.user_id = users.user_id
                INNER JOIN schools ON courses.schl_id = schools.school_id
                WHERE users.user_id = '$user_id' 
                ORDER BY courses.course_id DESC";

        $select = mysqli_query($conn, $sql);

        while ($rows = mysqli_fetch_array($select)) {
            $fileName = $rows['file'];
            $fileNameLimited = substr($fileName, 0, 10);
        ?>
        <tr id="course-<?php echo $rows['course_id']; ?>">
            <td><?=$rows['course_level']?></td>
            <td><?=$rows['trade']?></td>
            <td><?=$rows['course_name']?></td>
            <td><?=$rows['period']?></td>
            <td>
                <a href="view_course.php?course=<?=$rows['file']?>" target="_blank"><?=$fileNameLimited?></a>
            </td>
            <td>
                <!-- Edit Icon with SweetAlert -->
                <a href="javascript:void(0);" class="edit-course" data-course-id="<?=$rows['course_id']?>" data-trainer-id="<?=$user_id?>"><i class="fa fa-edit text-info" style="font-size: 25px;margin-right: 10px" title="Edit Course"></i></a>
                
                <!-- Delete Icon with SweetAlert -->
                <a href="javascript:void(0);" class="delete-course" data-course-id="<?=$rows['course_id']?>"><i class="fa fa-x text-danger" style="font-size: 25px;margin-right: 10px" title="Delete Course"></i></a>
            </td>
        </tr>
        <?php
        }
        ?>
        </tbody>
    </table>
</div>

<!-- SweetAlert CDN -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).on('click', '.edit-course', function() {
    var courseId = $(this).data('course-id');
    var trainerId = $(this).data('trainer-id');

    // Show SweetAlert for edit confirmation
    Swal.fire({
        title: 'Are you sure?',
        text: 'Do you want to edit this course?',
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, edit it!',
        cancelButtonText: 'No, cancel!'
    }).then((result) => {
        if (result.isConfirmed) {
            // Fetch course details via AJAX
            $.ajax({
                url: 'fetch_course_details.php',
                type: 'GET',
                data: { course_id: courseId },
                success: function(response) {
                    var course = JSON.parse(response);

                    if(course) {
                        // Open the modal with course details
                        $('#course-level').val(course.course_level);
                        $('#trade').val(course.trade);
                        $('#course-name').val(course.course_name);
                        $('#period').val(course.period);
                        $('#file').val(course.file);
                        $('#course-id').val(course.course_id);
                        
                        // Show the modal
                        $('#editCourseModal').modal('show');
                    } else {
                        Swal.fire({
                            title: 'Error!',
                            text: 'Course not found.',
                            icon: 'error',
                            confirmButtonText: 'Close'
                        });
                    }
                }
            });
        }
    });
});

// Delete course action
$(document).on('click', '.delete-course', function() {
    var courseId = $(this).data('course-id');
    
    Swal.fire({
        title: 'Are you sure?',
        text: 'Do you want to delete this course?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete it!',
        cancelButtonText: 'No, cancel!'
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                url: 'delete_course.php',
                type: 'GET',
                data: { course: courseId },
                success: function(response) {
                    if(response == 'success') {
                        Swal.fire({
                            title: 'Deleted!',
                            text: 'The course has been deleted successfully.',
                            icon: 'success',
                            confirmButtonText: 'Okay'
                        }).then(() => {
                            $('#course-' + courseId).remove();
                        });
                    } else {
                        Swal.fire({
                            title: 'Error!',
                            text: 'There was an issue deleting the course.',
                            icon: 'error',
                            confirmButtonText: 'Try Again'
                        });
                    }
                },
                error: function() {
                    Swal.fire({
                        title: 'Error!',
                        text: 'Something went wrong, please try again later.',
                        icon: 'error',
                        confirmButtonText: 'Close'
                    });
                }
            });
        }
    });
});
</script>

<!-- Modal for Edit Course -->
<div class="modal fade" id="editCourseModal" tabindex="-1" role="dialog" aria-labelledby="editCourseModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editCourseModalLabel">Edit Course</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="" method="POST">
                    <input type="hidden" name="course_id" id="course-id">
                    
                    <div class="form-group">
                        <label for="course_level">Course Level</label>
                        <input type="text" class="form-control" id="course-level" name="course_level" required>
                    </div>

                    <div class="form-group">
                        <label for="trade">Trade</label>
                        <input type="text" class="form-control" id="trade" name="trade" required>
                    </div>

                    <div class="form-group">
                        <label for="course_name">Course Name</label>
                        <input type="text" class="form-control" id="course-name" name="course_name" required>
                    </div>

                    <div class="form-group">
                        <label for="period">Period</label>
                        <input type="text" class="form-control" id="period" name="period" required>
                    </div>

                    <div class="form-group">
                        <label for="file">Course Notes</label>
                        <input type="text" class="form-control" id="file" name="file" required>
                    </div>

                    <button type="submit" class="btn btn-primary">Update Course</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php
require 'footer.php';
?>
