<?php
require 'header.php';
// Include the database connection
include('connection.php');
$school = $_SESSION['school'];
// Pagination setup
$limit = 12;  // Number of cards per page
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;  // Get the current page (default to 1)
$offset = ($page - 1) * $limit;  // Calculate the offset for the SQL query

// Get the total number of users for pagination
$result_count = $conn->query("SELECT COUNT(*) AS total FROM users WHERE school = '$school'");
$row_count = $result_count->fetch_assoc();
$total_users = $row_count['total'];
$total_pages = ceil($total_users / $limit);  // Calculate total pages

// Fetch user data for the current page
$query = "SELECT * FROM users WHERE school = '$school' AND title = 'Trainer' LIMIT $limit OFFSET $offset";
$result = $conn->query($query);
?>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <style>
        .user-card {
            margin-bottom: 20px;
            border: 1px solid #ddd;
            padding: 15px;
            border-radius: 8px;
        }
        .user-card img {
            width: 100%;
            height: auto;
            border-radius: 5px;
        }
        .document-links a {
            display: block;
            margin-bottom: 10px;
            color: #007bff;
            text-decoration: none;
        }
        .document-links a:hover {
            text-decoration: underline;
        }
        .document-links i {
            margin-right: 10px;
        }
        .nav-link.activetd {
        background-color: rgba(3, 29, 54, 0.56);
        color: white;
    }
    </style>
</head>
<body>

<div class="container my-5">
    <h4 class="text-center mb-4">Trainer Documents</h4>

    <div class="row">
        <?php
        // Check if there are any users
        if ($result->num_rows > 0) {
            // Loop through each user and display their information in cards
            while ($user = $result->fetch_assoc()) {
                ?>
                <div class="col-md-3">
                    <div class="user-card">
                        <img src="uploaded_file/<?php echo $user['user_image']; ?>" alt="User Image" style="height: 7rem;border-radius: 500px;border: 2px solid #09ad53;width: 7rem;">
                        <h5 class="mt-3"><?php echo htmlspecialchars($user['username']); ?></h5>

                        <!-- Trainer Documents Links -->
                        <div class="document-links">
                                <a href="class_dairy_plan.php?trainer=<?=$user['user_id']?>/<?=$user['username']?>">
                                    <i class="fa fa-book"></i> Class Diary Plan
                                </a>
                                <a href="trainer_modules.php?trainer=<?=$user['user_id']?>/<?=$user['username']?>">
                                    <i class="fa fa-chalkboard-teacher"></i> Courses/Modules
                                </a>
                               
                                <a href="trainer_session_plans.php?trainer=<?=$user['user_id']?>/<?=$user['username']?>" target="">
                                    <i class="fa fa-file-o"></i> Session Plan
                                </a>
                               
                                <a href="trainer_assessment_plans.php?trainer=<?=$user['user_id']?>/<?=$user['username']?>" target="">
                                    <i class="fa fa-pencil-alt"></i> Assessment Plan
                                </a>
                                
                                <a href="trainer_schema_of_work.php?trainer=<?=$user['user_id']?>/<?=$user['username']?>" target="">
                                    <i class="fa fa-file-alt"></i> Schema of Work
                                </a>
                            
                                <a href="trainer_inspections.php?trainer=<?=$user['user_id']?>/<?=$user['username']?>" target="">
                                    <i class="fa fa-user-tie"></i> Inspections
                                </a>
                            <?php  ?>
                        </div>
                    </div>
                </div>
                <?php
            }
        } else {
            echo "<p>No users found.</p>";
        }
        ?>
    </div>

    <!-- Pagination Links -->
    <nav aria-label="Page navigation">
        <ul class="pagination justify-content-center">
            <?php if ($page > 1) : ?>
                <li class="page-item">
                    <a class="page-link" href="?page=<?php echo $page - 1; ?>">Previous</a>
                </li>
            <?php endif; ?>

            <?php for ($i = 1; $i <= $total_pages; $i++) : ?>
                <li class="page-item <?php echo ($i == $page) ? 'active' : ''; ?>">
                    <a class="page-link" href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                </li>
            <?php endfor; ?>

            <?php if ($page < $total_pages) : ?>
                <li class="page-item">
                    <a class="page-link" href="?page=<?php echo $page + 1; ?>">Next</a>
                </li>
            <?php endif; ?>
        </ul>
    </nav>
</div>

<script src="https://kit.fontawesome.com/a076d05399.js"></script>

</body>
</html>

<?php
// Close the database connection
$conn->close();
require 'footer.php';
?>
