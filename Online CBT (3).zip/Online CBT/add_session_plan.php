<?php
require 'header.php'; // Include header
require 'connection.php'; // Include database connection

// session_start();

// Process form submission if POST request is made
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['course_id'], $_POST['session_date'], $_FILES['session_doc'])) {
    $course_id = $_POST['course_id'];
    $user_id = $_SESSION['user_id'];
    $school_id = $_SESSION['school'];
    $session_date = $_POST['session_date'];
    $session_doc = $_FILES['session_doc'];

    // Handle file upload
    $upload_dir = 'session_plan/'; // Upload directory
    $file_name = basename($session_doc['name']); // Extract only the filename
    $upload_file = $upload_dir . $file_name; // Full file path

    if (move_uploaded_file($session_doc['tmp_name'], $upload_file)) {
        // Insert session plan
        $sql = "INSERT INTO session_plan (sschl_id, suser_id, scourse_id, date, session_doc) 
                VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("iiiss", $school_id, $user_id, $course_id, $session_date, $file_name);

        if ($stmt->execute()) {
            // Increment session_plan count in courses table
            $updateSql = "UPDATE courses SET session_plan = session_plan + 1 WHERE course_id = ?";
            $stmtUpdate = $conn->prepare($updateSql);
            $stmtUpdate->bind_param("i", $course_id);

            if ($stmtUpdate->execute()) {
                $message = "Session plan added successfully.";
                $redirect = true;
            } else {
                $message = "Error updating course session count: " . $conn->error;
                $redirect = false;
            }
        } else {
            $message = "Error: " . $conn->error;
            $redirect = false;
        }
    } else {
        $message = "Error uploading file.";
        $redirect = false;
    }
}

// Get the course_id from the URL
$course_id = isset($_GET['module']) ? $_GET['module'] : null;

// Fetch course details
$course = null;
if ($course_id) {
    $sql = "SELECT * FROM courses WHERE course_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $course_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $course = $result->fetch_assoc();
    }
}
?>
<style>
    .nav-link.activecmo {
        background-color: rgba(3, 29, 54, 0.56);
        color: white;
    }
</style>
<div class="container mt-3">
    <h4>Add Session Plan</h4>

    <div class="card col-lg-6">
        <div class="card-header">
            <h5 class="card-title">Session Plan for Module: <?php echo isset($course['course_name']) ? htmlspecialchars($course['course_name']) : 'N/A'; ?></h5>
        </div>
        <div class="card-body">
            <?php if ($course): ?>
                <h6>Module Name: <?php echo htmlspecialchars($course['course_name']); ?></h6>
                <p>Module Level: <b><?php echo htmlspecialchars($course['course_level']); ?></b></p>
            <?php endif; ?>

            <form id="sessionPlanForm" method="POST" enctype="multipart/form-data" action="">
                <input type="hidden" name="course_id" value="<?php echo htmlspecialchars($course_id); ?>">
                <input type="hidden" name="user_id" value="<?php echo $_SESSION['user_id']; ?>">
                <input type="hidden" name="school_id" value="<?php echo $_SESSION['school']; ?>">

                <div class="form-group">
                    <label for="session_date">Session Date</label>
                    <input type="date" class="form-control" id="session_date" name="session_date" required>
                </div>

                <div class="form-group">
                    <label for="session_doc">Session Document</label>
                    <input type="file" class="form-control-file" id="session_doc" name="session_doc" required>
                </div>

                <button type="submit" class="btn btn-primary col-lg-12 col-ms-12">Submit</button>
            </form>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<?php if (isset($redirect) && $redirect): ?>
    <script>
        Swal.fire({
            icon: 'success',
            title: 'Success',
            text: '<?php echo $message; ?>',
            showConfirmButton: false,
            timer: 5000
        }).then(function() {
            window.location.href = 'module_with_no_session_plan.php';
        });
    </script>
<?php elseif (isset($message)): ?>
    <script>
        Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: '<?php echo $message; ?>',
            showConfirmButton: true
        });
    </script>
<?php endif; ?>

<?php require 'footer.php'; ?>
