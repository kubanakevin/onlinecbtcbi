<?php
// Include the database connection file
require 'connection.php';

// Check if the 'file' parameter exists in the URL
if (isset($_GET['course'])) {
    $file_name = $_GET['course'];
    $file_path = 'uploaded_files/' . $file_name;

    // Check if the file exists
    if (file_exists($file_path)) {
        // Get the file extension
        $file_extension = pathinfo($file_path, PATHINFO_EXTENSION);

        // Set the appropriate headers based on the file type
        switch($file_extension) {
            case 'pdf':
                header('Content-Type: application/pdf');
                break;
            case 'jpg':
            case 'jpeg':
                header('Content-Type: image/jpeg');
                break;
            case 'png':
                header('Content-Type: image/png');
                break;
            case 'txt':
                header('Content-Type: text/plain');
                break;
            // Add more content types as needed
            default:
                header('Content-Type: application/octet-stream');
                break;
        }

        // Output the file
        readfile($file_path);
        exit();
    } else {
        echo "File not found.";
    }
} else {
    echo "No file specified.";
}
?>
