<?php
session_start();
include 'connection.php'; // Ensure this file contains the $conn variable for MySQLi connection

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if session variables are set
    if (!isset($_SESSION['user_id']) || !isset($_SESSION['school'])) {
        echo "<script>alert('Unauthorized access.'); window.history.back();</script>";
        exit;
    }

    $user = $_SESSION['user_id'];
    $school = $_SESSION['school'];
    $message = trim($_POST['message'] ?? '');

    // Validate message input
    if (empty($message)) {
        echo "<script>alert('Message cannot be empty.'); window.history.back();</script>";
        exit;
    }

    // Ensure the MySQLi connection ($conn) is available
    global $conn;

    // Prepare the SQL statement
    $stmt = mysqli_prepare($conn, "INSERT INTO messages (muser_id, mschl_id, message) VALUES (?, ?, ?)");
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "iis", $user, $school, $message);
        if (mysqli_stmt_execute($stmt)) {
            mysqli_stmt_close($stmt);
            
            // Success alert and redirect
            echo "<script>alert('Message sent successfully!'); window.location.href = 'messages.php';</script>";
            exit();
        } else {
            echo "<script>alert('Failed to send message.'); window.history.back();</script>";
        }
        mysqli_stmt_close($stmt);
    } else {
        echo "<script>alert('Database error: " . mysqli_error($conn) . "'); window.history.back();</script>";
    }
} else {
    echo "<script>alert('Invalid request method!'); window.history.back();</script>";
}
?>
