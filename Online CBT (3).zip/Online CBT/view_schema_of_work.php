<?php
// Include the database connection file
require 'connection.php';

// Check if the 'schema' parameter exists in the URL
if (isset($_GET['schema'])) {
    $file_name = $_GET['schema'];
    $file_path = 'schema_of_work/' . $file_name;

    // Check if the file exists
    if (file_exists($file_path)) {
        // Get the file extension
        $file_extension = strtolower(pathinfo($file_path, PATHINFO_EXTENSION));

        // Set headers based on file type
        switch ($file_extension) {
            case 'pdf':
                header('Content-Type: application/pdf');
                readfile($file_path);
                exit();
            
            case 'docx':
            case 'doc':
                // Option 1: Force Download
                // header('Content-Type: application/vnd.openxmlformats-officedocument.wordprocessingml.document'); // For .docx
                // header('Content-Type: application/msword'); // For .doc
                // header('Content-Disposition: inline; filename="' . basename($file_path) . '"');
                // readfile($file_path);
                // exit();

                // Option 2: Redirect to Microsoft Office Viewer
                $encoded_url = urlencode('http://yourwebsite.com/' . $file_path);
                header('Location: https://view.officeapps.live.com/op/view.aspx?src=' . $encoded_url);
                exit();
            
            case 'txt':
                header('Content-Type: text/plain');
                readfile($file_path);
                exit();

            default:
                header('Content-Type: application/octet-stream');
                header('Content-Disposition: attachment; filename="' . basename($file_path) . '"');
                readfile($file_path);
                exit();
        }
    } else {
        echo "File not found.";
    }
} else {
    echo "No file specified.";
}
?>
