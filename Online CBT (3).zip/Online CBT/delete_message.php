<?php
// Include database connection
require 'connection.php';

// Check if message_id is set
if (isset($_GET['message']) && is_numeric($_GET['message'])) {
    $message_id = $_GET['message'];

    // Prepare the DELETE statement
    $stmt = $conn->prepare("DELETE FROM messages WHERE message_id = ?");
    $stmt->bind_param("i", $message_id);

    // Execute the statement
    if ($stmt->execute()) {
        echo "<script>
                alert('Message deleted successfully!');
                window.location.href = 'messages.php'; // Redirect after deletion
              </script>";
    } else {
        echo "<script>alert('Error deleting message.');</script>";
    }

    // Close statement and connection
    $stmt->close();
} else {
    echo "<script>alert('Invalid message ID.');</script>";
}

// Close database connection
$conn->close();
?>
